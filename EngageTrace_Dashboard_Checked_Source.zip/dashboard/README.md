# EngageTrace dashboard visual refresh

A standalone redesign of the supplied React dashboard. This is separate from US-01 and its import branch.

## Open the dashboard

Keep `engagetrace_dashboard.html`, `bundle.js`, and `dashboard.css` in the same directory. Open the HTML in your browser. No build or server is required for the included preview. The default view uses synthetic demonstration data. Use **Load course data** to select an existing course JSON export. Local JSON stays in the browser; optional Supabase connections make network requests to the configured project.

## Rebuild

Use Node.js 20+ and npm. From this directory:

```sh
npm ci
npm run build
```

The lockfile pins dependencies. Source files: `engagetrace_dashboard.jsx` and `main.jsx`. Rebuild `bundle.js` after source edits. Styling is in `dashboard.css`.

## Changes

- Black/charcoal navigation, gold accents and a light workspace.
- Responsive overview, student activity and method comparison views.
- Course/student/flag summary cards, labeled controls and visible keyboard focus.
- Data source panel, comparison settings disclosure and student selector.
- Activity and method tables alongside charts, plus text/symbol flag indicators.
- Synthetic demo context shown only for synthetic data. Imported courses show no false-positive claims or fabricated quiet-period markers.
- JSON import checks for unique student IDs, matching week lengths and nonnegative numeric values; invalid/missing observations are rejected rather than silently plotted.

Detector formulas, defaults and synthetic generation are retained from the supplied JSX. Their implementation sections were checked byte-for-byte against the original. Imported data is still calculated in JavaScript. This preview is not connected to local SQLite, does not save runs and does not resolve the Python/JavaScript experimental differences documented in US-01. The Supabase path is retained but was not tested against a live account. No credentials are included.

The course overview and student activity views share the same timeline and controls; they are views of the currently loaded course, not separate persisted analyses. No saved-run navigation is shown because storage is not implemented here.
