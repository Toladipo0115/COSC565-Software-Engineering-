import React from 'react';
import {createRoot} from 'react-dom/client';
import EngageTraceDashboard from './engagetrace_dashboard.jsx';
createRoot(document.getElementById('root')).render(<EngageTraceDashboard/>);
