"""Reproducible CAP v2 event-window evaluation. No test-set tuning."""
import argparse,bisect,csv,hashlib,json,math,platform,random,sqlite3,statistics,time
from collections import defaultdict
from pathlib import Path

METHODS=['fixed','raw_individual','log_individual','cusum','cap','no_persistence','no_individual']
SCENARIOS=['no_change','sustained','temporary','quiet_only','decline_during_quiet']
ONSETS=[12,12,15,7,7]

def detect(matrix,cfg,upper_ties=False):
    n=len(matrix);T=len(matrix[0]);k=cfg['history_weeks'];lag=cfg['lag_weeks'];p=cfg['persistence_weeks']
    logs=[[math.log1p(v) for v in x] for x in matrix]
    ld=[[None]*T for _ in matrix];rd=[[None]*T for _ in matrix]
    for j,x in enumerate(matrix):
        for t in range(k+lag,T):
            base=statistics.median(x[t-k-lag:t-lag]);rd[j][t]=(base-x[t])/(base+1e-6)
            ld[j][t]=statistics.median(logs[j][t-k-lag:t-lag])-logs[j][t]
    ranks=[[None]*T for _ in matrix]
    for t in range(k+lag,T):
        values=sorted(d[t] for d in ld)
        for j in range(n):
            low=bisect.bisect_left(values,ld[j][t]);high=bisect.bisect_right(values,ld[j][t])
            ranks[j][t]=high/n if upper_ties else (low+high)/(2*n)
    out={m:[[False]*T for _ in matrix] for m in METHODS}
    for j,x in enumerate(matrix):
        runs=defaultdict(int);mu=statistics.median(x[:k]);S=0.
        for t in range(T):
            individual=ld[j][t] is not None and ld[j][t]>=cfg['log_decline_threshold']
            context=ranks[j][t] is not None and ranks[j][t]>=cfg['context_percentile']
            conditions={'fixed':x[t]<cfg['fixed_click_threshold'],'raw_individual':rd[j][t] is not None and rd[j][t]>=cfg['raw_relative_drop_threshold'],'log_individual':individual,'cap':individual and context,'no_individual':context}
            for m,condition in conditions.items():
                runs[m]=runs[m]+1 if condition else 0;out[m][j][t]=runs[m]>=p
            out['no_persistence'][j][t]=individual and context
            if t>=k:
                S=max(0,S+mu-x[t]-cfg['cusum_slack_fraction']*mu)
                out['cusum'][j][t]=mu>0 and S>cfg['cusum_threshold_fraction']*mu
    return out

def hashfile(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()

def load_data(db_path,reg_path,cfg):
    dev=set();eligible=defaultdict(list);counts=defaultdict(int)
    with open(reg_path,newline='') as f:
        for r in csv.DictReader(f):
            course=r['code_module']+'_'+r['code_presentation'];sid=r['id_student']
            if course in cfg['development_presentations']:dev.add(sid)
    with open(reg_path,newline='') as f:
        for r in csv.DictReader(f):
            if r['code_module'] not in cfg['evaluation_modules']:continue
            counts['candidate_enrollments']+=1
            if r['id_student'] in dev:counts['shared_student_purged']+=1;continue
            reg=r['date_registration'];unreg=r['date_unregistration']
            if reg in ('','?') or int(reg)>0:counts['late_or_unknown_registration']+=1;continue
            if unreg not in ('','?') and int(unreg)<140:counts['unregistered_before_window_end']+=1;continue
            eligible[r['code_module']+'_'+r['code_presentation']].append(r['id_student'])
    data={}
    with sqlite3.connect(f'file:{Path(db_path).resolve()}?mode=ro',uri=True) as con:
        for course,ids in sorted(eligible.items()):
            matrix={sid:[0]*cfg['weeks'] for sid in ids}
            for sid,w,v in con.execute('SELECT student_id,week,clicks FROM weekly_activity WHERE course_id=? AND week BETWEEN 1 AND ?',(course,cfg['weeks'])):
                if sid in matrix:matrix[sid][w-1]=v
            for sid in list(matrix):
                if not sum(matrix[sid]):counts['zero_total_clicks']+=1;del matrix[sid]
            data[course]=matrix
    counts['eligible_enrollments']=sum(map(len,data.values()))
    return data,dict(counts),dev

def experiment(data,cfg,quiet_length=2):
    rows=[];assignment=[]
    for course,pool in sorted(data.items()):
        ids=sorted(pool)
        n=min(cfg['maximum_students_per_course_seed'],len(ids));n-=n%5
        for seed in cfg['seeds']:
            rng=random.Random(f'{course}:{seed}');chosen=rng.sample(ids,n)
            original=[pool[sid][:] for sid in chosen];injected=[];categories=[]
            for j,sid in enumerate(chosen):
                category=SCENARIOS[j//(n//5)];categories.append(category);values=pool[sid][:]
                for w in range(7,7+quiet_length):values[w-1]=round(values[w-1]*.5)
                if category in ['sustained','decline_during_quiet']:
                    onset=12 if category=='sustained' else 7
                    for w in range(onset,cfg['weeks']+1):values[w-1]=round(values[w-1]*.25)
                elif category=='temporary':values[14]=round(values[14]*.25)
                injected.append(values)
                assignment.append({'course':course,'seed':seed,'student':sid,'scenario':category,'quiet_length':quiet_length})
            base=detect(original,cfg);flags=detect(injected,cfg);upper=detect(injected,cfg,upper_ties=True)
            for j,category in enumerate(categories):
                onset=ONSETS[SCENARIOS.index(category)];start=onset-1;end=min(start+cfg['response_window_weeks'],cfg['weeks'])
                for method in METHODS:
                    times=[t for t in range(start,end) if flags[method][j][t]]
                    base_flag=any(base[method][j][start:end]);alarm=bool(times)
                    rows.append({'course':course,'seed':seed,'student':chosen[j],'scenario':category,'method':method,'quiet_length':quiet_length,'positive':int(category in cfg['positive_scenarios']),'alarm':int(alarm),'baseline_alarm':int(base_flag),'new_alarm':int(alarm and not base_flag),'lost_alarm':int(base_flag and not alarm),'delay':times[0]-start if times else None,'pre_onset_alarm':int(any(flags[method][j][cfg['history_weeks']+cfg['lag_weeks']:start])),'window_weeks':end-start,'upper_rank_alarm':int(any(upper[method][j][start:end]))})
    return rows,assignment

def aggregate(rows):
    groups=defaultdict(list)
    for r in rows:groups[(r['quiet_length'],r['course'],r['seed'],r['method'],r['scenario'])].append(r)
    out=[]
    for key,rr in sorted(groups.items()):
        q,c,s,m,g=key;entry={'quiet_length':q,'course':c,'seed':s,'method':m,'scenario':g,'n':len(rr)}
        for name in ['alarm','baseline_alarm','new_alarm','lost_alarm','pre_onset_alarm','upper_rank_alarm']:entry[name+'_rate']=statistics.mean(r[name] for r in rr)
        ds=[r['delay'] for r in rr if r['delay'] is not None];entry['mean_delay']=statistics.mean(ds) if ds else None
        out.append(entry)
    return out

def tests(cfg):
    zero=[[0]*20 for _ in range(20)];f=detect(zero,cfg)
    assert not any(any(x) for x in f['cap']), 'Tied cohort must not look unusually low'
    matrix=[[100]*12+[10]*8]+[[100]*20 for _ in range(19)]
    flags=detect(matrix,cfg)
    assert any(flags['cap'][0]);assert not any(flags['cap'][j][t] for j in range(1,20) for t in range(20))
    assert flags['log_individual']==flags['log_individual']
    for m in METHODS:
        prefix=detect([x[:15] for x in matrix],cfg)
        assert [x[:15] for x in flags[m]]==prefix[m], f'Future leakage {m}'
    for j in range(20):
        for t in range(20):assert not flags['cap'][j][t] or flags['log_individual'][j][t]
    print('Detector tests passed: zero ties, planted decline, context, persistence implication and prefix invariance.')

def main():
    p=argparse.ArgumentParser();p.add_argument('--database',required=True);p.add_argument('--registration',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    start=time.monotonic();out=Path(a.output);out.mkdir(parents=True,exist_ok=True);cfg=json.loads(Path(__file__).with_name('protocol.json').read_text());tests(cfg)
    data,counts,dev=load_data(a.database,a.registration,cfg);print('Cohort',counts,'courses',{k:len(v) for k,v in data.items()},flush=True)
    rows=[];assignments=[]
    for q in [2,4]:
        rr,aa=experiment(data,cfg,q);rows+=rr;assignments+=aa;print('Completed quiet-length',q,flush=True)
    for name,records in [('case_results.csv',rows),('assignments.csv',assignments),('course_seed_results.csv',aggregate(rows))]:
        with (out/name).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
    (out/'provenance.json').write_text(json.dumps({'protocol':cfg,'counts':counts,'course_pool_sizes':{k:len(v) for k,v in data.items()},'source_hashes':{'database':hashfile(a.database),'registration':hashfile(a.registration)},'code_sha256':hashfile(__file__),'python':platform.python_version(),'elapsed_seconds':time.monotonic()-start},indent=2))

if __name__=='__main__':main()
