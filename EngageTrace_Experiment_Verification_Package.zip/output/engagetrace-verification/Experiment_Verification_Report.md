# EngageTrace experiment verification and paper changes

The supplied EngageTrace experiments are computationally reproducible. All 24 six-course alert totals and all four original controlled-method summaries match the saved results exactly. The source data and original manuscript are preserved.

## What was verified

- Rebuilt SQLite database used read-only; six presentations total 13,613 registered student-course records.
- All 300 saved controlled sequences match the stated injections applied to their source traces in the rebuilt database.
- All seven saved aggregate method/ablation summaries match exactly, including the originally withheld timing values. Reproducing those values does not validate their scoring interpretation.
- Original controlled CAP flags 90/120 positive-scenario sequences and 67/180 negative-scenario sequences. Fixed flags 93/120 and 69/180.
- Scenario counts are archived in `original_scenario_counts.csv`.

## Reconciliation of the original outputs

| Component | Six-course volume table | Controlled experiment |
|---|---|---|
| CAP individual statistic | Raw relative decline | Log1p decline |
| Historical baseline | Previous 3 weeks | 3 observations separated by a 3-week lag |
| Context | Leave-one-out deviation median/MAD | Upper percentile rank including focal sequence |
| Context cutoff | 1.5 | 0.6 |
| Individual cutoff | 0.5 | 0.2 log units |
| Persistence | 2 weeks | 3 weeks |
| Scoring | Flagged student-weeks | Any flag anywhere in 20 weeks |

These are two implementations. Their tables cannot support claims about one consistently configured detector. `six_course_reproduction.csv` intentionally records the failed attempt to apply revised settings to the legacy table. `legacy_six_course_reproduction.csv` records the exact successful reproduction with the correct legacy settings. The failed comparison is retained for transparency.

The individual-history comparator uses a raw relative drop. CAP without context retains its log-scale deviation. They were described as equivalent in earlier prose, but the implementation establishes that they are different. A matched context ablation compares log history plus persistence with full revised CAP.

The revised baseline is exactly k observations. With one-based candidate week t, its indices are t-k-L through t-L-1, inclusive. For k=3 and L=3, candidate week 7 uses weeks 1–3. This resolves the earlier endpoint ambiguity.

Original upper percentile ranks assign ties to their upper rank. CUSUM uses the first three observations' median and updates from week 1. Its reference therefore uses future observations during those initial weeks. Neither behavior was silently changed in the faithful transfer check.

Original controlled scoring accepts pre-onset flags as detections. The reported delay is clipped to zero for those flags. Timing columns remain excluded from the paper because numerical reproducibility does not make them evidence of valid post-onset timeliness.

## Faithful detector transfer follow-up

The separate follow-up uses the original revised detector unchanged. Eight AAA/EEE/GGG presentations are outside the six descriptive development presentations. Student overlap with development presentations is removed. Eligibility requires registration by day 0, no recorded withdrawal before day 140, and positive total activity through day 139, leaving 4,578 eligible enrollments. Each presentation/seed samples 300 sequences and assigns 60 to each scenario. Seeds are 101, 202, 303, 404, and 505.

Each scenario uses a six-week response window. Sustained decline and no_change start scoring at week 12; temporary dip at 15; quiet-only and decline during quiet at 7. Pre-onset alarms are recorded separately. Corresponding unmodified traces are also evaluated. Natural declines remain possible; negative-scenario flags are not verified false positives.

Results are equal-weight presentation means across seeds and scenarios within each scenario group. Descriptive intervals resample the eight presentation means 10,000 times with seed 1026. Repeated seeds and students are not independent replications. The intervals describe course variation, not external population certainty.

| Method | Two-week lull positive | Two-week lull negative | Four-week lull positive | Four-week lull negative |
|---|---:|---:|---:|---:|
| Fixed | 0.7025 | 0.5021 | 0.7410 | 0.5154 |
| Raw individual history | 0.6102 | 0.3133 | 0.6042 | 0.3375 |
| Log history / no context | 0.6735 | 0.4494 | 0.6696 | 0.4500 |
| CUSUM | 0.7750 | 0.6633 | 0.7833 | 0.6989 |
| CAP | 0.5348 | 0.2550 | 0.5242 | 0.2414 |
| No persistence | 0.8500 | 0.7681 | 0.8398 | 0.7519 |
| No individual condition | 0.6863 | 0.4301 | 0.6781 | 0.4256 |

For a two-week lull, CAP's descriptive course-bootstrap intervals are 0.4460–0.6131 for positive scenarios and 0.2418–0.2683 for negative scenarios. Fixed-rule intervals are 0.5967–0.8185 and 0.4028–0.6119. The alert reduction entails substantially lower positive-scenario detection; no universal superiority is claimed.

This run followed inspection of a previous transfer run that changed tie handling and CUSUM warm-up. That modified run is excluded from the paper. The faithful follow-up inherits detector settings without tuning in that run, but prior protocol exposure makes it exploratory, not a pristine confirmatory held-out test.

## Paper changes and COSC722 alignment

- Continued the existing EngageTrace paper rather than creating a replacement study.
- Added the requested author order: Tolulope Oladipo, Hubert Kyeremateng-Boateng, Avijoy Chakma. Hubert's department was not invented; confirm his author block before submission.
- Used the supplied IEEE Word template styles, Letter pages, two columns, 10-point body text, and no page numbering.
- Kept all original table values and plots; corrected their implementation labels and methods descriptions.
- Added separate transfer methods/results and a matched-ablation table, with limitations and descriptive uncertainty.
- Maintained the introduction, synthesized related work, explicit methods, experiments, results, discussion, limitations, and conclusion requested by the writing guide.
- Retained the 32-source bibliography; structural citation checks do not replace a publisher/full-text audit.
- Preserved the distinction from the COSC750 source-staleness/withdrawal classifier and the VR/AR–LMS architecture taxonomy. Shared use of OULAD or a dashboard is not claimed as novelty.

## Remaining work before conference submission

1. Check all bibliography metadata and claim support against primary sources; review the close 2026 contextual anomaly-detection literature.
2. Verify browser–Python parity on identical matrices and configurations, or keep dashboard outputs outside experimental claims.
3. Independently review the event-window and cohort-selection protocol. Original cohort selection and seed were not archived; fixed-threshold quantile population and algorithm were not logged.
4. Decide whether the observed detection/alert tradeoff supports a sufficiently strong contribution; no claim of broad superiority or acceptance is warranted.
5. Confirm all authors' names, affiliations, consent, and final submission details.

## Reproduction

The archive preserves the required project-relative layout. From its root, using Python with NumPy installed:

```
python output/engagetrace-verification/verify_original.py
python output/engagetrace-verification/verify_legacy_sweep.py
python output/engagetrace-verification/faithful_transfer.py
python output/engagetrace-verification/summarize_faithful_transfer.py
```

The original detector and saved controlled inputs are in `claude_source`. Supply the previously rebuilt database at `output/database/engagetrace.db` and OULAD registration CSV at `oulad_raw/studentRegistration.csv`. The archive omits the database and raw OULAD files to avoid unnecessary duplication. Original-cohort verification itself runs before the database-dependent stage in `verify_original.py`. Research inputs contain pseudonymous OULAD identifiers; the package is for the user's review, not an instruction to publish student-level outputs.
