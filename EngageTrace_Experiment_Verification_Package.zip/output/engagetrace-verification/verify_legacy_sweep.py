"""Read-only reproduction of legacy SQLite detector, with vectorized leave-one-out MAD."""
import csv,json,sqlite3,statistics
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
rows=[]
with sqlite3.connect(f'file:{ROOT}/output/database/engagetrace.db?mode=ro',uri=True) as con:
 for course,target in json.loads((ROOT/'claude_source/cross_course_sweep_results.json').read_text()).items():
  T=con.execute('select max(week) from weekly_activity where course_id=?',(course,)).fetchone()[0]
  ids=[s for s, in con.execute('select student_id from students where course_id=?',(course,))];index={s:i for i,s in enumerate(ids)};a=np.zeros((len(ids),T))
  for sid,w,v in con.execute('select student_id,week,clicks from weekly_activity where course_id=?',(course,)):a[index[sid],w-1]=v
  d=np.full_like(a,np.nan);z=np.full_like(a,np.nan)
  for t in range(3,T):
   b=np.median(a[:,t-3:t],axis=1);d[:,t]=(b-a[:,t])/(b+1e-6)
   v=d[:,t];others=np.broadcast_to(v,(len(v),len(v)))[~np.eye(len(v),dtype=bool)].reshape(len(v),len(v)-1)
   med=np.median(others,axis=1);mad=np.median(abs(others-med[:,None]),axis=1);z[:,t]=(v-med)/(mad+1e-6)
  total={m:0 for m in ['fixed','individual','cusum','cap']}
  for j,x in enumerate(a):
   runs={m:0 for m in ['fixed','individual','cap']};mu=statistics.median(x[:3]);S=0
   for t,v in enumerate(x):
    for m,test in [('fixed',v<target['fixed_threshold']),('individual',d[j,t]>=.5),('cap',d[j,t]>=.5 and z[j,t]>=1.5)]:
     runs[m]=runs[m]+1 if test else 0;total[m]+=int(runs[m]>=2)
    S=max(0.,S+(mu-v)-.25*mu);total['cusum']+=int(S>2*mu and mu>0)
  for m,old in target['summary'].items():rows.append(dict(course=course,n=len(ids),weeks=T,method=m,reported=old,reproduced=total[m],match=old==total[m]))
  print(course,total,{m:total[m]==target['summary'][m] for m in total},flush=True)
with (OUT/'legacy_six_course_reproduction.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
