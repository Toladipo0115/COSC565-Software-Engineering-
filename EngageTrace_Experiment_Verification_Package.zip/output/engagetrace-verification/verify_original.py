"""Reproduce supplied EngageTrace summaries without changing detector semantics.
Run from project workspace. Percentile counting is replaced by equivalent bisect_right.
"""
import bisect,csv,hashlib,json,sqlite3,statistics,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];SRC=ROOT/'claude_source';OUT=Path(__file__).resolve().parent
source=(SRC/'controlled_eval.py').read_text()
assert source.count('sum(1 for x in sorted_vals if x <= v)')==1
namespace={'__name__':'original_detector','bisect':bisect}
exec(compile(source.replace('sum(1 for x in sorted_vals if x <= v)','bisect.bisect_right(sorted_vals, v)'),str(SRC/'controlled_eval.py'),'exec'),namespace)
params=dict(k=3,tau_ind=.5,tau_ctx=.6,p=3,fixed_threshold=6,tau_ind_log=.2)
c=json.loads((SRC/'controlled_eval_cohort.json').read_text());matrix=c['matrix'];assignment=c['assignment']
results=namespace['run_controlled_evaluation'](matrix,assignment,**params)
expected=json.loads((SRC/'controlled_eval_final.json').read_text())
assert all(results[m]==expected[m] for m in expected)
flags=namespace['compute_flags'](matrix,**params)
category=[]
for group in namespace['CATEGORIES']:
 ids=[sid for sid,g in assignment.items() if g==group]
 for method in flags[ids[0]]:
  category.append(dict(scenario=group,method=method,n=len(ids),flagged=sum(any(flags[s][method]) for s in ids)))
with (OUT/'original_scenario_counts.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(category[0]));w.writeheader();w.writerows(category)
real=[]
with sqlite3.connect(f'file:{ROOT}/output/database/engagetrace.db?mode=ro',uri=True) as con:
 for course,target in json.loads((SRC/'cross_course_sweep_results.json').read_text()).items():
  n=con.execute('select max(week) from weekly_activity where course_id=?',(course,)).fetchone()[0]
  mat={str(sid):[0]*n for (sid,) in con.execute('select student_id from students where course_id=?',(course,))}
  for sid,week,click in con.execute('select student_id,week,clicks from weekly_activity where course_id=?',(course,)):mat[str(sid)][week-1]=click
  cfg=dict(params,fixed_threshold=target['fixed_threshold']);ff=namespace['compute_flags'](mat,**cfg)
  for method,old in target['summary'].items():
   count=sum(sum(row[method]) for row in ff.values())
   real.append(dict(course=course,n=len(mat),weeks=n,method=method,reported=old,reproduced=count,match=count==old,fixed_threshold=cfg['fixed_threshold']))
  print(course,[(r['method'],r['match'],r['reproduced']) for r in real if r['course']==course],flush=True)
with (OUT/'six_course_reproduction.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(real[0]));w.writeheader();w.writerows(real)
(OUT/'original_cohort_rerun.json').write_text(json.dumps(results,indent=2))
(OUT/'verification_manifest.json').write_text(json.dumps(dict(parameters=params,original_aggregate_exact=True,all_six_course_counts_exact=all(r['match'] for r in real),source_sha256=hashlib.sha256(source.encode()).hexdigest(),percentile_optimization='bisect_right is exactly count(x <= v), retaining upper ties'),indent=2))
