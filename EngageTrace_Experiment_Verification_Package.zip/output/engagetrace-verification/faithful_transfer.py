"""Transfer check of original log-percentile detector, with explicit event scoring.
Preserves original upper ties, CUSUM initialization, history and thresholds.
Sampling and event-window scoring are new and declared; no tuning on this run.
"""
import csv,hashlib,importlib.util,json,platform,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent/'faithful_transfer_results';OUT.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('transfer',ROOT/'output/icicip-paper/code/run_validation.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
# Exact upper-rank count, with bisect for speed. Keep supplied source unchanged on disk.
import bisect
source=(ROOT/'claude_source/controlled_eval.py').read_text();ns={'__name__':'original_detector','bisect':bisect}
exec(compile(source.replace('sum(1 for x in sorted_vals if x <= v)','bisect.bisect_right(sorted_vals, v)'), 'controlled_eval.py','exec'),ns)
def original_detect(matrix,cfg,upper_ties=False):
 f=ns['compute_flags']({str(j):x for j,x in enumerate(matrix)},k=cfg['history_weeks'],tau_ind=cfg['raw_relative_drop_threshold'],tau_ctx=cfg['context_percentile'],p=cfg['persistence_weeks'],fixed_threshold=cfg['fixed_click_threshold'],tau_ind_log=cfg['log_decline_threshold'])
 names={'fixed':'fixed','raw_individual':'individual','log_individual':'cap_no_context','cusum':'cusum','cap':'cap','no_persistence':'cap_no_persistence','no_individual':'cap_no_individual'}
 return {m:[f[str(j)][old] for j in range(len(matrix))] for m,old in names.items()}
v.detect=original_detect
cfg=json.loads((ROOT/'output/icicip-paper/code/protocol.json').read_text());cfg['version']='CAP-original-detector-transfer-v1';cfg['context_ties']='upper rank including focal observation, as in original controlled_eval.py';cfg['cusum_initialization']='median first three weeks; updates from week 1; no alarm reset, matching original code';cfg['reporting']='Six-week event windows; pre-onset alarms recorded separately; injected labels only; modified-midrank v2 run excluded';cfg['protocol_recovery']='Detector settings and cohort choices inherited; this check follows inspection of a prior modified-detector transfer run and is exploratory, not a pristine confirmatory test.'
data,counts,_=v.load_data(ROOT/'output/database/engagetrace.db',ROOT/'oulad_raw/studentRegistration.csv',cfg)
rows=[];assignment=[]
for q in [2,4]:
 r,a=v.experiment(data,cfg,q);rows+=r;assignment+=a
 print('Completed original detector transfer quiet-length',q,flush=True)
for name,records in [('case_results.csv',rows),('assignments.csv',assignment),('course_seed_results.csv',v.aggregate(rows))]:
 with (OUT/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
(OUT/'provenance.json').write_text(json.dumps({'protocol':cfg,'counts':counts,'course_pool_sizes':{k:len(x) for k,x in data.items()},'original_detector_sha256':hashlib.sha256(source.encode()).hexdigest(),'python':platform.python_version()},indent=2))
