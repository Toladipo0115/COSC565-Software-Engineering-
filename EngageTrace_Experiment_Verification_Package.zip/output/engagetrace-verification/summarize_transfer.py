"""Summarize the separate modified-protocol transfer run; do not pool with original paper."""
import csv,collections,random,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
raw=list(csv.DictReader((ROOT/'output/icicip-paper/results/course_seed_results.csv').open()))
records=[]
for quiet in [2,4]:
 for method in ['fixed','raw_individual','log_individual','cusum','cap','no_persistence','no_individual']:
  for label,positive in [('positive',True),('negative',False)]:
   g=collections.defaultdict(list)
   for r in raw:
    if int(r['quiet_length'])!=quiet or r['method']!=method:continue
    if (r['scenario'] in ['sustained','decline_during_quiet'])!=positive:continue
    g[r['course']].append(float(r['alarm_rate']))
   means=[statistics.mean(v) for v in g.values()];rng=random.Random(1026)
   samples=sorted(statistics.mean(rng.choices(means,k=len(means))) for _ in range(10000))
   records.append(dict(quiet_length=quiet,method=method,scenario_group=label,course_mean=statistics.mean(means),lower_descriptive95=samples[250],upper_descriptive95=samples[9749],courses=len(means)))
with (OUT/'modified_transfer_summary.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
