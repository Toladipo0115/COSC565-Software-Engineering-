"""Recover saved development case identities and verify each sequence against source data.
This replays recorded cases; it does NOT reconstruct the historical sampling algorithm.
Outputs contain student IDs. Keep them private.
"""
import argparse,collections,csv,hashlib,json,sqlite3
from pathlib import Path

def inject(v,category):
 v=list(v)
 for w in (7,8):v[w-1]=round(v[w-1]*0.5)
 if category=='individual_sustained_decline':
  for w in range(12,21):v[w-1]=round(v[w-1]*0.25)
 elif category=='decline_during_quiet':
  for w in range(7,21):v[w-1]=round(v[w-1]*0.25)
 elif category=='temporary_dip_recovered':v[14]=round(v[14]*0.25)
 elif category not in ('no_change','course_wide_quiet_only'):raise ValueError(category)
 return v

def main():
 p=argparse.ArgumentParser();p.add_argument('--cohort',required=True);p.add_argument('--database',required=True);p.add_argument('--output',required=True);a=p.parse_args()
 c=json.loads(Path(a.cohort).read_text());rows=[];groups=collections.defaultdict(list)
 with sqlite3.connect('file:'+str(Path(a.database).resolve())+'?mode=ro',uri=True) as db:
  for order,(case,values) in enumerate(c['matrix'].items()):
   sid=case.split('__')[0];category=c['assignment'][case];candidates={}
   for course,w,clicks in db.execute('SELECT course_id,week,clicks FROM weekly_activity WHERE student_id=? AND week BETWEEN 1 AND 20',(sid,)):
    candidates.setdefault(course,[0]*20)[w-1]=clicks
   matches=[course for course,v in candidates.items() if inject(v,category)==values]
   assert len(matches)==1,(case,'not uniquely identified',matches)
   course=matches[0];groups[sid].append(category)
   rows.append(dict(case_order=order,case_id=case,source_student_id=sid,course_id=course,scenario=category,source_sequence_verified=True))
 out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
 with (out/'Recovered_Development_Assignments_PRIVATE.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 poscats={'individual_sustained_decline','decline_during_quiet'}
 pos={s for s,v in groups.items() if any(x in poscats for x in v)};neg={s for s,v in groups.items() if any(x not in poscats for x in v)}
 report=dict(saved_case_count=len(rows),unique_source_students=len(groups),source_courses=sorted({r['course_id'] for r in rows}),exact_sequence_matches=len(rows),unmatched_cases=0,ambiguous_cases=0,source_student_multiplicities=dict(collections.Counter(map(len,groups.values()))),positive_cases=sum(r['scenario'] in poscats for r in rows),control_cases=sum(r['scenario'] not in poscats for r in rows),unique_positive_students=len(pos),unique_control_students=len(neg),students_appearing_in_positive_and_control_scenarios=len(pos&neg),scenario_counts=dict(collections.Counter(r['scenario'] for r in rows)),original_cohort_sha256=hashlib.sha256(Path(a.cohort).read_bytes()).hexdigest(),selection_seed='not recovered',selection_eligibility_filters='not recovered',historical_sampling_driver='not recovered',interpretation='Exact recorded case membership, order and scenario assignments recovered; historical sampling provenance not recovered. Sequence matching uses the current source database.')
 (out/'Development_Recovery_Findings.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':main()
