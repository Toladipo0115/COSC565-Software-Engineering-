# Rebuilt EngageTrace SQLite database

This package rebuilds the supplied research database's courses, student-course memberships and weekly activity from the three OULAD CSVs. It includes `engagetrace.db`, the original `engagetrace_db.py` and `schema.sql`, a safe rebuild runner, and a verification manifest. No raw OULAD CSVs are bundled.

## Use

Extract the package. Read the database with SQLite, DB Browser for SQLite, or Python:

```python
from engagetrace_db import EngageTraceDB

db = EngageTraceDB('engagetrace.db')
print(db.conn.execute('SELECT COUNT(*) FROM weekly_activity').fetchone()[0])
matrix = db.get_course_matrix('CCC_2014J')
# Optional export for the existing dashboard:
db.export_course_json('CCC_2014J', 'CCC_2014J_export.json')
db.close()
```

Exported JSON can be selected through **Load course data** in the redesigned dashboard. The dashboard does not connect directly to this SQLite file.

## Rebuild

Python 3.11+; no third-party packages needed. Keep the three CSVs in one local directory, and run:

```sh
python rebuild_database.py --input-dir /path/to/OULAD --database /path/to/new/engagetrace.db
```

The runner refuses to overwrite an existing database. Do not call the legacy `ingest_oulad` repeatedly on an existing database: its conflict handling adds click counts. Keep the database and raw CSVs outside GitHub. Commit source, schema, and setup documentation on the appropriate user-story branch instead.

## What is and is not reconstructed

The generated database uses the original research schema, including `courses`, `students`, `weekly_activity`, `detection_runs` and `detection_flags`. Detection tables are initialized but empty. No detector experiments or saved results were reconstructed, so this database need not match the size of the previously reported 506 MB file. A matching file size is not a verification criterion.

The original importer uses one-based weeks (`floor(date / 7) + 1`) and excludes pre-course events. It does not implement the requirements' enrollment eligibility and coverage/missing-data rules. `get_course_matrix` zero-fills missing weeks under the original behavior. Those policies must be reconciled before research validation. Student outcomes are not read from studentInfo.csv; the legacy final_result column remains empty.

US-01's versioned staging database remains a separate application artifact. This rebuild does not automatically migrate data to that schema or implement a local API.

## Provenance

Source: the OULAD archive supplied by Tolulope Oladipo. Dataset attribution: Jakub Kuzilek, Martin Hlosta and Zdenek Zdrahal, Open University Learning Analytics Dataset; CC BY 4.0. See `engagetrace.manifest.json` for exact input hashes, counts, database checksum and checks performed. The provided importer and schema are preserved unchanged.

## Included dashboard example

Select CCC_2014J_rebuilt_export.json through Load course data in the dashboard. See Verification_Report.md for counts and limitations. This does not create a live database connection.
