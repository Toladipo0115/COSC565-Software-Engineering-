# EngageTrace Database Verification

Built for Tolulope Oladipo from the uploaded OULAD CSVs using the supplied research importer.

| Check | Result |
|---|---:|
| Course presentations | 22 |
| Student-course memberships | 32,593 |
| Unique student pseudonyms | 28,785 |
| Weekly activity records | 579,438 |
| Source VLE event rows | 10,655,280 |
| Excluded pre-course event rows | 688,988 |
| Retained click total | 37,457,152 |
| Per-course click totals match source | Passed |
| Distinct weekly keys match source | Passed |
| SQLite integrity check | ok |
| Foreign-key violations | 0 |
| Database size | 49,483,776 bytes |

The initial build failed verification and was not packaged. A fresh build was checked both before close and after reopen, then independently verified against source totals and distinct source weekly keys. Input checksums were unchanged before and after verification. Only the verified final database is included.

Detection tables are present but empty. No conference experiments were rerun. The database is approximately 49.5 MB, not the previously reported 506 MB; contents of the absent original database cannot be compared. The rebuilt file contains input activity, not a recreation of its saved run history.

The original importer's one-based week numbering, exclusion of pre-course activity, additive reimport behavior and unconditional matrix zero filling are documented limitations. This build does not establish enrollment-aware eligibility or coverage. These policies and the detector differences remain to be reconciled for the paper.

A CCC_2014J course export is included for manual dashboard loading: 2,498 students and 39 weeks. It reflects the legacy matrix behavior, not validated missing-data semantics.

Full checksums and per-course counts are in engagetrace.manifest.json.
