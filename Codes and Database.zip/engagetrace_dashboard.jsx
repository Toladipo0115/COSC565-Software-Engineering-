import React, { useMemo, useState, useEffect, useRef } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  ReferenceArea, BarChart, Bar, Legend,
} from "recharts";

// ---------- synthetic OULAD-style data generation ----------

function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const WEEKS = 20;
const QUIET_WEEKS = [9, 10];

const CATEGORY_META = {
  sustained_decline: { label: "Individual sustained decline", color: "#B8763B" },
  temporary: { label: "Temporary dip, recovered", color: "#3B7A78" },
  decline_during_quiet: { label: "Decline during course-wide quiet period", color: "#A63D40" },
  stable_low: { label: "Stable low activity", color: "#7A7368" },
  normal: { label: "Normal / no change", color: "#8B8B7A" },
};

function patternFactor(category, week) {
  if (category === "sustained_decline") return week < 12 ? 1 : 0.25;
  if (category === "temporary") return week >= 5 && week <= 6 ? 0.35 : 1;
  if (category === "decline_during_quiet") return week < 9 ? 1 : 0.25;
  return 1;
}

function quietFactor(week) {
  return QUIET_WEEKS.includes(week) ? 0.5 : 1;
}

function generateStudents() {
  const rng = mulberry32(20260903);
  const students = [];
  const plan = [
    ...Array(4).fill("sustained_decline"),
    ...Array(3).fill("temporary"),
    ...Array(2).fill("decline_during_quiet"),
    "stable_low",
    ...Array(14).fill("normal"),
  ];
  plan.forEach((category, idx) => {
    const baseline = category === "stable_low"
      ? 18 + rng() * 8
      : 45 + rng() * 110;
    const noiseSd = category === "stable_low" ? baseline * 0.08 : baseline * 0.15;
    const values = [];
    for (let w = 1; w <= WEEKS; w++) {
      const noise = (rng() - 0.5) * 2 * noiseSd;
      const v = baseline * quietFactor(w) * patternFactor(category, w) + noise;
      values.push(Math.max(0, Math.round(v)));
    }
    students.push({
      id: `S${String(idx + 1).padStart(2, "0")}`,
      category,
      baseline: Math.round(baseline),
      values,
    });
  });
  return students;
}

// ---------- statistics helpers ----------

function median(arr) {
  if (!arr.length) return 0;
  const s = [...arr].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

function mad(arr) {
  const m = median(arr);
  return median(arr.map((x) => Math.abs(x - m)));
}

// ---------- detection methods ----------

function computeDetections(students, params) {
  const { k, tauInd, tauCtx, p, fixedThreshold, tauIndLog = 0.2, lag = 3 } = params;
  const eps = 1e-6;
  const weeks = students[0] ? students[0].values.length : WEEKS;

  // raw-scale delta, used only by the 'individual' and 'fixed' baselines
  const deltas = students.map((s) =>
    s.values.map((v, i) => {
      const t = i + 1;
      if (t <= k) return null;
      const win = s.values.slice(i - k, i);
      const base = median(win);
      return (base - v) / (base + eps);
    })
  );

  // log-scale, lagged-window delta, used by CAP -- matches controlled_eval.py.
  // Real click counts are strongly right-skewed (an opening-week spike dominates),
  // which saturates a raw-scale signal across nearly the whole cohort; log1p tames
  // this. The lag avoids the trailing baseline "chasing" an ongoing decline.
  const logStudents = students.map((s) => s.values.map((v) => Math.log1p(Math.max(0, v))));
  const logDeltas = students.map((s, si) =>
    s.values.map((v, i) => {
      const t = i + 1;
      if (t <= k + lag) return null;
      const win = logStudents[si].slice(i - k - lag, i - lag);
      const base = median(win);
      return base - logStudents[si][i];
    })
  );

  // course-relative percentile rank of that week's log-decline (robust to a
  // tightly clustered cohort distribution, unlike a MAD-based z-score)
  const percentiles = students.map(() => Array(weeks).fill(null));
  for (let i = 0; i < weeks; i++) {
    const weekVals = [];
    students.forEach((_, si) => {
      const v = logDeltas[si][i];
      if (v !== null) weekVals.push({ si, v });
    });
    if (weekVals.length < 2) continue;
    const sorted = weekVals.map((x) => x.v).slice().sort((a, b) => a - b);
    weekVals.forEach(({ si, v }) => {
      const rank = sorted.filter((x) => x <= v).length;
      percentiles[si][i] = rank / sorted.length;
    });
  }

  const results = students.map(() => ({
    fixed: Array(weeks).fill(false),
    individual: Array(weeks).fill(false),
    cusum: Array(weeks).fill(false),
    cap: Array(weeks).fill(false),
  }));

  // fixed + individual (with persistence p)
  students.forEach((s, si) => {
    let fixedRun = 0, indRun = 0;
    for (let i = 0; i < weeks; i++) {
      const val = s.values[i];
      fixedRun = val < fixedThreshold ? fixedRun + 1 : 0;
      results[si].fixed[i] = fixedRun >= p;

      const d = deltas[si][i];
      indRun = d !== null && d >= tauInd ? indRun + 1 : 0;
      results[si].individual[i] = indRun >= p;
    }
  });

  // cusum
  students.forEach((s, si) => {
    const mu0 = median(s.values.slice(0, Math.min(k, s.values.length)));
    const slack = 0.25 * mu0;
    const H = 2 * mu0;
    let S = 0;
    for (let i = 0; i < weeks; i++) {
      S = Math.max(0, S + (mu0 - s.values[i]) - slack);
      results[si].cusum[i] = S > H && mu0 > 0;
    }
  });

  // CAP: log-scale individual deviation AND course-relative percentile AND persistence
  students.forEach((s, si) => {
    let run = 0;
    for (let i = 0; i < weeks; i++) {
      const ld = logDeltas[si][i];
      const z = percentiles[si][i];
      const cond = ld !== null && z !== null && ld >= tauIndLog && z >= tauCtx;
      run = cond ? run + 1 : 0;
      results[si].cap[i] = run >= p;
    }
  });

  return { deltas, results };
}

const METHODS = [
  { key: "fixed", label: "Fixed threshold", color: "#8B8B7A" },
  { key: "individual", label: "Individual-history only", color: "#3B7A78" },
  { key: "cusum", label: "Statistical change-point (CUSUM)", color: "#B8763B" },
  { key: "cap", label: "CAP (proposed)", color: "#A63D40" },
];

// ---------- UI ----------

async function fetchSupabaseCourse(url, anonKey, courseId) {
  const headers = { apikey: anonKey, Authorization: `Bearer ${anonKey}` };
  const base = url.replace(/\/$/, "");

  const actRes = await fetch(
    `${base}/rest/v1/weekly_activity?course_id=eq.${encodeURIComponent(courseId)}&select=student_id,week,clicks&order=student_id,week`,
    { headers }
  );
  if (!actRes.ok) throw new Error(`Supabase error (${actRes.status}): ${await actRes.text()}`);
  const activity = await actRes.json();
  if (!activity.length) throw new Error("No weekly_activity rows found for this course_id");

  const maxWeek = Math.max(...activity.map((r) => r.week));
  const byStudent = {};
  activity.forEach((r) => {
    if (!byStudent[r.student_id]) byStudent[r.student_id] = Array(maxWeek).fill(0);
    byStudent[r.student_id][r.week - 1] = r.clicks;
  });

  return {
    courseId,
    weeks: maxWeek,
    students: Object.entries(byStudent).map(([id, values]) => ({ id, values })),
  };
}

async function fetchSupabaseCourseList(url, anonKey) {
  const headers = { apikey: anonKey, Authorization: `Bearer ${anonKey}` };
  const base = url.replace(/\/$/, "");
  const res = await fetch(`${base}/rest/v1/courses?select=course_id`, { headers });
  if (!res.ok) throw new Error(`Supabase error (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows.map((r) => r.course_id);
}

function parseImportedCourse(json) {
  if (!json || !Array.isArray(json.students) || !json.weeks) {
    throw new Error("File must have { courseId, weeks, students: [{ id, values }] }");
  }
  return json.students.map((s) => ({
    id: String(s.id),
    category: "imported",
    baseline: Math.round(median(s.values || [])),
    values: (s.values || []).slice(0, json.weeks),
  }));
}

export default function EngageTraceDashboard() {
  const syntheticStudents = useMemo(() => generateStudents(), []);
  const [importedStudents, setImportedStudents] = useState(null);
  const [importedCourseId, setImportedCourseId] = useState(null);
  const [importError, setImportError] = useState(null);
  const students = importedStudents || syntheticStudents;
  const [tab, setTab] = useState("explorer");
  const [studentId, setStudentId] = useState(students[0].id);
  const [k, setK] = useState(3);
  const [tauInd, setTauInd] = useState(0.5);
  const [tauCtx, setTauCtx] = useState(0.6);
  const [tauIndLog, setTauIndLog] = useState(0.2);
  const [p, setP] = useState(3);
  const [fixedThreshold, setFixedThreshold] = useState(6);
  const [showLabels, setShowLabels] = useState(true);

  const fileInputRef = useRef(null);
  const [supabaseUrl, setSupabaseUrl] = useState("");
  const [supabaseAnonKey, setSupabaseAnonKey] = useState("");
  const [supabaseCourses, setSupabaseCourses] = useState([]);
  const [supabaseSelectedCourse, setSupabaseSelectedCourse] = useState("");
  const [supabaseStatus, setSupabaseStatus] = useState(null);
  const [supabaseLoading, setSupabaseLoading] = useState(false);

  async function handleSupabaseConnect() {
    setSupabaseStatus(null);
    setSupabaseLoading(true);
    try {
      const courses = await fetchSupabaseCourseList(supabaseUrl, supabaseAnonKey);
      setSupabaseCourses(courses);
      setSupabaseSelectedCourse(courses[0] || "");
      setSupabaseStatus(courses.length ? null : "Connected, but no courses found yet.");
    } catch (err) {
      setSupabaseCourses([]);
      setSupabaseStatus(err.message || "Could not connect to Supabase");
    } finally {
      setSupabaseLoading(false);
    }
  }

  async function handleSupabaseLoadCourse() {
    if (!supabaseSelectedCourse) return;
    setSupabaseStatus(null);
    setSupabaseLoading(true);
    try {
      const json = await fetchSupabaseCourse(supabaseUrl, supabaseAnonKey, supabaseSelectedCourse);
      const parsed = parseImportedCourse(json);
      if (!parsed.length) throw new Error("No students found for this course");
      setImportedStudents(parsed);
      setImportedCourseId(json.courseId);
      setImportError(null);
    } catch (err) {
      setSupabaseStatus(err.message || "Could not load this course");
    } finally {
      setSupabaseLoading(false);
    }
  }

  useEffect(() => {
    if (!students.find((s) => s.id === studentId)) {
      setStudentId(students[0].id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [students]);

  function handleFileChange(e) {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const json = JSON.parse(reader.result);
        const parsed = parseImportedCourse(json);
        if (!parsed.length) throw new Error("No students found in file");
        setImportedStudents(parsed);
        setImportedCourseId(json.courseId || file.name);
        setImportError(null);
      } catch (err) {
        setImportError(err.message || "Could not parse this file");
      }
    };
    reader.readAsText(file);
  }

  function resetToSynthetic() {
    setImportedStudents(null);
    setImportedCourseId(null);
    setImportError(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  const weeksCount = students[0] ? students[0].values.length : WEEKS;
  const params = { k, tauInd, tauCtx, p, fixedThreshold, tauIndLog, lag: 3 };
  const { deltas, results } = useMemo(
    () => computeDetections(students, params),
    [students, k, tauInd, tauCtx, p, fixedThreshold, tauIndLog]
  );

  const cohortMedianByWeek = useMemo(() => {
    const arr = [];
    for (let i = 0; i < weeksCount; i++) {
      arr.push(median(students.map((s) => s.values[i])));
    }
    return arr;
  }, [students, weeksCount]);

  const selectedIdx = Math.max(0, students.findIndex((s) => s.id === studentId));
  const selected = students[selectedIdx] || students[0];

  const chartData = useMemo(() => {
    return Array.from({ length: weeksCount }, (_, i) => ({
      week: i + 1,
      activity: selected.values[i],
      cohort: cohortMedianByWeek[i],
    }));
  }, [selected, cohortMedianByWeek, weeksCount]);

  const capFlags = results[selectedIdx].cap;
  const flaggedWeeks = chartData.filter((_, i) => capFlags[i]);

  // cohort summary stats
  const summary = useMemo(() => {
    const stats = {};
    METHODS.forEach((m) => {
      let total = 0, quietFalse = 0, truePos = 0;
      students.forEach((s, si) => {
        const flags = results[si][m.key];
        const isGenuine = s.category === "sustained_decline" || s.category === "decline_during_quiet";
        flags.forEach((f, i) => {
          if (!f) return;
          total += 1;
          const week = i + 1;
          if (QUIET_WEEKS.includes(week) && !isGenuine) quietFalse += 1;
          if (isGenuine) truePos += 1;
        });
      });
      stats[m.key] = { total, quietFalse, truePos };
    });
    return stats;
  }, [results, students]);

  const barData = METHODS.map((m) => ({
    name: m.label,
    "Total flagged weeks": summary[m.key].total,
    "False alerts in quiet period": summary[m.key].quietFalse,
  }));

  return (
    <div style={{ fontFamily: "var(--font-sans, ui-sans-serif, system-ui)", color: "var(--text-primary, #1E2A38)", background: "var(--surface-0, #EDEFEA)", padding: "1.5rem", borderRadius: 12 }}>
      <div style={{ marginBottom: "1.25rem" }}>
        <h1 style={{ fontFamily: "var(--font-voice, Georgia, serif)", fontSize: 22, fontWeight: 500, margin: 0 }}>
          EngageTrace
        </h1>
        <p style={{ fontSize: 14, color: "var(--text-secondary, #5B6B7A)", margin: "4px 0 0" }}>
          Course-context-aware detection of sustained LMS activity decline · demo dashboard on synthetic OULAD-style data
        </p>
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: "1.25rem", borderBottom: "0.5px solid var(--border, #D8DCD0)" }}>
        {[["explorer", "Student explorer"], ["summary", "Cohort summary"]].map(([key, label]) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            style={{
              padding: "8px 14px",
              border: "none",
              background: "none",
              borderBottom: tab === key ? "2px solid #A63D40" : "2px solid transparent",
              color: tab === key ? "#A63D40" : "var(--text-secondary, #5B6B7A)",
              fontWeight: 500,
              fontSize: 14,
              cursor: "pointer",
            }}
          >
            {label}
          </button>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "260px minmax(0, 1fr)", gap: "1.5rem" }}>
        <div>
          <div style={{ background: "#fff", border: "0.5px solid #D8DCD0", borderRadius: 12, padding: "1rem", marginBottom: "1rem" }}>
            <p style={{ fontSize: 13, fontWeight: 500, margin: "0 0 8px" }}>Data source</p>
            <p style={{ fontSize: 12, color: "var(--text-secondary, #5B6B7A)", margin: "0 0 8px" }}>
              {importedStudents
                ? `Imported: ${importedCourseId} (${importedStudents.length} students)`
                : "Synthetic demo data (24 students)"}
            </p>
            <input
              ref={fileInputRef}
              type="file"
              accept="application/json"
              onChange={handleFileChange}
              style={{ fontSize: 12, width: "100%" }}
            />
            {importError && (
              <p style={{ fontSize: 12, color: "#A63D40", margin: "6px 0 0" }}>{importError}</p>
            )}
            {importedStudents && (
              <button
                onClick={resetToSynthetic}
                style={{ marginTop: 8, fontSize: 12, padding: "4px 10px", borderRadius: 6, border: "0.5px solid #D8DCD0", background: "none", cursor: "pointer" }}
              >
                Reset to synthetic demo data
              </button>
            )}

            <div style={{ borderTop: "0.5px solid #D8DCD0", marginTop: 12, paddingTop: 12 }}>
              <p style={{ fontSize: 12, fontWeight: 500, margin: "0 0 6px" }}>Or connect to Supabase</p>
              <input
                type="text"
                placeholder="https://xxxx.supabase.co"
                value={supabaseUrl}
                onChange={(e) => setSupabaseUrl(e.target.value)}
                style={{ width: "100%", padding: "5px 8px", fontSize: 12, borderRadius: 6, border: "0.5px solid #D8DCD0", marginBottom: 6 }}
              />
              <input
                type="password"
                placeholder="anon public API key"
                value={supabaseAnonKey}
                onChange={(e) => setSupabaseAnonKey(e.target.value)}
                style={{ width: "100%", padding: "5px 8px", fontSize: 12, borderRadius: 6, border: "0.5px solid #D8DCD0", marginBottom: 6 }}
              />
              <button
                onClick={handleSupabaseConnect}
                disabled={supabaseLoading || !supabaseUrl || !supabaseAnonKey}
                style={{ fontSize: 12, padding: "4px 10px", borderRadius: 6, border: "0.5px solid #D8DCD0", background: "none", cursor: "pointer", width: "100%" }}
              >
                {supabaseLoading ? "Working…" : "Connect"}
              </button>
              {supabaseCourses.length > 0 && (
                <div style={{ marginTop: 8 }}>
                  <select
                    value={supabaseSelectedCourse}
                    onChange={(e) => setSupabaseSelectedCourse(e.target.value)}
                    style={{ width: "100%", padding: "5px 8px", fontSize: 12, borderRadius: 6, border: "0.5px solid #D8DCD0", marginBottom: 6 }}
                  >
                    {supabaseCourses.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                  <button
                    onClick={handleSupabaseLoadCourse}
                    disabled={supabaseLoading}
                    style={{ fontSize: 12, padding: "4px 10px", borderRadius: 6, border: "0.5px solid #A63D40", color: "#A63D40", background: "none", cursor: "pointer", width: "100%" }}
                  >
                    Load this course
                  </button>
                </div>
              )}
              {supabaseStatus && (
                <p style={{ fontSize: 12, color: "#A63D40", margin: "6px 0 0" }}>{supabaseStatus}</p>
              )}
              <p style={{ fontSize: 11, color: "var(--text-muted, #8B8B7A)", margin: "6px 0 0" }}>
                Use the public anon key only — this is read-only if row-level security is set up per
                supabase_schema.sql. Never paste the service role key here.
              </p>
            </div>
          </div>

          <div style={{ background: "#fff", border: "0.5px solid #D8DCD0", borderRadius: 12, padding: "1rem", marginBottom: "1rem" }}>
            <p style={{ fontSize: 13, fontWeight: 500, margin: "0 0 8px" }}>Student</p>
            <select
              value={studentId}
              onChange={(e) => setStudentId(e.target.value)}
              style={{ width: "100%", padding: "6px 8px", borderRadius: 6, border: "0.5px solid #D8DCD0" }}
            >
              {students.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.id}{showLabels && CATEGORY_META[s.category] ? ` — ${CATEGORY_META[s.category].label}` : ""}
                </option>
              ))}
            </select>
            <label style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 8, fontSize: 12, color: "var(--text-secondary, #5B6B7A)" }}>
              <input type="checkbox" checked={showLabels} onChange={(e) => setShowLabels(e.target.checked)} />
              Show scenario labels (demo mode)
            </label>
          </div>

          <div style={{ background: "#fff", border: "0.5px solid #D8DCD0", borderRadius: 12, padding: "1rem" }}>
            <p style={{ fontSize: 13, fontWeight: 500, margin: "0 0 12px" }}>CAP parameters</p>

            <SliderField label="Baseline window (k weeks)" value={k} min={2} max={6} step={1} onChange={setK} />
            <SliderField label="CAP individual-deviation threshold (log scale)" value={tauIndLog} min={0.1} max={0.8} step={0.05} onChange={setTauIndLog} format={(v) => v.toFixed(2)} />
            <SliderField label="CAP course-relative percentile threshold" value={tauCtx} min={0.3} max={0.95} step={0.05} onChange={setTauCtx} format={(v) => `${Math.round(v * 100)}%`} />
            <SliderField label="Persistence (p weeks)" value={p} min={1} max={4} step={1} onChange={setP} />
            <SliderField label="Individual-only baseline threshold (relative drop)" value={tauInd} min={0.2} max={0.8} step={0.05} onChange={setTauInd} format={(v) => v.toFixed(2)} />
            <SliderField label="Fixed rule threshold (clicks)" value={fixedThreshold} min={2} max={80} step={2} onChange={setFixedThreshold} />
          </div>
        </div>

        <div>
          {tab === "explorer" ? (
            <>
              <div style={{ background: "#fff", border: "0.5px solid #D8DCD0", borderRadius: 12, padding: "1rem", marginBottom: "1rem" }}>
                <p style={{ fontSize: 13, fontWeight: 500, margin: "0 0 8px" }}>
                  {selected.id} weekly activity vs. course cohort median
                </p>
                <div style={{ height: 260 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                      <CartesianGrid stroke="#E1E0D9" vertical={false} />
                      <ReferenceArea x1={9} x2={10} fill="#8B8B7A" fillOpacity={0.12} />
                      <XAxis dataKey="week" tick={{ fontSize: 12 }} label={{ value: "Week", position: "insideBottom", offset: -2, fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} label={{ value: "Clicks", angle: -90, position: "insideLeft", fontSize: 12 }} />
                      <Tooltip />
                      <Line type="monotone" dataKey="activity" name={selected.id} stroke="#B8763B" strokeWidth={2} dot={{ r: 2 }} />
                      <Line type="monotone" dataKey="cohort" name="Cohort median" stroke="#3B7A78" strokeWidth={2} strokeDasharray="4 3" dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div style={{ display: "flex", gap: 16, marginTop: 8, fontSize: 12, color: "var(--text-secondary, #5B6B7A)" }}>
                  <LegendDot color="#B8763B" label={`${selected.id} activity`} />
                  <LegendDot color="#3B7A78" label="Cohort median" dashed />
                  <LegendDot color="#8B8B7A" label="Shared quiet period (wk 9–10)" swatch />
                </div>
                {flaggedWeeks.length > 0 ? (
                  <p style={{ fontSize: 13, marginTop: 10, color: "#A63D40" }}>
                    CAP flags sustained decline at week{flaggedWeeks.length > 1 ? "s" : ""}{" "}
                    {flaggedWeeks.map((f) => f.week).join(", ")}.
                  </p>
                ) : (
                  <p style={{ fontSize: 13, marginTop: 10, color: "var(--text-secondary, #5B6B7A)" }}>
                    CAP does not flag this student under the current thresholds.
                  </p>
                )}
              </div>

              <div style={{ background: "#fff", border: "0.5px solid #D8DCD0", borderRadius: 12, padding: "1rem" }}>
                <p style={{ fontSize: 13, fontWeight: 500, margin: "0 0 10px" }}>Method comparison — {selected.id}</p>
                <MethodStrip results={results[selectedIdx]} weeksCount={weeksCount} />
              </div>
            </>
          ) : (
            <>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0,1fr))", gap: 12, marginBottom: "1rem" }}>
                {METHODS.map((m) => (
                  <div key={m.key} style={{ background: "var(--surface-1, #F3F4EE)", borderRadius: 12, padding: "1rem" }}>
                    <p style={{ fontSize: 12, color: "var(--text-secondary, #5B6B7A)", margin: 0 }}>{m.label}</p>
                    <p style={{ fontSize: 22, fontWeight: 500, margin: "4px 0" }}>{summary[m.key].total}</p>
                    <p style={{ fontSize: 12, color: "#A63D40", margin: 0 }}>
                      {summary[m.key].quietFalse} false alerts during shared quiet period
                    </p>
                    <p style={{ fontSize: 12, color: "#3B7A78", margin: 0 }}>
                      {importedStudents
                        ? "Ground truth unavailable for real unlabeled data"
                        : `${summary[m.key].truePos} flags on genuinely declining students`}
                    </p>
                  </div>
                ))}
              </div>

              <div style={{ background: "#fff", border: "0.5px solid #D8DCD0", borderRadius: 12, padding: "1rem" }}>
                <p style={{ fontSize: 13, fontWeight: 500, margin: "0 0 8px" }}>Flagged student-weeks by method, across all 24 students</p>
                <div style={{ height: 260 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={barData} margin={{ top: 5, right: 10, left: 0, bottom: 40 }}>
                      <CartesianGrid stroke="#E1E0D9" vertical={false} />
                      <XAxis dataKey="name" tick={{ fontSize: 11 }} angle={-15} textAnchor="end" interval={0} height={60} />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Legend wrapperStyle={{ fontSize: 12 }} />
                      <Bar dataKey="Total flagged weeks" fill="#8B8B7A" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="False alerts in quiet period" fill="#A63D40" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <p style={{ fontSize: 12, color: "var(--text-secondary, #5B6B7A)", marginTop: 10 }}>
                  {importedStudents
                    ? "\"False alerts in quiet period\" assumes weeks 9\u201310 are a shared lull — this is a synthetic-data assumption and may not reflect a real course calendar. Check the individual timelines to identify your course's own quiet weeks."
                    : "Weeks 9\u201310 are a shared course-wide quiet period. A false alert here means the method flagged a student whose activity dropped only because the whole course slowed down, not because of an individual decline."}
                </p>
              </div>
            </>
          )}
        </div>
      </div>

      <p style={{ fontSize: 11, color: "var(--text-muted, #8B8B7A)", marginTop: "1.5rem" }}>
        {importedStudents
          ? `Running on imported data: ${importedCourseId}. Detection is computed live in the browser from the imported weekly activity — nothing is sent anywhere.`
          : "Data shown is synthetic, generated to match OULAD's weekly VLE-click structure and the five evaluation scenarios in the study design. Use \"Data source\" above to load a course exported from engagetrace_db.py's export_course_json()."}
      </p>
    </div>
  );
}

function SliderField({ label, value, min, max, step, onChange, format }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "var(--text-secondary, #5B6B7A)" }}>
        <span>{label}</span>
        <span style={{ fontWeight: 500, color: "var(--text-primary, #1E2A38)" }}>
          {format ? format(value) : value}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        style={{ width: "100%" }}
      />
    </div>
  );
}

function LegendDot({ color, label, dashed, swatch }) {
  return (
    <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
      {swatch ? (
        <span style={{ width: 12, height: 8, background: color, opacity: 0.3, display: "inline-block" }} />
      ) : (
        <span style={{ width: 14, height: dashed ? 0 : 2, borderTop: `2px ${dashed ? "dashed" : "solid"} ${color}`, display: "inline-block" }} />
      )}
      {label}
    </span>
  );
}

function MethodStrip({ results, weeksCount }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      {METHODS.map((m) => (
        <div key={m.key} style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 12, width: 190, flexShrink: 0, color: "var(--text-secondary, #5B6B7A)" }}>{m.label}</span>
          <div style={{ display: "flex", gap: 2, flexWrap: "wrap" }}>
            {Array.from({ length: weeksCount }, (_, i) => (
              <div
                key={i}
                title={`Week ${i + 1}`}
                style={{
                  width: 16,
                  height: 16,
                  borderRadius: 3,
                  background: results[m.key][i] ? m.color : "#E1E0D9",
                }}
              />
            ))}
          </div>
        </div>
      ))}
      <div style={{ display: "flex", gap: 10, marginTop: 2 }}>
        <span style={{ width: 190, flexShrink: 0 }} />
        <div style={{ display: "flex", gap: 2, flexWrap: "wrap" }}>
          {Array.from({ length: weeksCount }, (_, i) => (
            <div key={i} style={{ width: 16, fontSize: 9, textAlign: "center", color: "var(--text-muted, #8B8B7A)" }}>
              {i + 1}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
