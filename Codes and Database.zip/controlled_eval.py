"""
Controlled evaluation for EngageTrace.

Takes real student weekly-activity sequences (as behavioral/noise substrate)
and injects the five known change patterns from the study design at
controlled weeks, giving ground truth to score CAP and the three baselines
against: detection rate, false-positive rate, detection delay, and
localization error.
"""

import random
import statistics
import json

WEEKS = 20
QUIET_WEEKS = (7, 8)            # shared course-wide quiet period, applied to everyone
SUSTAINED_ONSET = 12            # individual_sustained_decline starts here, clear of quiet period
TEMP_DIP_WEEK = 15              # temporary_dip_recovered: single-week dip here
DURING_QUIET_ONSET = 7          # decline_during_quiet starts exactly when the quiet period starts

CATEGORIES = [
    "no_change",
    "individual_sustained_decline",
    "temporary_dip_recovered",
    "course_wide_quiet_only",
    "decline_during_quiet",
]
# ground truth: which categories should trigger a "sustained individual decline" flag
POSITIVE_CATEGORIES = {"individual_sustained_decline", "decline_during_quiet"}
TRUE_ONSET = {
    "individual_sustained_decline": SUSTAINED_ONSET,
    "decline_during_quiet": DURING_QUIET_ONSET,
}


def _median(values):
    values = list(values)
    return statistics.median(values) if values else 0.0


def _mad(values):
    values = list(values)
    m = _median(values)
    return _median([abs(v - m) for v in values])


def apply_quiet_period(values):
    out = list(values)
    for w in QUIET_WEEKS:
        out[w - 1] = round(out[w - 1] * 0.5)
    return out


def inject_pattern(real_values, category):
    """real_values: a real student's weekly clicks, length >= WEEKS.
    Returns a length-WEEKS sequence with the category's pattern injected."""
    base = list(real_values[:WEEKS])
    base = apply_quiet_period(base)  # every course has this shared background dip

    if category == "no_change":
        pass
    elif category == "individual_sustained_decline":
        for w in range(SUSTAINED_ONSET, WEEKS + 1):
            base[w - 1] = round(base[w - 1] * 0.25)
    elif category == "temporary_dip_recovered":
        base[TEMP_DIP_WEEK - 1] = round(base[TEMP_DIP_WEEK - 1] * 0.25)  # single week only
    elif category == "course_wide_quiet_only":
        pass  # already has the shared quiet dip, nothing individual added
    elif category == "decline_during_quiet":
        for w in range(DURING_QUIET_ONSET, WEEKS + 1):
            base[w - 1] = round(base[w - 1] * 0.25)
    return base


def compute_flags(matrix, k, tau_ind, tau_ctx, p, fixed_threshold, tau_ind_log=0.4, log_transform=True):
    """matrix: {student_id: [clicks_week1, ...]} -> per-method per-student per-week flags.

    Individual and CAP methods work on log1p(clicks) rather than raw clicks. Real
    LMS click counts are extremely right-skewed (a handful of huge-activity weeks
    dominate), which saturates a raw-scale relative-drop signal across nearly the
    whole cohort and destroys its ability to discriminate. The log transform makes
    "drop by half" comparable whether a student goes from 200->100 clicks or 10->5.

    CAP's course-context condition uses a cohort PERCENTILE RANK of that week's
    log-decline, not a z-score. A MAD-based z-score assumes the cohort's declines
    are unimodal and not too tightly clustered; on real data they cluster hard
    (most students decline somewhat every week), which collapses MAD near zero and
    makes z-scores meaningless. Percentile rank has no such assumption -- "top decile
    of declines this week" is well-defined even when everyone is declining somewhat.
    tau_ctx is therefore a percentile in [0, 1], e.g. 0.9 = top 10% steepest decline
    in the cohort that week.
    """
    student_ids = list(matrix.keys())
    weeks = len(next(iter(matrix.values())))
    LAG = 3

    def transform(v):
        return __import__("math").log1p(v) if log_transform else v

    log_matrix = {sid: [transform(v) for v in matrix[sid]] for sid in student_ids}

    deltas = {sid: [None] * weeks for sid in student_ids}       # raw-scale, for the 'individual' baseline
    log_deltas = {sid: [None] * weeks for sid in student_ids}   # log-scale, for CAP
    for sid in student_ids:
        vals = matrix[sid]
        lvals = log_matrix[sid]
        for i in range(weeks):
            if i + 1 <= k + LAG:
                continue
            window = vals[i - k - LAG:i - LAG]
            base = _median(window)
            deltas[sid][i] = (base - vals[i]) / (base + 1e-6)

            lwindow = lvals[i - k - LAG:i - LAG]
            lbase = _median(lwindow)
            log_deltas[sid][i] = lbase - lvals[i]  # log-ratio decline, unbounded, comparable across scales

    percentiles = {sid: [None] * weeks for sid in student_ids}
    for i in range(weeks):
        week_ld = {sid: log_deltas[sid][i] for sid in student_ids if log_deltas[sid][i] is not None}
        if len(week_ld) < 2:
            continue
        sorted_vals = sorted(week_ld.values())
        n = len(sorted_vals)
        for sid, v in week_ld.items():
            rank = sum(1 for x in sorted_vals if x <= v)
            percentiles[sid][i] = rank / n

    flags = {sid: {"fixed": [False] * weeks, "individual": [False] * weeks,
                    "cusum": [False] * weeks, "cap": [False] * weeks,
                    "cap_no_context": [False] * weeks,
                    "cap_no_persistence": [False] * weeks,
                    "cap_no_individual": [False] * weeks}
             for sid in student_ids}

    for sid in student_ids:
        vals = matrix[sid]
        fixed_run = ind_run = cap_run = ctx_run = indiv_run = 0
        mu0 = _median(vals[:min(k, weeks)])
        slack = 0.25 * mu0
        H = 2 * mu0
        S = 0.0
        for i in range(weeks):
            fixed_run = fixed_run + 1 if vals[i] < fixed_threshold else 0
            flags[sid]["fixed"][i] = fixed_run >= p

            d = deltas[sid][i]
            ind_run = ind_run + 1 if (d is not None and d >= tau_ind) else 0
            flags[sid]["individual"][i] = ind_run >= p

            S = max(0.0, S + (mu0 - vals[i]) - slack)
            flags[sid]["cusum"][i] = bool(S > H and mu0 > 0)

            z = percentiles[sid][i]
            ld = log_deltas[sid][i]

            # full CAP: individual deviation AND context AND persistence
            cond_full = ld is not None and z is not None and ld >= tau_ind_log and z >= tau_ctx
            cap_run = cap_run + 1 if cond_full else 0
            flags[sid]["cap"][i] = cap_run >= p

            # ablation 1: drop the course-context condition (individual + persistence only)
            cond_no_ctx = ld is not None and ld >= tau_ind_log
            ctx_run = ctx_run + 1 if cond_no_ctx else 0
            flags[sid]["cap_no_context"][i] = ctx_run >= p

            # ablation 2: drop persistence -- full CAP condition but single-week trigger
            flags[sid]["cap_no_persistence"][i] = cond_full

            # ablation 3: drop the individual-deviation condition (context + persistence only)
            cond_no_ind = z is not None and z >= tau_ctx
            indiv_run = indiv_run + 1 if cond_no_ind else 0
            flags[sid]["cap_no_individual"][i] = indiv_run >= p

    return flags


ABLATION_METHODS = ("cap", "cap_no_context", "cap_no_persistence", "cap_no_individual")
ABLATION_LABELS = {
    "cap": "Full CAP",
    "cap_no_context": "CAP without course context",
    "cap_no_persistence": "CAP without persistence",
    "cap_no_individual": "CAP without individual deviation",
}


def run_controlled_evaluation(matrix, categories_by_student, k=3, tau_ind=0.5,
                                tau_ctx=0.9, p=2, fixed_threshold=6, tau_ind_log=0.4, seed=None):
    flags = compute_flags(matrix, k, tau_ind, tau_ctx, p, fixed_threshold, tau_ind_log=tau_ind_log)
    methods = ("fixed", "individual", "cusum", "cap", "cap_no_context", "cap_no_persistence", "cap_no_individual")
    results = {m: {"tp": 0, "fn": 0, "fp": 0, "tn": 0, "delays": [], "localization_errors": []}
               for m in methods}

    for sid, category in categories_by_student.items():
        is_positive = category in POSITIVE_CATEGORIES
        student_flags = flags[sid]
        for m in methods:
            flagged_weeks = [w + 1 for w, f in enumerate(student_flags[m]) if f]
            was_flagged = len(flagged_weeks) > 0
            if is_positive:
                if was_flagged:
                    results[m]["tp"] += 1
                    onset = TRUE_ONSET[category]
                    first_flag = min(flagged_weeks)
                    results[m]["delays"].append(max(0, first_flag - onset))
                    results[m]["localization_errors"].append(abs(first_flag - onset))
                else:
                    results[m]["fn"] += 1
            else:
                if was_flagged:
                    results[m]["fp"] += 1
                else:
                    results[m]["tn"] += 1

    summary = {}
    for m in methods:
        r = results[m]
        n_pos = r["tp"] + r["fn"]
        n_neg = r["fp"] + r["tn"]
        summary[m] = {
            "detection_rate": round(r["tp"] / n_pos, 3) if n_pos else None,
            "false_positive_rate": round(r["fp"] / n_neg, 3) if n_neg else None,
            "mean_delay_weeks": round(statistics.mean(r["delays"]), 2) if r["delays"] else None,
            "mean_localization_error_weeks": round(statistics.mean(r["localization_errors"]), 2) if r["localization_errors"] else None,
            "n_true_positive_cases": n_pos,
            "n_true_negative_cases": n_neg,
            "tp": r["tp"], "fn": r["fn"], "fp": r["fp"], "tn": r["tn"],
        }
    return summary
