# EngageTrace revision record

## Status

The Chp manuscript has been revised as an exploratory research draft. It is not yet a submission-ready empirical paper. No experiments were rerun, no held-out data were evaluated, and the source code and raw result files were not available in the attachments. The source manuscripts remain unchanged.

## Changes completed

- Clarified the research contribution and removed claims that the present evidence establishes general superiority or deployment readiness.
- Distinguished student-course records from distinct people across presentations.
- Distinguished real-course student-week alert volumes from scenario-level fractions flagged.
- Corrected the sensitivity differences: 73.3% versus 76.7% is approximately 3.3 percentage points; 76.7% versus 78.3% is approximately 1.7 points.
- Replaced claims about false positives specifically during quiet weeks with scenario-level descriptions; temporal scoring intervals were not supplied.
- Corrected no_change: all groups receive the shared event, so it means no additional individual decline.
- Explained that the context statistic ranks historical deviations; the plotted course median is a separate visualization.
- Removed the ambiguous baseline endpoints from the displayed expression, using an explicit historical index set instead. This avoids endorsing the k-versus-k+1 ambiguity, but the exact set still requires code verification.
- Removed the internally inconsistent ablation tables and the component-attribution claims they supported. Their original numbers are preserved below.
- Omitted delay and localization-error columns because their scoring and matching rules were not defined. The original values are preserved below.
- Removed the unsupported real-data case-study claims and dashboard screenshots. A supplied screenshot labels its shared event as a synthetic approximation and displays a 24-student summary, while the prose describes 150 real students. It cannot substantiate that narrative without source verification.
- Replaced screenshots with two charts generated directly from the supplied result tables: real-course CAP/fixed flag ratios and CAP/fixed scenario proportions. These charts are not new experiments.
- Corrected prior-work positioning: Al Doulat and Maher use cohort-relative anomaly detection algorithmically, rather than only for visualization.
- Added Park et al. (2017) and Shimada et al. (2018) as closely related individual clickstream change-detection studies.
- Removed uncited original references [2-5], [18], [19], [22], and [33], and removed placeholder [32]. Renumbered the remaining citations in order of first appearance; the manuscript now has 32 references with no orphan entries or missing citation targets.
- Corrected Nakamura's third author to I. Horikoshi and added article number 31. Added confirmed DOIs to selected references.
- Applied US Letter, two-column body text, 10-point Times New Roman, and no page numbering. Wide tables and plots occupy full-width pages to preserve readability. Author names and affiliations must be supplied before submission.

## Required scientific checks before submission

1. Supply the Python detection and evaluation code, preprocessing scripts, dataset selection, environment/dependency versions, seed values, parameter-search logs, and saved student-week outputs.
2. Reconcile individual-only with CAP without context. Under equivalent definitions and identical settings, they should return the same flags. The supplied summaries differ substantially; disclose any distinct formula or parameter settings and rerun consistently.
3. Resolve the baseline window: the original inclusive endpoints t-k-L through t-L contain k+1 observations. Confirm whether k means sample count or index span, then restore an exact equation and rerun if necessary. A lag does not by itself guarantee exclusion of opening-week activity.
4. Specify cohort inclusion/exclusion, ties, empty cohorts, missing observations, minimum history, the week-index convention, enrollment eligibility, pre-course events, and incomplete weeks.
5. Specify every baseline's settings, including fixed-threshold calibration and inequality, individual-history scale, and CUSUM reference period, allowance, threshold, initialization, and reset behavior.
6. Define a common scoring protocol. State the positive interval, how flags before onset are treated, the detection horizon, and the event-matching rules for delay and localization error. A two-week lull with p=3 cannot alone establish three consecutive qualifying weeks; inspect surrounding activity and detector state.
7. Separate development from final evaluation. Freeze all parameters and scenario generation choices on development data; evaluate once on a separate cohort/course. Do not describe this planned analysis as completed.
8. Repeat across additional courses and seeds; report confidence intervals using units that respect student/course dependence. Consider a stronger neighboring change-detection comparator.
9. Verify parity between browser and Python outputs on identical data and configurations. Replace the screenshots only with a verified artifact matching the text, or retain the current table-derived plots.
10. Independently reproduce the retained tables. Their arithmetic can be checked from summaries, but their empirical provenance cannot be established from DOCX files alone.
11. Complete a publisher-level audit of all retained references and claim support. This revision checked selected primary sources, not the full text of every cited article.
12. Add authors and affiliations; verify the conference's latest submission instructions, review anonymity rules if any, submission deadline, and the final author-approved PDF.

## Targeted reference checks

Primary publisher or institutional records were consulted for the following corrections and additions. These checks do not imply that every reference in the manuscript was independently verified.

- ICICIP submission instructions: https://conference.cs.cityu.edu.hk/icicip/web_submission.htm
- Nakamura et al. (2024), author list, article number, and PELT result: https://doi.org/10.1186/s40561-024-00317-6
- Al Doulat and Maher (2023), algorithmic cohort comparison and metadata: https://library.iated.org/view/ALDOULAT2023ANO
- Fazil et al. (2024), publication metadata and DOI: https://learning-analytics.info/index.php/JLA/article/view/7985
- Lee et al. (2025), publication record: https://learning-analytics.info/index.php/JLA/article/view/8375
- Dai et al. (2025), publication metadata and abstract: https://learning-analytics.info/index.php/JLA/article/view/8735
- Matcha et al. (2020), method summary and metadata: https://learning-analytics.info/index.php/JLA/article/view/7008
- Park et al. (2017), author publication listing: https://ics.uci.edu/~jihyunp/
- Shimada et al. (2018), institutional record and abstract: https://kyushu-u.elsevierpure.com/en/publications/online-change-detection-for-monitoring-individual-student-behavio/

## Original values withheld pending verification

These tables preserve the original manuscript values. They are not validated or newly generated experimental results.

### Timing values removed from the main table

| Method | Mean delay (weeks) | Mean localization error (weeks) |
| --- | --- | --- |
| Fixed | 2.94 | 3.28 |
| Individual-only | 1.76 | 2.18 |
| CUSUM | 1.08 | 2.65 |
| CAP | 2.98 | 3.14 |


### Original aggregate ablation table

| Variant | Detection rate | False-positive rate | Gap (detection - FP rate) |
| --- | --- | --- | --- |
| Full CAP | 0.750 | 0.372 | 0.378 |
| CAP without course context | 0.950 | 0.817 | 0.133 |
| CAP without persistence | 1.000 | 0.983 | 0.017 |
| CAP without individual deviation | 0.850 | 0.483 | 0.367 |


### Original scenario ablation table

| Category | Full CAP | No context | No persistence | No individual |
| --- | --- | --- | --- | --- |
| no_change | 0.367 | 0.800 | 0.950 | 0.467 |
| course_wide_quiet_only | 0.267 | 0.750 | 1.000 | 0.367 |
| individual_sustained_decline | 0.733 | 0.950 | 1.000 | 0.850 |
| temporary_dip_recovered | 0.483 | 0.900 | 1.000 | 0.617 |
| decline_during_quiet | 0.767 | 0.950 | 1.000 | 0.850 |

### Original dashboard claims removed

The source prose reports 150 students, 480 CAP flags, 2,566 fixed-rule flags, and 2,935 CUSUM flags, with quiet-period counts of 42, 108, and 116, respectively. These claims are preserved here solely for reconciliation. The supplied screenshot also displays a 24-student summary and describes a synthetic quiet-period approximation. The featured student's claimed flag weeks and a live-computation claim likewise require source verification.
