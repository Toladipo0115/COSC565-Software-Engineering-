-- EngageTrace schema for Supabase (Postgres).
-- Paste this into the Supabase SQL editor (Project -> SQL Editor -> New query) and run it.

CREATE TABLE IF NOT EXISTS courses (
    course_id           TEXT PRIMARY KEY,
    module               TEXT NOT NULL,
    presentation          TEXT NOT NULL,
    length_days            INTEGER
);

CREATE TABLE IF NOT EXISTS students (
    student_id           TEXT NOT NULL,
    course_id             TEXT NOT NULL REFERENCES courses(course_id),
    final_result           TEXT,
    PRIMARY KEY (student_id, course_id)
);

CREATE TABLE IF NOT EXISTS weekly_activity (
    student_id            TEXT NOT NULL,
    course_id              TEXT NOT NULL,
    week                     INTEGER NOT NULL,
    clicks                   INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (student_id, course_id, week),
    FOREIGN KEY (student_id, course_id) REFERENCES students(student_id, course_id)
);

CREATE TABLE IF NOT EXISTS detection_runs (
    run_id                 BIGSERIAL PRIMARY KEY,
    course_id               TEXT NOT NULL REFERENCES courses(course_id),
    created_at               TIMESTAMPTZ NOT NULL DEFAULT now(),
    baseline_window_k        INTEGER NOT NULL,
    tau_individual             REAL NOT NULL,
    tau_context                 REAL NOT NULL,
    persistence_p                 INTEGER NOT NULL,
    fixed_threshold                REAL NOT NULL,
    notes                          TEXT
);

CREATE TABLE IF NOT EXISTS detection_flags (
    run_id                  BIGINT NOT NULL REFERENCES detection_runs(run_id),
    student_id               TEXT NOT NULL,
    week                       INTEGER NOT NULL,
    method                      TEXT NOT NULL CHECK (method IN ('fixed','individual','cusum','cap')),
    flagged                      BOOLEAN NOT NULL,
    delta_individual              REAL,
    z_context                       REAL,
    PRIMARY KEY (run_id, student_id, week, method)
);

CREATE INDEX IF NOT EXISTS idx_activity_course_week ON weekly_activity(course_id, week);
CREATE INDEX IF NOT EXISTS idx_flags_run_method ON detection_flags(run_id, method);

-- Row-level security: the browser dashboard uses the public "anon" key and
-- should only ever be able to SELECT. Writes (ingestion, detection runs) go
-- through engagetrace_db_pg.py using the service role / direct connection
-- string, which bypasses RLS entirely -- do not put that connection string
-- or the service role key in any browser-facing code.

ALTER TABLE courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE weekly_activity ENABLE ROW LEVEL SECURITY;
ALTER TABLE detection_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE detection_flags ENABLE ROW LEVEL SECURITY;

CREATE POLICY "public read courses" ON courses FOR SELECT USING (true);
CREATE POLICY "public read students" ON students FOR SELECT USING (true);
CREATE POLICY "public read weekly_activity" ON weekly_activity FOR SELECT USING (true);
CREATE POLICY "public read detection_runs" ON detection_runs FOR SELECT USING (true);
CREATE POLICY "public read detection_flags" ON detection_flags FOR SELECT USING (true);

-- Note: no INSERT/UPDATE/DELETE policies are created for the anon role,
-- so the public key can only ever read. This is intentional.
