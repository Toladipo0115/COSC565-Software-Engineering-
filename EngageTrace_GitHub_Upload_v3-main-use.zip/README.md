# EngageTrace: course-context-aware detection of sustained LMS activity declines

Code, protocol, aggregate results and manuscript for the EngageTrace / CAP study (Open University Learning Analytics Dataset).

## Contents
- `original-frozen-validation/` the original frozen test: generator `run_validation.py`, detectors, protocol and its hash, and aggregate results (`summary.csv`, per presentation rates, paired differences, checks, run manifest). The student level files that `run_validation.py` writes (`assignments.csv`, `case_results.csv`) are generated locally and are not published.
- `analysis-scripts/` scripts and JSON results behind the manuscript tables and figures (frozen comparison, matched alert rates, shared lulls, sensitivity, withdrawal anchor). Set `ENGAGETRACE_DB`, `ENGAGETRACE_REG` and `ENGAGETRACE_VALIDATION_CODE` before running; see `README_original.md`.
- `dashboard`: the EngageTrace dashboard (Fig. 6) is `EngageTrace_Dashboard_Checked.html` in the existing repository.
- `paper/` reviewed manuscript (Word and PDF).
- `extension-experiments/` additional analyses run after the frozen test: injection robustness (28 conditions), threshold calibration, sampling stability (11 seeds) and the corrected withdrawal analysis. Includes the dated protocol with its SHA-256, runnable scripts, aggregate results, figures and a report. See its `README.md` for exact commands.
- `docs/` provenance of the original 300 case development cohort, and the independent manuscript review.

## Status of the analyses
The additional analyses were specified after the frozen test had been examined. They are not untouched confirmation. Control flag rate is not a false positive rate. Seeds measure sampling variability within the same eight presentations, not external validity.

## Data not included
The database and OULAD `studentRegistration.csv` are not in this repository, and no student level file is published. OULAD is available from the Open University (Kuzilek et al., 2017). Student level assignment files that the scripts write are created locally in `private_do_not_publish/`, which is git-ignored.

## Reproduce
```
pip install -r extension-experiments/requirements.txt
export ET_DB=/path/to/engagetrace.db
export ET_REG=/path/to/studentRegistration.csv
cd extension-experiments/code && python3 verify_original.py
```
