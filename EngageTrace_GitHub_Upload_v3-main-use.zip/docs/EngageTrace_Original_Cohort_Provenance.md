# Provenance of controlled_eval_cohort.json (original 300 student development cohort)

Sources inspected: the repository archive "Codes and Database.zip" (members dated 2026-10-15 08:20), the verification package, the validation package, the frozen-test package, my earlier session outputs, the saved conversation transcript, and the CCC_2014J export and OULAD database. Hashes (SHA-256): controlled_eval_cohort.json d1fabbe9...2acb361, controlled_eval.py 06fc393f...ed2d1f, CCC_2014J_export.json 647f0205...d430.

## A. Recovered evidence (read directly from saved files)
1. The file holds 300 entries, each keyed `studentID__scenario__position`, so the student IDs, their order, and the scenario assignment are all recorded. The student list is in the private CSV `original_cohort_recovered_PRIVATE.csv`, not in this report.
2. Scenario assignment: positions 0 to 59 no_change, 60 to 119 course_wide_quiet_only, 120 to 179 individual_sustained_decline, 180 to 239 temporary_dip_recovered, 240 to 299 decline_during_quiet. Order inside each block is not sorted.
3. Course: all 300 students belong to CCC_2014J. All 283 distinct IDs are in CCC_2014J_export.json.
4. The 300 sequences are post-injection. Applying the injection rules in controlled_eval.py (weeks 7 and 8 halved for everyone, onset 12 or 7 multiplied by 0.25, one-week dip in week 15) to the real weekly clicks reproduces all 300 sequences exactly, from both the database and the export (300 of 300 each).
5. Within each scenario block the 60 IDs are distinct. Across blocks 17 IDs recur, leaving 283 distinct students.
6. All 300 were registered by day 0 and all have nonzero clicks in weeks 1 to 20.
7. The earlier verification report (Experiment_Verification_Report.md, line 72) states that the original cohort selection and seed were not archived. My search found no script, log, notebook, or message that does.

## B. Inferences from the recovered data (not recorded; each is a statistical observation)
1. No early-withdrawal exclusion was applied: 38 of the 300 have an unregistration date and 16 of those withdrew before day 140. This differs from the frozen test, which excludes them.
2. The sample was probably not drawn uniformly from all active students. Every one of the 300 has at least 10 nonzero weeks and at least 131 total clicks in weeks 1 to 20, whereas only about 65 percent of the 2,215 active students have 10 or more nonzero weeks. Some activity filter likely existed, but its form and threshold cannot be identified from the data.
3. The 17 repeated IDs across blocks match independent draws of 60 per scenario from a pool of roughly 1,400 to 2,200 students (about 17 to 23 repeats expected). This is consistent with, but does not prove, five independent per-scenario samples.

## C. Not recovered
The sampling seed, the sampling function, the exact eligibility filter, the pool and its ordering, and the date the cohort was drawn. No search of the available archives found them.

## D. Seed search (a test of a hypothesis, not a recovery)
I tested whether any simple sampler reproduces the first scenario block exactly (60 IDs in the recorded order): random.Random(seed).sample and shuffle-then-take-60, seeds 0 to 3,000 plus 11 other round values, over 48 candidate pools (export order, sorted string, sorted integer, crossed with several activity filters). There were no matches. This is a bounded negative result and does not show the seed is outside the search. No seed is claimed.

## E. What can and cannot be said
- It can be said that the original 300 student list, order, and scenario assignment are recovered from the saved file, and that the sequences are verified injections of the real CCC_2014J traces.
- It cannot be said that the selection procedure, seed, or eligibility rules were recovered, and a newly sampled cohort does not reproduce the original selection.
- Suggested manuscript wording: "The original 300-student development cohort is preserved as a saved file (CCC_2014J; student order and scenario assignments recorded), and its sequences reproduce exactly from the database. The sampling seed and eligibility rule used to draw it were not archived. The replacement development samples are a different procedure."
- Student IDs in the private CSV should not go to public GitHub.
