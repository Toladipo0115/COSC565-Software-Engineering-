# Before you upload: clean the existing repository

Repository: github.com/Toladipo0115/COSC565-Software-Engineering- (public).

This upload contains no database, no registration file, and no student identifiers (every file was scanned against the 7,732 student IDs known from the private files).

Existing repository files that conflict with the rule "no database or student level exports on public GitHub":
1. `Codes and Database.zip` contains `controlled_eval_cohort.json` (student IDs in its keys) and the CCC_2014J export with 2,498 student IDs.
2. `EngageTrace_Experiment_Verification_Package.zip` contains the same cohort file.
3. `EngageTrace_Rebuilt_Database.zip` is a database.
4. `EngageTrace_Validation_Package.zip` and the frozen test package may contain `assignments.csv` (sampled student IDs).

Suggested steps: check each archive, remove or replace the ones above, and note that deleting a file does not remove it from git history. If the IDs must leave the history, rewrite it with `git filter-repo` or recreate the repository, then upload this package.
OULAD student IDs are pseudonymous, but the rule you set is that student level files stay private.
