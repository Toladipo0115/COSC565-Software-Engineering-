# Frozen validation on previously unevaluated presentations

## Scope and separation

The protocol was written and SHA-256 hashed before computing new detector outcomes. It reuses the frozen revised detector and comparator definitions. The eight presentations were absent from the available archived EngageTrace detection evaluations; all their raw records had already been ingested. Same modules and OULAD had informed development and other projects, so this is not external or globally untouched data.

Exclude all students enrolled in the fourteen previously evaluated presentations, not only those sampled earlier. Retrospective eligibility requires registration by day 0, no withdrawal before day 140, and positive recorded activity during the first 140 days. This selects stable enrollments using future information and is not an online population. Cross-course duplicates among eligible test records are removed, keeping the lexicographically first eligible presentation.

There are 7,642 distinct eligible students after deduplication. A single fixed seed samples 300 per presentation, resulting in 2,400 distinct evaluated students, 960 positive scenarios and 1,440 controls. All eight methods, two/four-week lulls, and both declared scoring windows are reported. No resampling, retuning, or outcome-based exclusions were performed.

## Declared outcomes

Primary scoring counts any flag from the scenario start to week 20; six-week scoring is the declared sensitivity check. Earlier alarms use all preceding weeks. Strict detection requires no earlier alarm at all; new episodes require a false-to-true transition within the window.

| Lull | Method | Primary positive | Primary control | Six-week positive | Six-week control |
|---|---|---:|---:|---:|---:|
| 2 weeks | Fixed | 0.706 | 0.482 | 0.609 | 0.416 |
| 2 weeks | Raw history | 0.729 | 0.383 | 0.689 | 0.310 |
| 2 weeks | CUSUM | 0.879 | 0.742 | 0.858 | 0.676 |
| 2 weeks | CAP | 0.696 | 0.370 | 0.621 | 0.252 |
| 2 weeks | No context | 0.810 | 0.549 | 0.772 | 0.458 |
| 2 weeks | No persistence | 0.932 | 0.861 | 0.915 | 0.797 |
| 2 weeks | No individual | 0.797 | 0.498 | 0.643 | 0.312 |
| 2 weeks | Park Poisson adaptation | 0.892 | 0.655 | 0.823 | 0.610 |
| 4 weeks | Fixed | 0.717 | 0.487 | 0.645 | 0.431 |
| 4 weeks | Raw history | 0.701 | 0.377 | 0.667 | 0.319 |
| 4 weeks | CUSUM | 0.881 | 0.767 | 0.864 | 0.723 |
| 4 weeks | CAP | 0.674 | 0.346 | 0.597 | 0.233 |
| 4 weeks | No context | 0.797 | 0.518 | 0.765 | 0.446 |
| 4 weeks | No persistence | 0.928 | 0.856 | 0.906 | 0.796 |
| 4 weeks | No individual | 0.842 | 0.549 | 0.663 | 0.357 |
| 4 weeks | Park Poisson adaptation | 0.882 | 0.653 | 0.810 | 0.603 |

For a two-week lull, primary CAP detections are 668/960 and control flags 533/1,440; fixed has 678/960 and 694/1,440. Within six weeks, CAP has 596/960 and 363/1,440; fixed has 585/960 and 599/1,440. Thus direction and size of detection differences depend on the window. With four-week lulls, primary CAP has 647/960 detections versus fixed 688/960, with 498/1,440 versus 701/1,440 control flags.

## Descriptive uncertainty

Eight presentation means receive equal weight; the archived summary includes 10,000-resample descriptive course-bootstrap intervals. These do not establish causal effects, institutional transfer, or equivalence. Same-course dependence and only eight presentations limit inference.

Supplementary paired course-bootstrap differences for two-week lulls and six-week windows are +0.011 for positive detection (descriptive 95% −0.096 to +0.121) and −0.164 for control flags (−0.229 to −0.098). These are additional descriptive summaries, not a prospectively registered superiority test. No blanket superiority is claimed.

## Reproducibility

protocol.json and protocol.sha256 record the fixed protocol and checksum. run_manifest.json records source/data hashes and exclusions. assignments.csv preserves sampling; case_results.csv preserves 76,800 method/window/case records; summary.csv and course_seed_results.csv include all eight methods. Repeated windows and lull lengths are paired evaluations of the same 2,400 students, not independent new cases.

## Remaining limits

Outcome labels describe injected modifications, not verified disengagement or academic risk. Natural declines remain in controls. Stable-enrollment eligibility uses future status, and the same modules/dataset informed prior work. The Park comparator is a weekly-prefix Poisson adaptation, not the authors original software or experiment. External data, operational review costs, fairness, and intervention outcomes remain unvalidated.
