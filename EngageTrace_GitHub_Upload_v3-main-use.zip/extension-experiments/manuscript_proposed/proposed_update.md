---
title: "EngageTrace: proposed manuscript update (patch to EngageTrace_ICICIP_Corrected.docx)"
---

This file is a separate patch. It does not replace the corrected manuscript. Each block says where it goes. The new material needs about one and a quarter two-column pages, so the manuscript must free that space (suggested: merge Tables V and VI, shorten the related-work paragraph, and keep only Fig. 1 and Fig. 4 of the extension). Check the page count in Word against the limit of 10 pages.

# 1. Add to Evaluation Sets, after the sentence on lull-free runs

The additional analyses reported below were specified in a dated protocol (2026-10-16, SHA-256 c454b5c0...b7ad2a5) saved before any extension outcome was computed. They were run after the frozen test had been examined. They are additional analyses, not untouched confirmation.

# 2. New section: Additional Analyses After the Frozen Test

**Injection robustness.** The same 2,400 sampled students and assignments were rerun with individual multipliers d of 0.10, 0.25, 0.50, and 0.75 and with no lull or lulls of two and four weeks at shared multipliers 0.25, 0.50, and 0.75, which gives 28 conditions (no-lull runs are not repeated across lull multipliers). The original injection order and rounding were kept; the rerun reproduces all 192 archived summary values (maximum difference 1.1e-16). Detection of all methods falls as d rises from 0.10 to 0.75, to about 0.5 for the fixed rule, raw history, and CAP. Against the no-context ablation, CUSUM, and the Poisson adaptation, CAP has lower control flag rates and lower detection in all 28 conditions. Against raw history and the fixed rule, CAP's control flag rate is lower mainly under the longest, deepest lull (four weeks, multiplier 0.25), by 0.07 and 0.18 to 0.20, at a detection cost of 0.04 to 0.10 against raw history. In other conditions CAP and raw history differ by less than about 0.06.

**Sampling stability.** The robustness analysis was repeated with ten further seeds (20261101 to 20261110). At d = 0.25 and a two-week lull of 0.5, the median detection and control flag rate over the 11 seeds were 0.68 and 0.39 for CAP, 0.74 and 0.41 for raw history, and 0.72 and 0.48 for the fixed rule; seed ranges were about 0.03 for detection and 0.04 for control flag rate. A direction was called consistent only if it held for the original seed and for at least nine of eleven seeds, with at least seven of eight presentations agreeing, in both scoring windows. CAP versus raw history is consistent in control flag rate only in the four four-week, 0.25 conditions and in detection in three conditions, in both cases with CAP lower. No condition supports a CAP advantage in detection. Seeds resample students within the same eight presentations, so they measure sampling variability, not external validity, and are not treated as independent observations.

**Thresholds chosen on development samples.** Thresholds for each method were chosen on replacement development samples (six development presentations, five seeds, 30 samples) at control flag budgets of 0.10, 0.20, and 0.30, frozen, and applied to the frozen presentations (Table XI). Achieved test rates are reported without interpolation. These presentations had already been examined. Several budgets were not attainable inside the prespecified grids (the fixed rule at all budgets), and some selected settings lie at a grid edge. Test control flag rates differ among methods and exceed the budget for CAP at 0.30 (0.317), so the comparison does not establish an ordering. The original development selection procedure cannot be recovered by these replacement samples.

**TABLE XI. DEVELOPMENT-SELECTED SETTINGS ON THE FROZEN PRESENTATIONS (TWO-WEEK LULL, d = 0.25, PRIMARY WINDOW)**

| Budget | Method | Dev det/ctrl | Test detection | Test control flag rate |
|---|---|---|---|---|
| 0.20 | Raw history | 0.436/0.200 | 0.434 | 0.177 |
| 0.20 | No context | 0.425/0.182 | 0.429 | 0.156 |
| 0.20 | CAP | 0.393/0.187 | 0.483 | 0.214 |
| 0.30 | Raw history | 0.603/0.276 | 0.630 | 0.255 |
| 0.30 | No context | 0.604/0.281 | 0.615 | 0.265 |
| 0.30 | CAP | 0.570/0.293 | 0.663 | 0.317 |

**Withdrawal, corrected.** Weekly eligibility uses only information available at week t: registration by day 0, no unregistration before day 7t, and at least one nonzero click in weeks 1 to t. Withdrawn students are removed from later cohort ranks, flags use weeks 1 to t, and prediction weeks are 9 to 16 so that a four-week horizon is observed. Withdrawal is an exploratory outcome distinct from disengagement. Over all 22 presentations (4-week horizon) CAP has sensitivity 0.18, precision 0.046, 10.9 alerts per 100 eligible students, and lift 1.68 over a base rate of 0.026, with lift above one in 21 of 22 presentations. The fixed rule has sensitivity 0.45 and lift 1.96 at 23.7 alerts per 100. CAP's advantage is lower alert volume, not higher precision. Among students eligible at week 9, CAP flagged 46% of withdrawers and 42% of students who never withdrew. Student-weeks repeat the same students, so counts are not independent observations.

![CAP minus raw history and fixed rule across the 28 injection conditions (original seed).](fig1_cap_minus_comparators.png){width=100%}

![Withdrawal metrics at a four-week horizon.](fig4_withdrawal.png){width=100%}

# 3. Replace in Table X

Replace the row "Single injection strength" with: "Injection shape fixed | Strength (0.10 to 0.75) and shared lull (0.25 to 0.75, 0 to 4 weeks) varied after the frozen test | Other shapes (gradual, partial) untested". Add a row: "Repeated seeds | Sampling variability within the same eight presentations | Not external validity". Replace "Retrospective withdrawal sample" handling with: "Corrected weekly eligibility and cohort; exploratory association".

# 4. Replace in Abstract and Conclusion

Suggested sentence for the abstract: "Additional analyses run after the frozen test show that CAP is a more conservative detector than context-free, CUSUM, and Poisson comparators, and lowers control flags relative to raw history only under long, deep shared lulls; superiority is not established."

Suggested sentence for the conclusion: "Across 28 injection conditions and 11 seeds, CAP's differences from raw history and the fixed rule were small and mostly not consistent, so we claim a more conservative alert volume and not superior detection."

# 5. Claims that should not be made

- Do not describe the extension as untouched confirmation or as external validation.
- Do not report control flag rate as a false positive rate.
- Do not claim superiority of CAP over raw history or the fixed rule.
- Do not claim that the missing original development selection was recovered.
