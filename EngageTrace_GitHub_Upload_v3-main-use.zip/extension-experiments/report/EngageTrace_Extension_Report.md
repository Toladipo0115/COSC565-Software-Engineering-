# EngageTrace extension analyses: report

Protocol: `protocol/protocol.json`, dated 2026-10-16, SHA-256 c454b5c0d2e3c6537420059d5aa135007e056715f8617f8a5b13f8a10b7ad2a5, saved before any extension outcome was computed. The original frozen files are untouched (`vendor/SHA256SUMS.txt`; the archived generator hash 87b4482a...1495b1968 is unchanged).

**Status of these analyses.** Every analysis below was run after the frozen test had been examined. They are additional analyses, not untouched confirmation. The extension reproduces all 192 values of the original `summary.csv` (largest absolute difference 1.1e-16) and its vectorized detectors have zero mismatches against the canonical detectors in 144,000 cells per method for all six methods (`code/test_equivalence.py`).

## 1. Injection robustness (original seed 20261015, archived assignments)

Design: individual multiplier d in {0.10, 0.25, 0.50, 0.75}; seven lull conditions (no lull once, then 2 or 4 weeks times shared multiplier 0.25, 0.50, 0.75), 28 conditions. The same students are paired across all conditions; the original injection order and Python rounding are kept. The same d scales the temporary dip, so no_change and quiet_only control rates are also reported separately in `results/exp1_summary.csv`.

Findings that hold:
- Under the original setting (d=0.25, 2 week lull x0.5) CAP detects 0.70 with control flag rate 0.37, raw history 0.73/0.38, fixed rule 0.71/0.48, no-context 0.81/0.55, CUSUM 0.88/0.74, Poisson 0.89/0.65.
- CAP flags fewer control students than the no-context ablation, CUSUM and the Poisson adaptation in every condition, and also detects less (CAP is the more conservative detector; no-context, CUSUM and Poisson trade a higher control flag rate for higher detection).
- The CAP versus raw-history gap is small: detection differs by -0.06 to +0.01 and control flag rate by -0.07 to +0.03 depending on condition.
- CAP has the lowest control flag rate against raw history and the fixed rule where the shared lull is longest and deepest (4 weeks, x0.25): -0.07 versus raw history and -0.18 to -0.20 versus fixed. The detection cost there versus raw history is 0.04 to 0.10.
- All methods lose detection as d rises from 0.10 to 0.75 (about 0.5 for fixed, raw history and CAP at d=0.75), because a larger multiplier means a milder decline, which is harder to separate from natural variation. Duration and strength were tested, so the earlier limitation "single injection strength" can be narrowed to "fixed injection shape".

Findings that change: any wording that CAP reduces control alarms under shared lulls is supported against raw history and the fixed rule only in the 4 week x0.25 lull. In other conditions the point differences against raw history are within about 0.03.

## 2. Fair threshold comparison (development-only selection)

Thresholds chosen on replacement development samples (six development presentations, seeds 101, 202, 303, 404, 505; 30 units; d=0.25, 2 week lull x0.5; primary window) at control flag budgets 0.10, 0.20, 0.30, then frozen and run on the archived frozen assignments. Achieved test rates are reported; no interpolation, no equalization.

| Budget | Method | Setting | Dev det/ctrl | Test det/ctrl (q=2) | q=0 | q=4 |
|---|---|---|---|---|---|---|
| 0.10 | CAP | tau_ind 0.2, tau_ctx 0.9 | 0.075/0.053 | 0.096/0.053 | 0.093/0.058 | 0.092/0.056 |
| 0.20 | raw history | tau 0.85 | 0.436/0.200 | 0.434/0.177 | 0.428/0.192 | 0.454/0.178 |
| 0.20 | no-context | tau_ind 1.5 | 0.425/0.182 | 0.429/0.156 | 0.438/0.173 | 0.424/0.169 |
| 0.20 | CAP | 0.75, 0.7 | 0.393/0.187 | 0.483/0.214 | 0.510/0.219 | 0.467/0.198 |
| 0.30 | raw history | tau 0.7 | 0.603/0.276 | 0.630/0.255 | 0.657/0.274 | 0.601/0.271 |
| 0.30 | no-context | tau_ind 1.0 | 0.604/0.281 | 0.615/0.265 | 0.648/0.280 | 0.596/0.276 |
| 0.30 | CAP | 0.5, 0.6 | 0.570/0.293 | 0.663/0.317 | 0.685/0.342 | 0.622/0.287 |
| 0.30 | CUSUM | H 8 | 0.494/0.207 | 0.529/0.229 | 0.479/0.197 | 0.580/0.248 |
| 0.30 | Poisson | c 32 | 0.408/0.213 | 0.369/0.179 | 0.395/0.195 | 0.360/0.167 |

Not attainable inside the prespecified grids: fixed rule at every budget (lowest development control flag rate 0.333); raw history, no-context, CUSUM, Poisson at 0.10; CUSUM and Poisson at 0.20. Several selected settings sit at a grid edge (no-context 1.5, CUSUM H=8, Poisson c=32), so those comparators may have been restricted by the prespecified grid; the grids were not widened after seeing results.

What this shows: the CAP settings reach higher test detection than raw history at budgets 0.20 and 0.30 but also have higher achieved test control flag rates (0.214 vs 0.177 and 0.317 vs 0.255), above the budget at 0.30. Because test rates differ, no ordering of methods is supported. CAP is the only family that reaches the 0.10 budget, with very low detection (about 0.10).

## 3. Sampling stability (11 seeds: 20261015 plus 20261101 to 20261110)

Seeds, students and conditions are not independent observations. Results are reported by presentation and as spread over seeds; no pooled p-values. Base condition medians (range over seeds), primary window:

| Method | Detection | Control flag rate |
|---|---|---|
| Fixed | 0.719 (0.691 to 0.733) | 0.480 (0.458 to 0.507) |
| Raw history | 0.742 (0.722 to 0.755) | 0.411 (0.383 to 0.419) |
| CAP | 0.682 (0.673 to 0.698) | 0.388 (0.370 to 0.415) |
| No context | 0.820 (0.799 to 0.829) | 0.574 (0.549 to 0.595) |
| CUSUM | 0.890 (0.872 to 0.901) | 0.742 (0.718 to 0.760) |
| Poisson | 0.901 (0.883 to 0.915) | 0.650 (0.630 to 0.672) |

Per-presentation standard deviation across seeds is 0.02 to 0.05 for detection. Direction rule (original seed plus at least 9 of 11 seeds with at least 7 of 8 presentations the same way, both windows):
- CAP has lower detection and lower control flag rate than no-context, CUSUM, Poisson and the no-persistence ablation in all 28 conditions.
- CAP versus raw history passes the rule for control flag rate only in the four 4 week x0.25 conditions (CAP lower) and for detection in 3 conditions (CAP lower).
- CAP versus fixed passes for control flag rate in the same four conditions and for detection in one.
- No condition supports "CAP higher" for detection or control flag rate in either direction against any comparator. Superiority is not claimed.

## 4. Withdrawal (exploratory, distinct from disengagement)

Weekly eligibility at week t: registered by day 0, not unregistered before day 7t, at least one nonzero click in weeks 1 to t. Cohort ranks use only students eligible that week, and withdrawn students leave later cohorts. Flags use weeks 1 to t only. Prediction weeks 9 to 16; outcome is unregistration in days 7t to 7(t+H)-1 (H=4 primary, 2 sensitivity); blank unregistration is not withdrawn; weeks end at 16 so the outcome window is observed by week 20. The masked detector equals the unmasked one when everyone is eligible (asserted in the script).

| Scope, H=4 | Method | Sensitivity | Precision | Alerts per 100 eligible | Base rate | Lift | Presentations with lift above 1 |
|---|---|---|---|---|---|---|---|
| 22 presentations | CAP | 0.184 | 0.046 | 10.9 | 0.026 | 1.68 | 21 of 22 |
| | Raw history | 0.231 | 0.044 | 14.2 | 0.026 | 1.60 | 20 of 22 |
| | No context | 0.300 | 0.034 | 23.3 | 0.026 | 1.26 | 18 of 22 |
| | Fixed | 0.451 | 0.051 | 23.7 | 0.026 | 1.96 | 22 of 22 |
| Frozen 8 | CAP | 0.224 | 0.062 | 11.3 | 0.032 | 1.97 | 8 of 8 |
| | Raw history | 0.255 | 0.062 | 13.0 | 0.032 | 1.95 | 8 of 8 |
| | No context | 0.343 | 0.047 | 23.1 | 0.032 | 1.49 | 8 of 8 |
| | Fixed | 0.367 | 0.056 | 20.6 | 0.032 | 1.77 | 8 of 8 |

The 2 week horizon gives the same ordering (frozen 8: CAP lift 2.23, raw history 2.16, fixed 1.96, no context 1.61). Student-level, among students eligible at week 9: CAP flagged 46% of withdrawers (n=1,938) and 42% of students who never withdrew (n=21,728), so repeated student-level flagging barely separates the groups.

What changed from the earlier run: the old run removed students using zero activity over 39 weeks (future information) and kept withdrawn students in the ranks. The new analysis uses only information available at each week; CAP's lift is 1.68 to 1.97 (old 1.46), sensitivity 0.18 to 0.22 (old 0.17), and the old run's pattern that non-withdrawers were flagged more than withdrawers (0.78 vs 0.66) is no longer present (0.42 vs 0.46). The figures are not directly comparable because horizon and outcome windows differ. The fixed rule has similar or higher precision and lift at about twice the alert volume; the CAP advantage is lower volume, not higher precision.

## 5. Interpretation

- "Control flag rate" is the fraction of control students flagged in the scoring window. Controls include natural declines, so it is not a false positive rate.
- Supported: CAP is a more conservative detector than no-context, CUSUM and Poisson in every tested condition; CAP reduces control flags against raw history and the fixed rule where the shared lull is longest and deepest, at some detection cost; withdrawal alerts have lift above the base rate in most presentations.
- Not supported: superiority over raw history or the fixed rule; a calibrated deployable threshold; any claim that withdrawal prediction works; external validity.
- Multiple seeds measure sampling variability inside the same eight presentations, not generalization. The original development selection procedure is still unrecoverable; replacement development samples show what a clean procedure would pick, not what was done.

## Files

See `README.md`. Student-level files are only in `private_do_not_publish/` and must not go to public GitHub.
