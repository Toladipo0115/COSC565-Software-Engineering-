"""Experiment 4: exploratory withdrawal analysis with weekly eligibility and withdrawn students removed from cohort ranks.
Run: python3 withdrawal.py   (needs ET_DB, ET_REG). Writes results/exp4_withdrawal.json/.csv"""
import sqlite3, json, csv, math
import numpy as np
from common import *
from fastdet import feats, persist, ge, f_fixed, f_raw, f_noctx, f_cap

check_protocol_hash()
P4 = PROTO['experiment_4_withdrawal']
PRED = list(range(9, 17)); HORIZ = (4, 2); WK = 16

def masked_flags(F, E, method, p=3, ti=0.2, tc=0.6, tr=0.5, th=6):
    """E[i,w] True if student i is in cohort E_t at week w+1. Ranks use only E members; persistence resets when ineligible."""
    n, W = E.shape; ld = F['ld']
    if method == 'cap' or method == 'cap_no_context':
        cond = ge(ld, ti) & E
        if method == 'cap':
            rank = np.full(ld.shape, np.nan)
            for t in range(W):
                v = E[:, t] & ~np.isnan(ld[:, t])
                if not v.any(): continue
                col = np.sort(ld[v, t]); rank[:, t] = np.searchsorted(col, ld[:, t], side='right') / v.sum()
            cond = cond & ge(rank, tc)
    elif method == 'individual': cond = ge(F['rd'], tr) & E
    elif method == 'fixed': cond = (F['M'] < th) & E
    return persist(cond, p)

def load_all():
    regs = {}; 
    for r in csv.DictReader(open(REG)):
        if r['date_registration'] in ('', '?') or int(r['date_registration']) > 0: continue
        un = None if r['date_unregistration'] in ('', '?') else int(r['date_unregistration'])
        regs.setdefault(r['code_module'] + '_' + r['code_presentation'], {})[r['id_student']] = un
    acts = {}
    with sqlite3.connect(f'file:{Path(DB).resolve()}?mode=ro', uri=True) as con:
        for c, sid, w, x in con.execute(f'SELECT course_id,student_id,week,clicks FROM weekly_activity WHERE week BETWEEN 1 AND {WK}'):
            if c in regs and sid in regs[c]:
                acts.setdefault(c, {}).setdefault(sid, [0] * WK)[w - 1] = x
    return regs, acts

def analyse_course(reg, act, methods):
    ids = sorted(s for s in reg if s in act)
    M = np.array([act[s] for s in ids], dtype=float); un = np.array([np.nan if reg[s] is None else reg[s] for s in ids])
    F = feats(M); cum = np.cumsum(M, axis=1) > 0
    E = np.zeros(M.shape, dtype=bool)
    for w in range(WK):
        t = w + 1; E[:, w] = cum[:, w] & (np.isnan(un) | (un >= 7 * t))
    out = {}
    for m in methods:
        fl = masked_flags(F, E, m)
        res = {}
        for H in HORIZ:
            tp = fp = fn = tn = 0
            for t in PRED:
                el = E[:, t - 1]; y = el & ~np.isnan(un) & (un >= 7 * t) & (un <= 7 * (t + H) - 1); f = fl[:, t - 1] & el
                tp += int((f & y).sum()); fp += int((f & ~y).sum()); fn += int((~f & y).sum()); tn += int((~f & el & ~y).sum())
            n = tp + fp + fn + tn; res[f'H{H}'] = dict(tp=tp, fp=fp, fn=fn, tn=tn, student_weeks=n)
        # student level: eligible at week 9; flagged at least once weeks 9..min(withdrawal week-1,16)
        e9 = E[:, 8]; wk = np.where(np.isnan(un), 99, np.floor(np.nan_to_num(un) / 7) + 1)
        grp = {'withdrew_days63_139': e9 & ~np.isnan(un) & (un <= 139), 'never_withdrew': e9 & np.isnan(un)}
        sl = {}
        for g, mask in grp.items():
            hit = 0; nn = 0
            for i in np.where(mask)[0]:
                last = int(min(wk[i] - 1, WK)); 
                if last < 9: last = 9
                hit += int(fl[i, 8:last].any()); nn += 1
            sl[g] = dict(n=nn, flagged_at_least_once=hit)
        res['student_level'] = sl; res['eligible_week9'] = int(e9.sum())
        out[m] = res
    return out, dict(students=len(ids), eligible_week9=int(E[:, 8].sum()), eligible_week16=int(E[:, 15].sum()))

def metrics(c):
    tp, fp, fn, tn = c['tp'], c['fp'], c['fn'], c['tn']; n = tp + fp + fn + tn
    sens = tp / (tp + fn) if tp + fn else float('nan'); prec = tp / (tp + fp) if tp + fp else float('nan')
    base = (tp + fn) / n if n else float('nan')
    return dict(sensitivity=sens, precision=prec, alerts_per_100_eligible=100 * (tp + fp) / n, base_rate=base, lift=prec / base if base and prec == prec else float('nan'), student_weeks=n, positives=tp + fn)

def main():
    methods = ['cap', 'cap_no_context', 'individual', 'fixed']
    # equivalence test: mask all True must reproduce canonical flags
    data, _ = frozen_pools(); c0 = sorted(data)[0]; ids = sorted(data[c0])[:400]
    M = np.array([data[c0][s] for s in ids], dtype=float); F = feats(M); E = np.ones(M.shape, dtype=bool)
    for m, ref in (('cap', f_cap(F)), ('cap_no_context', f_noctx(F)), ('individual', f_raw(F)), ('fixed', f_fixed(F))):
        assert (masked_flags(F, E, m) == ref).all(), m
    print('masked detector equals unmasked detector when all students are eligible: OK')
    regs, acts = load_all(); per = {}; sizes = {}
    for c in sorted(regs):
        if c not in acts: continue
        per[c], sizes[c] = analyse_course(regs[c], acts[c], methods)
    frozen = set(FROZEN)
    summary = {}
    for scope, courses in (('all_22', sorted(per)), ('frozen_8', sorted(frozen & set(per)))):
        summary[scope] = {}
        for m in methods:
            summary[scope][m] = {}
            for H in HORIZ:
                rows = [metrics(per[c][m][f'H{H}']) for c in courses]
                eq = {k: float(np.nanmean([r[k] for r in rows])) for k in rows[0] if k not in ('student_weeks', 'positives')}
                spread = {k + '_min_max': [float(np.nanmin([r[k] for r in rows])), float(np.nanmax([r[k] for r in rows]))] for k in ('sensitivity', 'precision', 'lift')}
                summary[scope][m][f'H{H}'] = dict(presentations=len(courses), equal_weight=eq, spread_over_presentations=spread,
                    pooled=metrics({k: sum(per[c][m][f'H{H}'][k] for c in courses) for k in ('tp', 'fp', 'fn', 'tn')}),
                    presentations_with_lift_gt_1=int(sum(r['lift'] > 1 for r in rows)))
            sl = {g: dict(n=sum(per[c][m]['student_level'][g]['n'] for c in courses), hit=sum(per[c][m]['student_level'][g]['flagged_at_least_once'] for c in courses)) for g in ('withdrew_days63_139', 'never_withdrew')}
            summary[scope][m]['student_level'] = {g: dict(v, share=v['hit'] / v['n']) for g, v in sl.items()}
    (ROOT / 'results' / 'exp4_withdrawal.json').write_text(json.dumps(dict(protocol_sha256=(ROOT / 'protocol' / 'protocol.sha256').read_text().split()[0],
        caveat='Exploratory. Withdrawal is distinct from disengagement. Student-weeks repeat students; presentation spread is descriptive only.', sizes=sizes, summary=summary, per_presentation=per), indent=1))
    with open(ROOT / 'results' / 'exp4_withdrawal_by_presentation.csv', 'w', newline='') as f:
        w = csv.writer(f); w.writerow(['course', 'frozen', 'method', 'horizon', 'sensitivity', 'precision', 'alerts_per_100_eligible', 'base_rate', 'lift', 'student_weeks', 'positives'])
        for c in sorted(per):
            for m in methods:
                for H in HORIZ:
                    r = metrics(per[c][m][f'H{H}']); w.writerow([c, int(c in frozen), m, H] + [round(r[k], 5) for k in ('sensitivity', 'precision', 'alerts_per_100_eligible', 'base_rate', 'lift')] + [r['student_weeks'], r['positives']])
    for scope in summary:
        print(scope)
        for m in methods:
            e = summary[scope][m]['H4']['equal_weight']; s = summary[scope][m]['student_level']
            print(f"  {m:<15} H4 sens {e['sensitivity']:.3f} prec {e['precision']:.3f} alerts/100 {e['alerts_per_100_eligible']:.1f} base {e['base_rate']:.3f} lift {e['lift']:.2f} lift>1 in {summary[scope][m]['H4']['presentations_with_lift_gt_1']}/{summary[scope][m]['H4']['presentations']} | student flagged: wd {s['withdrew_days63_139']['share']:.2f} (n={s['withdrew_days63_139']['n']}) never {s['never_withdrew']['share']:.2f} (n={s['never_withdrew']['n']})")
main()
