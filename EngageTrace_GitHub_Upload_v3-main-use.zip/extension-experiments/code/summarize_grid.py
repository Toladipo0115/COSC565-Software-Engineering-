"""Experiment 1 and 3 summaries from the per-scenario count files."""
from analysis import *
ORIGS = PROTO['experiment_3_seeds']['plus_original_seed']; NEW = PROTO['experiment_3_seeds']['seeds']; ALL = [ORIGS] + NEW
MET = METHODS; LABEL = {'individual': 'raw_history'}
rows = load_grid(ALL); pr = presentation_rates(course_table(rows))
conds = condition_list(); courses = sorted(FROZEN)
def ck(seed, d, q, s, m, w): return (seed, d, q, s, m, w)
def pres_vals(seed, d, q, s, m, w, g, idx):
    return [pr[ck(seed, d, q, s, m, w) + (c,)][g][idx] for c in courses]
METRICS = {'detection': ('pos', 0), 'ctrl_flag': ('ctrl', 0), 'ctrl_flag_stable': ('ctrl_stable', 0), 'ctrl_flag_no_change': ('no_change', 0),
           'ctrl_flag_temporary': ('temporary', 0), 'ctrl_flag_quiet_only': ('quiet_only', 0), 'strict_detection': ('pos', 2), 'pre_onset_pos': ('pos', 1), 'pre_onset_ctrl': ('ctrl', 1)}
# ---- Experiment 1: original seed
e1 = []
for d, q, s in conds:
    for w in ('to_end', 'six_week'):
        for m in MET:
            rec = dict(d=d, q=q, s=s, window=w, method=m)
            for name, (g, idx) in METRICS.items(): rec[name] = float(np.mean(pres_vals(ORIGS, d, q, s, m, w, g, idx)))
            e1.append(rec)
json.dump(e1, open(ROOT / 'results' / 'exp1_summary.json', 'w'), indent=1)
with open(ROOT / 'results' / 'exp1_summary.csv', 'w', newline='') as f:
    wr = csv.DictWriter(f, fieldnames=list(e1[0])); wr.writeheader(); wr.writerows(e1)
# paired CAP minus comparator, original seed
paired = []
for d, q, s in conds:
    for w in ('to_end', 'six_week'):
        for m in MET:
            if m == 'cap': continue
            for name in ('detection', 'ctrl_flag', 'strict_detection'):
                g, idx = METRICS[name]
                diff = np.array(pres_vals(ORIGS, d, q, s, 'cap', w, g, idx)) - np.array(pres_vals(ORIGS, d, q, s, m, w, g, idx))
                paired.append(dict(d=d, q=q, s=s, window=w, comparator=m, metric=name, mean_diff=float(diff.mean()), cap_higher=int((diff > 1e-12).sum()),
                                   cap_lower=int((diff < -1e-12).sum()), ties=int((abs(diff) <= 1e-12).sum()), signflip_p_descriptive=signflip_p(diff)))
json.dump(paired, open(ROOT / 'results' / 'exp1_paired_differences.json', 'w'), indent=1)
# ---- Experiment 3: seeds
e3 = []; direction = []
for d, q, s in conds:
    for w in ('to_end', 'six_week'):
        for m in MET:
            rec = dict(d=d, q=q, s=s, window=w, method=m)
            for name, (g, idx) in METRICS.items():
                per_seed = [float(np.mean(pres_vals(sd, d, q, s, m, w, g, idx))) for sd in ALL]
                per_pres = np.array([pres_vals(sd, d, q, s, m, w, g, idx) for sd in ALL])  # seeds x courses
                rec[name] = dict(seed_values=per_seed, min=min(per_seed), median=float(np.median(per_seed)), max=max(per_seed), sd=float(np.std(per_seed, ddof=1)),
                                 new_seed_mean=float(np.mean(per_seed[1:])),
                                 presentation_sd_across_seeds=[float(x) for x in per_pres.std(axis=0, ddof=1)],
                                 presentation_means=[float(x) for x in per_pres.mean(axis=0)])
            e3.append(rec)
        for m in MET:
            if m == 'cap': continue
            for name in ('detection', 'ctrl_flag', 'strict_detection'):
                g, idx = METRICS[name]
                seed_dirs = []; orig_dir = None
                for sd in ALL:
                    diff = np.array(pres_vals(sd, d, q, s, 'cap', w, g, idx)) - np.array(pres_vals(sd, d, q, s, m, w, g, idx))
                    hi, lo = int((diff > 1e-12).sum()), int((diff < -1e-12).sum())
                    dirn = 'cap_higher' if hi >= 7 else ('cap_lower' if lo >= 7 else 'mixed')
                    seed_dirs.append(dirn)
                    if sd == ORIGS: orig_dir = dirn
                n_same = max(seed_dirs.count('cap_higher'), seed_dirs.count('cap_lower'))
                maj = 'cap_higher' if seed_dirs.count('cap_higher') >= seed_dirs.count('cap_lower') else 'cap_lower'
                direction.append(dict(d=d, q=q, s=s, window=w, comparator=m, metric=name, original_seed_direction=orig_dir,
                                      seeds_with_7of8=sum(1 for x in seed_dirs if x == maj), seeds_total=len(ALL),
                                      majority_direction=maj, passes_rule=bool(orig_dir == maj and sum(1 for x in seed_dirs if x == maj) >= 9)))
json.dump(e3, open(ROOT / 'results' / 'exp3_seed_stability.json', 'w'))
json.dump(direction, open(ROOT / 'results' / 'exp3_direction_consistency.json', 'w'), indent=1)
print('done', len(e1), len(paired), len(e3), len(direction))
