import json, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from pathlib import Path
R = Path(__file__).resolve().parent.parent / 'results'; FG = Path(__file__).resolve().parent.parent / 'figures'; FG.mkdir(exist_ok=True)
plt.rcParams.update({'font.size': 9, 'figure.dpi': 160})
S = json.load(open(R / 'exp1_summary.json'))
conds = [(0, None)] + [(q, s) for q in (2, 4) for s in (0.25, 0.5, 0.75)]
lab = ['no lull'] + [f'{q}w, x{s}' for q in (2, 4) for s in (0.25, 0.5, 0.75)]
D = [0.1, 0.25, 0.5, 0.75]
def val(m, d, q, s, key, w='to_end'):
    for r in S:
        if r['method'] == m and r['d'] == d and r['q'] == q and r['s'] == s and r['window'] == w: return r[key]
# Fig 1: CAP minus comparator, detection and control flag
fig, ax = plt.subplots(2, 2, figsize=(9.5, 6.4), constrained_layout=True)
for j, comp in enumerate(['individual', 'fixed']):
    for i, key in enumerate(['detection', 'ctrl_flag']):
        A = np.array([[val('cap', d, q, s, key) - val(comp, d, q, s, key) for (q, s) in conds] for d in D])
        im = ax[i, j].imshow(A, cmap='RdBu_r', vmin=-0.3, vmax=0.3, aspect='auto')
        ax[i, j].set_xticks(range(7)); ax[i, j].set_xticklabels(lab if i == 1 else [], rotation=40, ha='right'); ax[i, j].set_yticks(range(4)); ax[i, j].set_yticklabels([f'd={d}' for d in D])
        ax[i, j].set_title(f"CAP minus {'raw history' if comp=='individual' else 'fixed'}: {'detection' if key=='detection' else 'control flag rate'}")
        for a in range(4):
            for b in range(7): ax[i, j].text(b, a, f'{A[a,b]:+.2f}', ha='center', va='center', fontsize=6)
fig.colorbar(im, ax=ax, shrink=0.8); fig.savefig(FG / 'fig1_cap_minus_comparators.png', bbox_inches='tight'); plt.close(fig)
# Fig 2: seed spread
SS = json.load(open(R / 'exp3_seed_stability.json'))
fig, ax = plt.subplots(1, 2, figsize=(9, 3.4))
for k, (key, t) in enumerate([('detection', 'Detection'), ('ctrl_flag', 'Control flag rate')]):
    for x, m in enumerate(['fixed', 'individual', 'cap', 'cap_no_context', 'cusum', 'park_prefix_poisson']):
        r = [r for r in SS if r['method'] == m and r['d'] == 0.25 and r['q'] == 2 and r['s'] == 0.5 and r['window'] == 'to_end'][0][key]
        ax[k].scatter([x] * len(r['seed_values']), r['seed_values'], s=12, alpha=.7); ax[k].plot([x - .3, x + .3], [r['median']] * 2, 'k-', lw=1)
    ax[k].set_xticks(range(6)); ax[k].set_xticklabels(['fixed', 'raw hist', 'CAP', 'no ctx', 'CUSUM', 'Poisson'], rotation=30); ax[k].set_title(f'{t}, d=0.25, 2w lull x0.5, 11 seeds')
fig.savefig(FG / 'fig2_seed_spread.png', bbox_inches='tight'); plt.close(fig)
# Fig 3: calibration dev vs test
C = json.load(open(R / 'exp2_calibration.json'))['results']
fig, ax = plt.subplots(figsize=(5.2, 4))
mk = {'individual': 'o', 'cap_no_context': 's', 'cap': '^', 'cusum': 'D', 'park_prefix_poisson': 'v'}
for r in C:
    if r.get('params') is None: continue
    t = r['test']['q2']['to_end']; ax.scatter(t['equal_weight_control_flag_rate'], t['equal_weight_detection'], marker=mk[r['method']], c={0.1: 'C0', 0.2: 'C1', 0.3: 'C2'}[r['budget']], s=40)
ax.set_xlabel('achieved test control flag rate'); ax.set_ylabel('test detection'); ax.set_title('Frozen settings chosen on development (q=2, x0.5, d=0.25)\ncolor: budget 0.1/0.2/0.3; marker: method', fontsize=8)
ax.legend([plt.Line2D([], [], marker=v, ls='', c='gray') for v in mk.values()], ['raw hist', 'no ctx', 'CAP', 'CUSUM', 'Poisson'], fontsize=7)
fig.savefig(FG / 'fig3_calibration_frozen_test.png', bbox_inches='tight'); plt.close(fig)
# Fig 4: withdrawal
W = json.load(open(R / 'exp4_withdrawal.json'))['summary']
fig, ax = plt.subplots(1, 3, figsize=(9.5, 3))
ms = ['fixed', 'individual', 'cap_no_context', 'cap']
for k, key in enumerate(['sensitivity', 'alerts_per_100_eligible', 'lift']):
    for o, sc in enumerate(['all_22', 'frozen_8']):
        ax[k].bar(np.arange(4) + o * .38, [W[sc][m]['H4']['equal_weight'][key] for m in ms], .38, label=sc)
    ax[k].set_xticks(np.arange(4) + .19); ax[k].set_xticklabels(['fixed', 'raw', 'no ctx', 'CAP'], rotation=20); ax[k].set_title(key.replace('_', ' ') + ' (4 week horizon)')
ax[2].axhline(1, c='k', lw=.6); ax[0].legend(fontsize=7)
fig.savefig(FG / 'fig4_withdrawal.png', bbox_inches='tight'); plt.close(fig)
print('ok')
