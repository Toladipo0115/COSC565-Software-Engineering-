"""Zero mismatch check of the vectorised detectors against the vendored canonical detectors on the frozen conditions."""
from common import *
from fastdet import *
check_protocol_hash()
data, _ = frozen_pools(); bad = {k: 0 for k in ('fixed', 'individual', 'cusum', 'cap', 'cap_no_context', 'park_prefix_poisson')}; cells = 0
for course in sorted(data):
    ids, scen = archived_assignment(course)
    for q in (0, 2, 4):
        mat = inject(data[course], ids, scen, q, 0.5, 0.25); canon = run_detectors(mat)
        M = np.array([mat[s] for s in ids], dtype=float); F = feats(M); P = poisson_stats(M)
        mine = dict(fixed=f_fixed(F), individual=f_raw(F), cusum=f_cusum(F), cap=f_cap(F), cap_no_context=f_noctx(F), park_prefix_poisson=f_poisson(P))
        for k, arr in mine.items():
            ref = np.array([canon[s][k] for s in ids], dtype=bool); bad[k] += int((ref != arr).sum())
        cells += M.size
print('cells per method', cells, 'mismatches', bad)
assert sum(bad.values()) == 0
