"""Experiment 1 (original seed, archived assignments) and Experiment 3 (new seeds): full injection grid.
Usage: ET_DB=... ET_REG=... python run_grid.py --seed 20261015 [--workers 2]"""
import argparse, time
from multiprocessing import Pool
from common import *

def work(args):
    course, pool, seed, conds = args
    if seed == ORIG['seeds'][0]:
        ids, scen = archived_assignment(course)
        regen, rscen = sample_assignment(pool, course, seed)
        assert ids == regen and scen == rscen, f'archived assignment differs from regeneration for {course}'
    else:
        ids, scen = sample_assignment(pool, course, seed)
    return run_course(course, pool, ids, scen, seed, conds), (course, seed, list(zip(ids, scen)))

if __name__ == '__main__':
    check_protocol_hash()
    ap = argparse.ArgumentParser(); ap.add_argument('--seed', type=int, required=True); ap.add_argument('--workers', type=int, default=2)
    a = ap.parse_args()
    t0 = time.time()
    data, counts = frozen_pools()
    conds = condition_list()
    jobs = [(c, data[c], a.seed, conds) for c in sorted(data)]
    with Pool(a.workers) as p: out = p.map(work, jobs)
    rows = [r for o in out for r in o[0]]
    write_rows(ROOT / 'results' / f'grid_seed_{a.seed}.csv.gz', rows)
    with open(ROOT / 'private_do_not_publish' / f'assignments_seed_{a.seed}.csv', 'w', newline='') as f:
        w = csv.writer(f); w.writerow(['course', 'seed', 'student', 'scenario'])
        for _, (c, s, pairs) in out:
            for sid, sc in pairs: w.writerow([c, s, sid, sc])
    print('seed', a.seed, 'rows', len(rows), 'seconds', round(time.time() - t0, 1), counts)
