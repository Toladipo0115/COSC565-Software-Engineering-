"""Shared helpers for the EngageTrace extension package.
Imports the vendored original detector code unchanged (see vendor/SHA256SUMS.txt)."""
import csv, gzip, json, os, random, sys, statistics, itertools
from pathlib import Path
from collections import defaultdict

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'vendor'))
from run_validation import load_data, SCENARIOS, ONSETS, POS          # original generator pieces
from engagetrace_detectors import RevisedConfig, detect_revised, REVISED_METHODS
from park_poisson import detect_park_prefix

DB = os.environ.get('ET_DB', '')
REG = os.environ.get('ET_REG', '')
PROTO = json.loads((ROOT / 'protocol' / 'protocol.json').read_text())
ORIG = json.loads((ROOT / 'vendor' / 'original_protocol.json').read_text())
DET = ORIG['detector']
METHODS = list(REVISED_METHODS) + ['park_prefix_poisson']
FROZEN = ORIG['evaluation_presentations']
T = 20

def check_protocol_hash():
    import hashlib
    h = hashlib.sha256((ROOT / 'protocol' / 'protocol.json').read_bytes()).hexdigest()
    ref = (ROOT / 'protocol' / 'protocol.sha256').read_text().split()[0]
    assert h == ref, 'protocol.json changed after it was frozen'

def frozen_pools():
    """Original eligibility, 7,642 distinct students in eight presentations."""
    data, counts = load_data(DB, REG, ORIG)
    return data, counts

def sample_assignment(pool, course, seed, n=300):
    ids = random.Random(f'{course}:{seed}').sample(sorted(pool), n)
    return ids, [SCENARIOS[j // 60] for j in range(n)]

def archived_assignment(course):
    """Archived original assignments for seed 20261015 and q=2 (order preserved)."""
    rows = [r for r in csv.DictReader(open(ROOT / 'private_do_not_publish' / 'original_assignments.csv'))
            if r['course'] == course and r['quiet_length'] == '2']
    return [r['student'] for r in rows], [r['scenario'] for r in rows]

def inject(pool, ids, scen, q, s, d):
    """Original order and rounding: shared lull first, then individual change."""
    out = {}
    for sid, c in zip(ids, scen):
        v = pool[sid][:]
        if q:
            for w in range(7, 7 + q): v[w - 1] = round(v[w - 1] * s)
        if c in POS:
            for w in range(ONSETS[c], 21): v[w - 1] = round(v[w - 1] * d)
        elif c == 'temporary':
            v[14] = round(v[14] * d)
        out[sid] = v
    return out

def run_detectors(matrix, cfg=None):
    cfg = cfg or DET
    res = detect_revised(matrix, RevisedConfig(**cfg))
    park = detect_park_prefix(matrix)
    for sid in res: res[sid]['park_prefix_poisson'] = park[sid]
    return res

def score_case(seq, onset_week, window):
    begin = onset_week - 1
    end = 20 if window == 'to_end' else min(begin + 6, 20)
    alarm = any(seq[begin:end]); pre = any(seq[:begin])
    return int(alarm), int(pre), int(alarm and not pre)

def condition_list():
    conds = []
    for d in PROTO['injection']['individual_multipliers_d']:
        for lc in PROTO['injection']['lull_conditions']:
            conds.append((d, lc['q'], lc['s']))
    return conds

HEADER = ['course', 'seed', 'd', 'q', 's', 'method', 'window', 'scenario', 'n', 'alarm', 'pre', 'strict']

def run_course(course, pool, ids, scen, seed, conds):
    rows = []
    for d, q, s in conds:
        mat = inject(pool, ids, scen, q, s, d)
        fl = run_detectors(mat)
        for m in METHODS:
            for window in ('to_end', 'six_week'):
                acc = defaultdict(lambda: [0, 0, 0, 0])
                for sid, c in zip(ids, scen):
                    a, p, st = score_case(fl[sid][m], ONSETS[c], window)
                    r = acc[c]; r[0] += 1; r[1] += a; r[2] += p; r[3] += st
                for c in SCENARIOS:
                    n, a, p, st = acc[c]
                    rows.append([course, seed, d, q, '' if s is None else s, m, window, c, n, a, p, st])
    return rows

def write_rows(path, rows):
    with gzip.open(path, 'wt', newline='') as f:
        w = csv.writer(f); w.writerow(HEADER); w.writerows(rows)

def read_rows(path):
    with gzip.open(path, 'rt', newline='') as f:
        r = csv.DictReader(f)
        for x in r:
            for k in ('seed', 'q', 'n', 'alarm', 'pre', 'strict'): x[k] = int(x[k])
            x['d'] = float(x['d']); x['s'] = float(x['s']) if x['s'] != '' else None
            yield x
