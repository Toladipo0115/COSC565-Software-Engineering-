# EngageTrace extension protocol, 2026-10-16

Hashed before any extension run. See protocol.json for the exact configuration (the code reads it).

Status: additional post hoc analyses after the frozen test was examined. They are not untouched confirmation. Original files and results are preserved in vendor/ and are never edited.

1. Injection robustness: individual multiplier d in {0.10, 0.25, 0.50, 0.75} by lull (q, s): no lull, and q in {2, 4} with s in {0.25, 0.50, 0.75}. That is 28 paired conditions on the archived frozen assignments. Original injection order and Python rounding. The same d scales the temporary dip, so no_change and quiet_only control rates are also reported alone.
2. Threshold comparison: select settings on replacement development samples at control flag budgets 10, 20 and 30 percent, freeze, evaluate on the frozen presentations, report achieved rates without interpolation.
3. Seed stability: ten new seeds plus the original, full grid each. Seeds overlap in students and are not independent.
4. Withdrawal: weekly eligibility from information known by the prediction week, withdrawn students removed from later cohort ranks, prediction weeks 9 to 16, horizons 4 and 2 weeks.

Reporting rules: control flag rate is not a false positive rate; no superiority claim without direction in 7 of 8 presentations, the original seed, and 9 of 11 seeds, both windows; all p values descriptive and unadjusted; seeds do not give external validity; the missing original development selection cannot be recovered.
