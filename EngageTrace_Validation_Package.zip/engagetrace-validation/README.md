# EngageTrace transfer audit and dashboard check

## What this package establishes

The revised detector was rerun without tuning on the same eight-presentation exploratory transfer protocol already inspected earlier. Full pre-onset scoring is corrected. This is not a new independent or external test. A weekly-prefix adaptation of the Poisson model in Park et al. (2017), DOI 10.1145/3027385.3027430, supplies a closer comparison; it is not their released implementation or exact daily retrospective experiment.

Read protocol.json before interpreting results. results/summary.csv contains equal-weight presentation means, descriptive course bootstrap bounds, earlier alarms, strict detections, baseline flags, and newly beginning episodes. results/case_results.csv and assignments.csv preserve all outcomes and sampling assignments. run_manifest.json records input/code hashes and exclusions. Repeated seeds reuse people and are not independent replications. Eligibility uses future enrollment status and nonzero activity and selects a stable-enrollment population.

## Reproduce

Requires Python 3.12 (standard library only) and the rebuilt OULAD SQLite database and original studentRegistration.csv. The database is not bundled.

```bash
python code/test_park.py
python code/run_transfer.py --database /path/engagetrace.db --registration /path/studentRegistration.csv
```

Run from the extracted package. Outputs replace the package results directory, so copy it first if preserving the delivered results.

## Dashboard

Open EngageTrace_Dashboard_Checked.html directly in a browser. It contains the compiled application and styles in one file. The revised look and feel is retained. Synthetic data are labeled as demonstration data; real course JSON can be loaded through the existing source controls. Local JSON is processed in the browser. SQLite CSV ingestion remains a Python step. Connecting a database service still requires the existing configured service; this work did not deploy or populate a hosted database.

The dashboard raw-history comparator now uses the same lagged baseline as the revised Python detector. Four displayed methods match Python on 19 datasets/configurations and 38,688 weekly flags. These include the saved 300-sequence controlled cohort, zeros, tied declines, a singleton, short history, random data, and isolated decline. This is computational parity on stated fixtures, not proof for every input or usability validation. The editable dashboard source and golden regression tests are in the separate dashboard source ZIP.

For a Python-side dashboard parity check, provide the original saved controlled_eval_cohort.json:

```bash
python code/check_dashboard_parity.py /path/engagetrace_dashboard.jsx /path/controlled_eval_cohort.json results/dashboard_after.json
```

The original dashboard source is retained as code/dashboard_before.jsx for audit. Before correction there were 716 raw-history mismatches; CAP, fixed, and CUSUM already matched these fixtures.
