"""Execute the actual dashboard function in Node and compare every flag to Python.
Usage: python check_dashboard_parity.py DASHBOARD.jsx COHORT.json REPORT.json
The cohort JSON is the saved controlled_eval_cohort.json, not a newly sampled set.
"""
import json,os,random,subprocess,sys,hashlib
from pathlib import Path
from engagetrace_detectors import RevisedConfig,detect_revised
source=Path(sys.argv[1]);cohort=Path(sys.argv[2]);output=Path(sys.argv[3])
base=dict(k=3,lag=3,tauInd=.5,tauCtx=.6,p=3,fixedThreshold=6,tauIndLog=.2)
cases=[('saved_controlled',json.loads(cohort.read_text())['matrix'],base)]
rng=random.Random(102615)
for name,mat in [('zero',{str(i):[0]*20 for i in range(3)}),('tied_decline',{str(i):[100]*6+[2]*14 for i in range(4)}),('singleton',{'one':[100]*6+[0]*14}),('short',{'a':[1,2],'b':[3,4]}),('random',{str(i):[rng.randrange(0,300) for _ in range(30)] for i in range(30)}),('isolated_decline',{str(i):[100]*6+([0]*14 if i==0 else [100]*14) for i in range(8)})]:
 for j,override in enumerate([{},dict(k=2,lag=1,p=1,tauIndLog=.35,tauCtx=.7),dict(k=6,lag=3,p=4,tauInd=.7,tauCtx=.95,fixedThreshold=20)]):
  cases.append((name+'_'+str(j),mat,base|override))
payload=[dict(name=n,students=[dict(id=k,values=v) for k,v in m.items()],params=p) for n,m,p in cases]
js="""const fs=require('fs'),vm=require('vm');const src=fs.readFileSync(process.argv[1],'utf8');const a=src.indexOf('function median('),b=src.indexOf('const METHODS =',a);if(a<0||b<0)throw Error('Detector extraction markers missing');const ctx={WEEKS:20};vm.createContext(ctx);vm.runInContext(src.slice(a,b),ctx);const input=JSON.parse(fs.readFileSync(0,'utf8'));process.stdout.write(JSON.stringify(input.map(c=>ctx.computeDetections(c.students,c.params).results)));"""
node=os.environ.get('CODEX_PRIMARY_RUNTIME_NODE','node')
actual=json.loads(subprocess.run([node,'-e',js,str(source)],input=json.dumps(payload),text=True,capture_output=True,check=True).stdout)
golden=[]
checks=0;diffs=[];by={m:0 for m in ['fixed','individual','cusum','cap']}
for (name,m,p),got in zip(cases,actual):
 cfg=RevisedConfig(k=p['k'],lag=p['lag'],tau_ind_raw=p['tauInd'],tau_ind_log=p['tauIndLog'],tau_ctx_pct=p['tauCtx'],p=p['p'],fixed_threshold=p['fixedThreshold'])
 expected=detect_revised(m,cfg)
 golden.append([dict((method,expected[sid][method]) for method in by) for sid in m])
 for j,sid in enumerate(m):
  for method in by:
   for t,(a,b) in enumerate(zip(got[j][method],expected[sid][method]),1):
    checks+=1
    if a!=b:
     by[method]+=1
     if len(diffs)<10:diffs.append(dict(case=name,student=sid,method=method,week=t,browser=a,python=b))
report=dict(cases=len(cases),flag_comparisons=checks,mismatches=sum(by.values()),mismatches_by_method=by,examples=diffs,dashboard_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),reference_sha256=hashlib.sha256(Path(__file__).with_name('engagetrace_detectors.py').read_bytes()).hexdigest(),scope='Numerical flag parity on listed fixtures and configurations, not UI usability, imports, network, or database end-to-end validation.')
output.with_name('dashboard_parity_fixtures.json').write_text(json.dumps(dict(cases=payload,expected=golden,reference_sha256=report['reference_sha256'])))
output.write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
