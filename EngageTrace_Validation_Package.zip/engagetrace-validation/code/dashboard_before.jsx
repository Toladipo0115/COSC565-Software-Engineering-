import React, { useMemo, useState, useEffect, useRef, useId } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  ReferenceArea, BarChart, Bar, Legend,
} from "recharts";

// ---------- synthetic OULAD-style data generation ----------

function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const WEEKS = 20;
const QUIET_WEEKS = [9, 10];

const CATEGORY_META = {
  sustained_decline: { label: "Individual sustained decline", color: "#B8763B" },
  temporary: { label: "Temporary dip, recovered", color: "#3B7A78" },
  decline_during_quiet: { label: "Decline during course-wide quiet period", color: "#A63D40" },
  stable_low: { label: "Stable low activity", color: "#7A7368" },
  normal: { label: "Normal / no change", color: "#8B8B7A" },
};

function patternFactor(category, week) {
  if (category === "sustained_decline") return week < 12 ? 1 : 0.25;
  if (category === "temporary") return week >= 5 && week <= 6 ? 0.35 : 1;
  if (category === "decline_during_quiet") return week < 9 ? 1 : 0.25;
  return 1;
}

function quietFactor(week) {
  return QUIET_WEEKS.includes(week) ? 0.5 : 1;
}

function generateStudents() {
  const rng = mulberry32(20260903);
  const students = [];
  const plan = [
    ...Array(4).fill("sustained_decline"),
    ...Array(3).fill("temporary"),
    ...Array(2).fill("decline_during_quiet"),
    "stable_low",
    ...Array(14).fill("normal"),
  ];
  plan.forEach((category, idx) => {
    const baseline = category === "stable_low"
      ? 18 + rng() * 8
      : 45 + rng() * 110;
    const noiseSd = category === "stable_low" ? baseline * 0.08 : baseline * 0.15;
    const values = [];
    for (let w = 1; w <= WEEKS; w++) {
      const noise = (rng() - 0.5) * 2 * noiseSd;
      const v = baseline * quietFactor(w) * patternFactor(category, w) + noise;
      values.push(Math.max(0, Math.round(v)));
    }
    students.push({
      id: `S${String(idx + 1).padStart(2, "0")}`,
      category,
      baseline: Math.round(baseline),
      values,
    });
  });
  return students;
}

// ---------- statistics helpers ----------

function median(arr) {
  if (!arr.length) return 0;
  const s = [...arr].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

function mad(arr) {
  const m = median(arr);
  return median(arr.map((x) => Math.abs(x - m)));
}

// ---------- detection methods ----------

function computeDetections(students, params) {
  const { k, tauInd, tauCtx, p, fixedThreshold, tauIndLog = 0.2, lag = 3 } = params;
  const eps = 1e-6;
  const weeks = students[0] ? students[0].values.length : WEEKS;

  // raw-scale delta, used only by the 'individual' and 'fixed' baselines
  const deltas = students.map((s) =>
    s.values.map((v, i) => {
      const t = i + 1;
      if (t <= k) return null;
      const win = s.values.slice(i - k, i);
      const base = median(win);
      return (base - v) / (base + eps);
    })
  );

  // log-scale, lagged-window delta, used by CAP -- matches controlled_eval.py.
  // Real click counts are strongly right-skewed (an opening-week spike dominates),
  // which saturates a raw-scale signal across nearly the whole cohort; log1p tames
  // this. The lag avoids the trailing baseline "chasing" an ongoing decline.
  const logStudents = students.map((s) => s.values.map((v) => Math.log1p(Math.max(0, v))));
  const logDeltas = students.map((s, si) =>
    s.values.map((v, i) => {
      const t = i + 1;
      if (t <= k + lag) return null;
      const win = logStudents[si].slice(i - k - lag, i - lag);
      const base = median(win);
      return base - logStudents[si][i];
    })
  );

  // course-relative percentile rank of that week's log-decline (robust to a
  // tightly clustered cohort distribution, unlike a MAD-based z-score)
  const percentiles = students.map(() => Array(weeks).fill(null));
  for (let i = 0; i < weeks; i++) {
    const weekVals = [];
    students.forEach((_, si) => {
      const v = logDeltas[si][i];
      if (v !== null) weekVals.push({ si, v });
    });
    if (weekVals.length < 2) continue;
    const sorted = weekVals.map((x) => x.v).slice().sort((a, b) => a - b);
    weekVals.forEach(({ si, v }) => {
      const rank = sorted.filter((x) => x <= v).length;
      percentiles[si][i] = rank / sorted.length;
    });
  }

  const results = students.map(() => ({
    fixed: Array(weeks).fill(false),
    individual: Array(weeks).fill(false),
    cusum: Array(weeks).fill(false),
    cap: Array(weeks).fill(false),
  }));

  // fixed + individual (with persistence p)
  students.forEach((s, si) => {
    let fixedRun = 0, indRun = 0;
    for (let i = 0; i < weeks; i++) {
      const val = s.values[i];
      fixedRun = val < fixedThreshold ? fixedRun + 1 : 0;
      results[si].fixed[i] = fixedRun >= p;

      const d = deltas[si][i];
      indRun = d !== null && d >= tauInd ? indRun + 1 : 0;
      results[si].individual[i] = indRun >= p;
    }
  });

  // cusum
  students.forEach((s, si) => {
    const mu0 = median(s.values.slice(0, Math.min(k, s.values.length)));
    const slack = 0.25 * mu0;
    const H = 2 * mu0;
    let S = 0;
    for (let i = 0; i < weeks; i++) {
      S = Math.max(0, S + (mu0 - s.values[i]) - slack);
      results[si].cusum[i] = S > H && mu0 > 0;
    }
  });

  // CAP: log-scale individual deviation AND course-relative percentile AND persistence
  students.forEach((s, si) => {
    let run = 0;
    for (let i = 0; i < weeks; i++) {
      const ld = logDeltas[si][i];
      const z = percentiles[si][i];
      const cond = ld !== null && z !== null && ld >= tauIndLog && z >= tauCtx;
      run = cond ? run + 1 : 0;
      results[si].cap[i] = run >= p;
    }
  });

  return { deltas, results };
}

const METHODS = [
  { key: "fixed", label: "Fixed threshold", color: "#8B8B7A" },
  { key: "individual", label: "Individual-history only", color: "#3B7A78" },
  { key: "cusum", label: "Statistical change-point (CUSUM)", color: "#B8763B" },
  { key: "cap", label: "CAP (proposed)", color: "#A63D40" },
];

// ---------- UI ----------

async function fetchSupabaseCourse(url, anonKey, courseId) {
  const headers = { apikey: anonKey, Authorization: `Bearer ${anonKey}` };
  const base = url.replace(/\/$/, "");

  const actRes = await fetch(
    `${base}/rest/v1/weekly_activity?course_id=eq.${encodeURIComponent(courseId)}&select=student_id,week,clicks&order=student_id,week`,
    { headers }
  );
  if (!actRes.ok) throw new Error(`Supabase error (${actRes.status}): ${await actRes.text()}`);
  const activity = await actRes.json();
  if (!activity.length) throw new Error("No weekly_activity rows found for this course_id");

  const maxWeek = Math.max(...activity.map((r) => r.week));
  const byStudent = {};
  activity.forEach((r) => {
    if (!byStudent[r.student_id]) byStudent[r.student_id] = Array(maxWeek).fill(0);
    byStudent[r.student_id][r.week - 1] = r.clicks;
  });

  return {
    courseId,
    weeks: maxWeek,
    students: Object.entries(byStudent).map(([id, values]) => ({ id, values })),
  };
}

async function fetchSupabaseCourseList(url, anonKey) {
  const headers = { apikey: anonKey, Authorization: `Bearer ${anonKey}` };
  const base = url.replace(/\/$/, "");
  const res = await fetch(`${base}/rest/v1/courses?select=course_id`, { headers });
  if (!res.ok) throw new Error(`Supabase error (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows.map((r) => r.course_id);
}

function parseImportedCourse(json) {
  if (!json || !Array.isArray(json.students) || !Number.isInteger(json.weeks) || json.weeks < 1 || json.weeks > 520) {
    throw new Error("File must have { courseId, weeks, students: [{ id, values }] }");
  }
  if (!json.students.length || json.students.length > 10000) throw new Error("Choose a course containing 1 to 10,000 students.");
  const ids = new Set();
  for (const s of json.students) {
    if (s.id == null || !String(s.id).trim() || ids.has(String(s.id))) throw new Error("Student IDs must be present and unique.");
    ids.add(String(s.id));
    if (!Array.isArray(s.values) || s.values.length !== json.weeks || s.values.some(v => typeof v !== "number" || !Number.isFinite(v) || v < 0)) throw new Error("Each student needs one nonnegative numeric click count per week. Missing weeks require preprocessing.");
  }
  return json.students.map((s) => ({
    id: String(s.id),
    category: "imported",
    baseline: Math.round(median(s.values || [])),
    values: (s.values || []).slice(0, json.weeks),
  }));
}

export default function EngageTraceDashboard() {
  const syntheticStudents = useMemo(() => generateStudents(), []);
  const [importedStudents, setImportedStudents] = useState(null);
  const [importedCourseId, setImportedCourseId] = useState(null);
  const [importError, setImportError] = useState(null);
  const students = importedStudents || syntheticStudents;
  const [tab, setTab] = useState("overview");
  const [studentId, setStudentId] = useState(students[0].id);
  const [k, setK] = useState(3);
  const [tauInd, setTauInd] = useState(0.5);
  const [tauCtx, setTauCtx] = useState(0.6);
  const [tauIndLog, setTauIndLog] = useState(0.2);
  const [p, setP] = useState(3);
  const [fixedThreshold, setFixedThreshold] = useState(6);
  const [showLabels, setShowLabels] = useState(true);
  const [sourceOpen, setSourceOpen] = useState(false);

  const fileInputRef = useRef(null);
  const [supabaseUrl, setSupabaseUrl] = useState("");
  const [supabaseAnonKey, setSupabaseAnonKey] = useState("");
  const [supabaseCourses, setSupabaseCourses] = useState([]);
  const [supabaseSelectedCourse, setSupabaseSelectedCourse] = useState("");
  const [supabaseStatus, setSupabaseStatus] = useState(null);
  const [supabaseLoading, setSupabaseLoading] = useState(false);

  async function handleSupabaseConnect() {
    setSupabaseStatus(null);
    setSupabaseLoading(true);
    try {
      const courses = await fetchSupabaseCourseList(supabaseUrl, supabaseAnonKey);
      setSupabaseCourses(courses);
      setSupabaseSelectedCourse(courses[0] || "");
      setSupabaseStatus(courses.length ? null : "Connected, but no courses found yet.");
    } catch (err) {
      setSupabaseCourses([]);
      setSupabaseStatus(err.message || "Could not connect to Supabase");
    } finally {
      setSupabaseLoading(false);
    }
  }

  async function handleSupabaseLoadCourse() {
    if (!supabaseSelectedCourse) return;
    setSupabaseStatus(null);
    setSupabaseLoading(true);
    try {
      const json = await fetchSupabaseCourse(supabaseUrl, supabaseAnonKey, supabaseSelectedCourse);
      const parsed = parseImportedCourse(json);
      if (!parsed.length) throw new Error("No students found for this course");
      setImportedStudents(parsed);
      setImportedCourseId(json.courseId);
      setImportError(null);
    } catch (err) {
      setSupabaseStatus(err.message || "Could not load this course");
    } finally {
      setSupabaseLoading(false);
    }
  }

  useEffect(() => {
    if (!students.find((s) => s.id === studentId)) {
      setStudentId(students[0].id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [students]);

  function handleFileChange(e) {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) { setImportError("Choose a course JSON smaller than 10 MiB."); return; }
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const json = JSON.parse(reader.result);
        const parsed = parseImportedCourse(json);
        if (!parsed.length) throw new Error("No students found in file");
        setImportedStudents(parsed);
        setImportedCourseId(json.courseId || file.name);
        setImportError(null);
      } catch (err) {
        setImportError(err.message || "Could not parse this file");
      }
    };
    reader.onerror = () => setImportError("Could not read the selected file.");
    reader.readAsText(file);
  }

  function resetToSynthetic() {
    setImportedStudents(null);
    setImportedCourseId(null);
    setImportError(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  const weeksCount = students[0] ? students[0].values.length : WEEKS;
  const params = { k, tauInd, tauCtx, p, fixedThreshold, tauIndLog, lag: 3 };
  const { deltas, results } = useMemo(
    () => computeDetections(students, params),
    [students, k, tauInd, tauCtx, p, fixedThreshold, tauIndLog]
  );

  const cohortMedianByWeek = useMemo(() => {
    const arr = [];
    for (let i = 0; i < weeksCount; i++) {
      arr.push(median(students.map((s) => s.values[i])));
    }
    return arr;
  }, [students, weeksCount]);

  const selectedIdx = Math.max(0, students.findIndex((s) => s.id === studentId));
  const selected = students[selectedIdx] || students[0];

  const chartData = useMemo(() => {
    return Array.from({ length: weeksCount }, (_, i) => ({
      week: i + 1,
      activity: selected.values[i],
      cohort: cohortMedianByWeek[i],
    }));
  }, [selected, cohortMedianByWeek, weeksCount]);

  const capFlags = results[selectedIdx].cap;
  const flaggedWeeks = chartData.filter((_, i) => capFlags[i]);

  // cohort summary stats
  const summary = useMemo(() => {
    const stats = {};
    METHODS.forEach((m) => {
      let total = 0, quietFalse = 0, truePos = 0;
      students.forEach((s, si) => {
        const flags = results[si][m.key];
        const isGenuine = s.category === "sustained_decline" || s.category === "decline_during_quiet";
        flags.forEach((f, i) => {
          if (!f) return;
          total += 1;
          const week = i + 1;
          if (QUIET_WEEKS.includes(week) && !isGenuine) quietFalse += 1;
          if (isGenuine) truePos += 1;
        });
      });
      stats[m.key] = { total, quietFalse, truePos };
    });
    return stats;
  }, [results, students]);

  const barData = METHODS.map((m) => ({
    name: m.label,
    "Total flagged weeks": summary[m.key].total,
    ...(importedStudents ? {} : { "Demo flags in quiet period": summary[m.key].quietFalse }),
  }));


  const flaggedStudents = students.filter((_, i) => results[i].cap.some(Boolean)).length;
  const reduction = summary.fixed.total ? Math.round((1 - summary.cap.total / summary.fixed.total) * 100) : null;
  const heading = { overview: "Course overview", explorer: "Student activity", summary: "Method comparison" }[tab];
  const metrics = [
    ["Students in course", students.length.toLocaleString(), "Pseudonymous activity records", "01"],
    ["Observation window", `${weeksCount} weeks`, "Weekly LMS click totals", "02"],
    ["Students with CAP flags", flaggedStudents.toLocaleString(), `${students.length} students reviewed by the detector`, "03"],
    ["CAP flagged student-weeks", summary.cap.total.toLocaleString(), "Activity signals for human review", "04"],
  ];
  const timeline = <section className="panel timeline" aria-labelledby="timeline-title">
    <div className="panel-head"><div><p className="eyebrow">ACTIVITY EXPLORER</p><h2 id="timeline-title">A closer look at {selected.id}</h2><p>Weekly clicks alongside the course median.</p></div><span className="badge">{weeksCount} weeks</span></div>
    <div className="chart" role="img" aria-label={`Weekly activity for ${selected.id} compared with the cohort median. Exact values follow in a table.`}>
      <ResponsiveContainer width="100%" height="100%"><LineChart data={chartData} margin={{top:18,right:22,left:0,bottom:15}}>
        <CartesianGrid stroke="#e9e9e5" vertical={false}/>
        {!importedStudents && <ReferenceArea x1={9} x2={10} fill="#dfbb52" fillOpacity={0.16}/>}
        <XAxis dataKey="week" tick={{fontSize:11,fill:"#626660"}} axisLine={false} tickLine={false} label={{value:"Course week",position:"insideBottom",offset:-12,fontSize:11}}/>
        <YAxis tick={{fontSize:11,fill:"#626660"}} axisLine={false} tickLine={false}/>
        <Tooltip contentStyle={{borderRadius:12,border:"1px solid #dedfd8",fontSize:12}} labelFormatter={v=>`Week ${v}`}/>
        <Line isAnimationActive={false} type="linear" dataKey="activity" name={`${selected.id} clicks`} stroke="#9b6b08" strokeWidth={3} dot={{r:3,fill:"#fff",strokeWidth:2}} activeDot={{r:5}}/>
        <Line isAnimationActive={false} type="linear" dataKey="cohort" name="Cohort median" stroke="#3f776d" strokeWidth={2} strokeDasharray="5 5" dot={false}/>
      </LineChart></ResponsiveContainer>
    </div>
    <div className="chart-legend"><span><i className="gold-line"/>Student activity</span><span><i className="teal-line"/>Cohort median</span>{!importedStudents && <span><i className="quiet-key"/>Demo quiet period: weeks 9–10</span>}</div>
    <div className={`finding ${flaggedWeeks.length ? "has-flags" : ""}`}><span className="finding-icon" aria-hidden="true">{flaggedWeeks.length ? "!" : "✓"}</span><div><strong>{flaggedWeeks.length ? `${flaggedWeeks.length} CAP-flagged week${flaggedWeeks.length === 1 ? "" : "s"}` : "No CAP flags under current settings"}</strong><p>{flaggedWeeks.length ? `Weeks ${flaggedWeeks.map(f=>f.week).join(", ")}. Review the timeline and course context before taking action.` : "An unflagged pattern does not establish that a student needs no support."}</p></div></div>
    <details className="data-details"><summary>View accessible activity table</summary><div className="table-scroll"><table><caption>Weekly activity and CAP flags for {selected.id}</caption><thead><tr><th scope="col">Week</th><th scope="col">Student clicks</th><th scope="col">Cohort median</th><th scope="col">CAP flag</th></tr></thead><tbody>{chartData.map((row,i)=><tr key={row.week}><th scope="row">{row.week}</th><td>{row.activity}</td><td>{row.cohort}</td><td>{capFlags[i] ? "Flagged" : "Not flagged"}</td></tr>)}</tbody></table></div></details>
  </section>;
  return <div className="app-shell">
    <a className="skip-link" href="#main-content">Skip to main content</a>
    <aside className="sidebar">
      <a className="brand" href="#main-content" aria-label="EngageTrace dashboard"><span className="brand-mark" aria-hidden="true">E<span>·</span></span><span>EngageTrace<small>LEARNING ANALYTICS</small></span></a>
      <div className="nav-label">WORKSPACE</div>
      <nav aria-label="Dashboard views">{[["overview","◫","Course overview"],["explorer","↗","Student activity"],["summary","≋","Method comparison"]].map(([key,icon,label])=><button key={key} className={tab===key?"nav-item active":"nav-item"} aria-current={tab===key?"page":undefined} onClick={()=>setTab(key)}><span aria-hidden="true">{icon}</span>{label}</button>)}</nav>
      <div className="sidebar-note"><span className="status-dot"/>LOCAL RESEARCH PREVIEW<p>Understand activity.<br/>Keep people in the picture.</p></div>
      <div className="sidebar-footer"><div className="avatar">TO</div><div>Tolulope Oladipo<small>EngageTrace project</small></div></div>
    </aside>
    <div className="workspace">
      <header className="topbar"><div>Workspace <span>/</span> <strong>{heading}</strong></div><span className="badge source-badge">{importedStudents?"Imported course":"Synthetic demonstration"}</span></header>
      <main id="main-content" tabIndex="-1">
        <div className="page-heading"><div><p className="eyebrow">ENGAGEMENT INTELLIGENCE</p><h1>{heading}</h1><p>See the pattern. Understand the context. Support the student.</p></div><button className="button primary" onClick={()=>setSourceOpen(!sourceOpen)} aria-expanded={sourceOpen} aria-controls="data-source">{sourceOpen?"Close data source":"Load course data"}<span aria-hidden="true"> ↗</span></button></div>
        <section className="course-banner" aria-label="Current data context"><div className="banner-symbol" aria-hidden="true">▥</div><div className="banner-copy"><span className="eyebrow">{importedStudents?"IMPORTED COURSE":"DEMONSTRATION WORKSPACE"}</span><h2>{importedStudents?importedCourseId:"Explore engagement in context"}</h2><p>{importedStudents?"Unlabeled activity · browser-computed results · human review required":"Synthetic OULAD-style activity. Illustrative signals, not validated research results."}</p></div><div className="banner-tag"><span className="status-dot"/>{importedStudents?"COURSE LOADED":"DEMO DATA"}</div></section>
        {sourceOpen && <section className="panel source-panel" id="data-source" aria-label="Data source"><div className="panel-head"><div><h2>Choose your data source</h2><p>Load weekly course JSON exported from the existing database tool.</p></div></div><label className="file-label" htmlFor="course-file">Course JSON file</label><input id="course-file" ref={fileInputRef} type="file" accept=".json,application/json" onChange={handleFileChange}/><p className="help">Local JSON is read in this browser. CSV import is a separate Python workflow.</p>{importError&&<p role="alert" className="error">{importError}</p>}{importedStudents&&<button className="button" onClick={resetToSynthetic}>Return to synthetic demo</button>}
          <details className="connection"><summary>Advanced: Supabase connection</summary><div className="connection-fields"><label>Project URL<input type="url" placeholder="https://project.supabase.co" value={supabaseUrl} onChange={e=>setSupabaseUrl(e.target.value)}/></label><label>Public anon key<input type="password" value={supabaseAnonKey} onChange={e=>setSupabaseAnonKey(e.target.value)}/></label><button className="button" disabled={supabaseLoading||!supabaseUrl||!supabaseAnonKey} onClick={handleSupabaseConnect}>{supabaseLoading?"Connecting…":"Connect"}</button>{supabaseCourses.length>0&&<><label>Course<select value={supabaseSelectedCourse} onChange={e=>setSupabaseSelectedCourse(e.target.value)}>{supabaseCourses.map(c=><option key={c}>{c}</option>)}</select></label><button className="button" disabled={supabaseLoading} onClick={handleSupabaseLoadCourse}>Load course</button></>}</div><p className="help">Optional hosted data source. Use a public anon key with configured read-only policies. Never enter a service role key.</p><p role="status">{supabaseStatus}</p></details>
        </section>}
        <div className="metrics">{metrics.map(([label,value,detail,index])=><section className="metric" key={label}><div className="metric-top"><span>{label}</span><span className="metric-index" aria-hidden="true">{index}</span></div><strong>{value}</strong><p>{detail}</p></section>)}</div>
        <div className="content-grid"><div className="main-column">
          {tab!=="summary" ? <>{timeline}<section className="panel"><div className="panel-head"><div><p className="eyebrow">SIGNAL AGREEMENT</p><h2>Four methods. One timeline.</h2><p>Filled cells indicate flagged weeks; a dot means no flag.</p></div><span className="badge">{selected.id}</span></div><MethodStrip results={results[selectedIdx]} weeksCount={weeksCount}/></section></> : <>
            <section className="panel"><div className="panel-head"><div><p className="eyebrow">METHOD COMPARISON</p><h2>Flag volume across the course</h2><p>{students.length.toLocaleString()} students · {weeksCount} weeks · browser calculations</p></div></div><div className="method-cards">{METHODS.map(m=><div className="method-card" key={m.key}><span className="method-label"><i style={{background:m.color}}/>{m.label}</span><strong>{summary[m.key].total.toLocaleString()}</strong><span>flagged student-weeks</span></div>)}</div><div className="chart comparison-chart" role="img" aria-label="Flagged student-week counts by detector. Exact counts are provided in the following table."><ResponsiveContainer width="100%" height="100%"><BarChart data={barData} margin={{top:12,right:20,left:0,bottom:65}}><CartesianGrid vertical={false} stroke="#e9e9e5"/><XAxis dataKey="name" tick={{fontSize:10}} interval={0} angle={-12} textAnchor="end" height={65}/><YAxis tick={{fontSize:11}}/><Tooltip contentStyle={{borderRadius:12}}/><Bar isAnimationActive={false} dataKey="Total flagged weeks" fill="#a77b19" radius={[5,5,0,0]}/>{!importedStudents&&<Bar isAnimationActive={false} dataKey="Demo flags in quiet period" fill="#9e4953" radius={[5,5,0,0]}/>}</BarChart></ResponsiveContainer></div><div className="table-scroll"><table><caption>Method flag counts across {students.length} students</caption><thead><tr><th scope="col">Detector</th><th scope="col">Flagged student-weeks</th>{!importedStudents&&<th scope="col">Demo flags in quiet period</th>}</tr></thead><tbody>{METHODS.map(m=><tr key={m.key}><th scope="row">{m.label}</th><td>{summary[m.key].total}</td>{!importedStudents&&<td>{summary[m.key].quietFalse}</td>}</tr>)}</tbody></table></div><p className="comparison-note">{reduction===null?"Flag-volume reduction is unavailable because the fixed rule produced no flags.":`CAP flag-volume reduction relative to the fixed rule: ${reduction}%.`} Fewer flags do not establish greater accuracy.</p>{importedStudents?<p className="help">Ground truth is unavailable. No false-positive rate is shown for imported activity.</p>:<p className="help">The quiet-period count uses known synthetic scenarios in weeks 9–10. It is a demonstration measure, not a validated false-positive rate.</p>}</section>
          </>}
        </div><aside className="controls-column" aria-label="Analysis controls"><section className="panel student-panel"><p className="eyebrow">YOUR FOCUS</p><h2>Student selection</h2><label htmlFor="student-select">Student pseudonym</label><select id="student-select" value={studentId} onChange={e=>setStudentId(e.target.value)}>{students.map(s=><option key={s.id} value={s.id}>{s.id}{!importedStudents&&showLabels&&CATEGORY_META[s.category]?` — ${CATEGORY_META[s.category].label}`:""}</option>)}</select>{!importedStudents&&<label className="checkbox"><input type="checkbox" checked={showLabels} onChange={e=>setShowLabels(e.target.checked)}/>Show demo scenario labels</label>}<p className="help">Choose a student to inspect their activity and method flags.</p></section>
          <section className="panel parameter-panel"><div className="panel-head"><div><p className="eyebrow">TUNE THE SIGNAL</p><h2>Detector settings</h2></div><span className="badge">Live</span></div><p className="help">Changes recalculate this preview. They are not saved as database runs.</p><SliderField label="Baseline window" suffix="weeks" value={k} min={2} max={6} step={1} onChange={setK}/><SliderField label="CAP log-decline threshold" value={tauIndLog} min={0.1} max={0.8} step={0.05} onChange={setTauIndLog} format={v=>v.toFixed(2)}/><SliderField label="CAP cohort percentile" value={tauCtx} min={0.3} max={0.95} step={0.05} onChange={setTauCtx} format={v=>`${Math.round(v*100)}%`}/><SliderField label="Persistence" suffix="weeks" value={p} min={1} max={4} step={1} onChange={setP}/><details className="baseline-settings"><summary>Comparison method settings</summary><SliderField label="Individual relative-drop threshold" value={tauInd} min={0.2} max={0.8} step={0.05} onChange={setTauInd} format={v=>v.toFixed(2)}/><SliderField label="Fixed threshold" suffix="clicks" value={fixedThreshold} min={2} max={80} step={2} onChange={setFixedThreshold}/></details><p className="help">CAP lag: 3 weeks. Course median is a visual reference, not the CAP context statistic.</p></section>
          <section className="review-note"><span aria-hidden="true">◎</span><h3>A signal starts a conversation.</h3><p>Activity flags support human review. They do not prove disengagement or academic risk.</p></section>
        </aside></div>
        <footer className="page-footer"><span>EngageTrace <b>·</b> Course-context-aware activity analysis</span><span>{importedStudents?"Imported activity · no outcome labels":"Synthetic preview · research validation pending"}</span></footer>
      </main>
    </div>
  </div>;
}
function SliderField({label,value,min,max,step,onChange,format,suffix}) {
  const id=useId();
  return <div className="slider-field"><div><label htmlFor={id}>{label}</label><output htmlFor={id}>{format?format(value):`${value}${suffix?` ${suffix}`:""}`}</output></div><input id={id} type="range" value={value} min={min} max={max} step={step} onChange={e=>onChange(Number(e.target.value))}/></div>;
}
function MethodStrip({results,weeksCount}) {
  return <div className="table-scroll"><table className="method-strip"><caption>Weekly detector flags: ● flagged, · not flagged</caption><thead><tr><th scope="col">Detector</th>{Array.from({length:weeksCount},(_,i)=><th scope="col" key={i}>W{i+1}</th>)}</tr></thead><tbody>{METHODS.map(m=><tr key={m.key}><th scope="row">{m.label}</th>{Array.from({length:weeksCount},(_,i)=><td key={i} style={{color:results[m.key][i]?m.color:"#777"}} aria-label={`Week ${i+1}: ${results[m.key][i]?"flagged":"not flagged"}`}><span className={results[m.key][i]?"flag-cell on":"flag-cell"} style={results[m.key][i]?{background:m.color,color:"white"}:undefined}>{results[m.key][i]?"●":"·"}</span></td>)}</tr>)}</tbody></table></div>;
}
