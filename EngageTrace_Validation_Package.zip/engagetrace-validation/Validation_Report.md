# Validation and dashboard review

The COSC722 guide was applied through explicit protocol and preprocessing, versioned methods, matched ablations, temporal scoring, uncertainty, critical interpretation, and reproducibility.

## Transfer population and provenance

Eight AAA/EEE/GGG presentations contain 4,578 eligible enrollments representing 4,550 distinct students after exclusions. Five reused seeds sample 300 per presentation, with five groups of 60. Each selected sample is evaluated with two- and four-week shared lulls and two scoring windows. This creates 384,000 method-window-case records, not 384,000 independent people.

The previously inspected transfer population, seeds, transformations, and parameters were retained. The run is an exploratory audit, not a newly untouched test. Original code/results remain intact.

## Six-week transfer results

| Shared lull | Method | Positive detection | Negative flagging | Strict positive detection | Positive pre-onset alarms |
|---|---|---:|---:|---:|---:|
| 2 weeks | Fixed | 0.703 | 0.502 | 0.356 | 0.359 |
| 2 weeks | CAP | 0.535 | 0.255 | 0.493 | 0.085 |
| 2 weeks | Park Poisson adaptation | 0.783 | 0.623 | 0.111 | 0.743 |
| 4 weeks | Fixed | 0.741 | 0.515 | 0.379 | 0.374 |
| 4 weeks | CAP | 0.524 | 0.241 | 0.479 | 0.095 |
| 4 weeks | Park Poisson adaptation | 0.761 | 0.612 | 0.105 | 0.735 |

These are equal-weight presentation means averaged over seeds/scenarios. CAP reduces both detections and control flags. The Poisson adaptation detects more positive scenarios but flags many controls and often alarms before onset. Its low strict rate must not be read as proof that CAP is superior to the original published method: aggregation scale, prefix refitting, signal direction, repeated testing, and lack of persistence differ.

## Audit correction

The earlier transfer scorer checked pre-onset flags only after week 6. This omitted early fixed and CUSUM alarms. Correcting the entire pre-onset interval changes 2,840 fixed and 1,096 CUSUM case records across the two shared-lull lengths. The 168,000 previously reported six-week method-case flags are unchanged. Corrected strict rates should replace any strict rates derived from the earlier transfer script.

A new episode means a false-to-true transition within the window. Strict detection instead excludes all sequences with any earlier alarm; these are different measures.

## Dashboard correction

The raw individual-history baseline used an immediate historical window. It now uses the same k-week baseline and L-week gap as revised Python. On 19 fixtures/configurations, mismatches decrease from 716 to zero across 38,688 flags. CAP, fixed, and CUSUM had no mismatches before the fix on these fixtures. A golden regression test and rebuilt JavaScript bundle are supplied. Visual design and existing import controls are retained. No remote deployment, hosted-database creation, or usability study was performed.

## Remaining limits

The same data informed earlier development, the original controlled cohort was tuned, and transfer outcomes were previously inspected. Stable-enrollment eligibility uses future enrollment status and activity, so this is a retrospective selected population. Multiple seeds and some presentations reuse students. All event labels are injected; natural declines remain among controls. No educational disengagement labels, intervention effects, or demographic fairness have been validated. The original daily Bernoulli/Poisson study is not fully replicated. Independent, prospectively specified validation remains necessary for stronger effectiveness claims.
