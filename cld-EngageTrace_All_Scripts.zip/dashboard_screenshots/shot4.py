from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={'width':1280,'height':900},device_scale_factor=2)
    pg.goto('file:///tmp/claude-0/-home-claude/970a3a35-2242-5d95-bf97-4240b7c5ce89/scratchpad/dash/checked.html')
    pg.wait_for_timeout(1500)
    pg.get_by_text('Method comparison').first.click(); pg.wait_for_timeout(1500)
    pg.screenshot(path='dash/c2.png',full_page=True)
    t=pg.inner_text('main') if pg.query_selector('main') else pg.inner_text('body')
    print(t[:2500])
    b.close()
