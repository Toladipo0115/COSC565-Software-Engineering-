from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={'width':1280,'height':900},device_scale_factor=2)
    pg.goto('file:///tmp/claude-0/-home-claude/970a3a35-2242-5d95-bf97-4240b7c5ce89/scratchpad/dash/engagetrace_dashboard.html')
    pg.wait_for_timeout(1500)
    pg.get_by_text('Cohort summary').first.click(); pg.wait_for_timeout(1500)
    pg.screenshot(path='dash/cohort.png',full_page=True)
    b.close()
