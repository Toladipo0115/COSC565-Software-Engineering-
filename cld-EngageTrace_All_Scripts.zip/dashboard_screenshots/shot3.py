from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={'width':1280,'height':900},device_scale_factor=2)
    pg.on('console',lambda m:print('c',m.text[:150]))
    pg.goto('file:///tmp/claude-0/-home-claude/970a3a35-2242-5d95-bf97-4240b7c5ce89/scratchpad/dash/checked.html')
    pg.wait_for_timeout(2500)
    pg.screenshot(path='dash/c1.png',full_page=True)
    print(pg.inner_text('body')[:1500])
    b.close()
