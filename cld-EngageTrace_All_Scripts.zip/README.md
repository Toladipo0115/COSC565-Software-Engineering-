# Scripts used for the EngageTrace revision

experiments/        Analysis scripts (Python). Run from this folder.
  core.py           Vectorized detectors (CAP, raw history, fixed, no context, CUSUM, Poisson adaptation), scoring, metrics
  frozen.py         Rebuilds the frozen test sets (seed 20261015, 300 per presentation)
  validate.py       Checks vectorized CAP against the repository detector (expects 0 mismatches)
  whichcode.py, legacy.py   Which repository code the paper used; legacy raw-scale detector
  run1.py, run2.py  Primary comparisons; development and transfer sets
  match.py          Matched alert rate sweeps
  lull.py           Shared lull and lull free control
  run3.py           Filter, development sensitivity, per-presentation differences, precision
  run4.py           Per-presentation lull deltas and exact sign-flip tests
  run5.py           Real withdrawal anchor
  samp.py, v2.py    Sampling and variant checks
  newnums.py        Collects every number quoted in the manuscript
  example.py        Worked example students for Fig. 3
  figs.py, figs2.py Figures
results/            JSON outputs used for the paper tables
manuscript_build/   python-docx builder for the IEEE template
  lib.py            Builder (styles, tables, figures, equations as OMML via pandoc)
  main.py           Manuscript text and tables; refs.txt holds the 32 references
  main_before_renum.py  Version before references were renumbered by first appearance
dashboard_screenshots/  Playwright scripts that rendered the dashboard figure

Set before running experiments:
  export ENGAGETRACE_DB=/path/to/engagetrace.db
  export ENGAGETRACE_VALIDATION_CODE=/path/to/EngageTrace_Validation_Package/engagetrace-validation/code
Needs python 3.10+, numpy, matplotlib, python-docx, lxml, pandoc, LibreOffice (preview only), Playwright with Chromium (screenshots only).
Paths inside some scripts are relative to the original working folders and may need adjusting.
