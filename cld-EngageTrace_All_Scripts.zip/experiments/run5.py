from core import *
from frozen import FROZEN
import itertools
regs = list(csv.DictReader(open(REG)))
W = 39
pools = {}; wd = {}
seen = set()
with sqlite3.connect(f'file:{Path(DB).resolve()}?mode=ro', uri=True) as con:
    for c in sorted(FROZEN):
        ids = []
        for r in regs:
            if r['code_module'] + '_' + r['code_presentation'] != c: continue
            if r['date_registration'] in ('', '?') or int(r['date_registration']) > 0: continue
            ids.append(r['id_student'])
            wd[(c, r['id_student'])] = (int(r['date_unregistration']) // 7 + 1) if r['date_unregistration'] not in ('', '?') else None
        m = {s: [0] * W for s in ids}
        for sid, w, x in con.execute('SELECT student_id,week,clicks FROM weekly_activity WHERE course_id=? AND week BETWEEN 1 AND ?', (c, W)):
            if sid in m: m[sid][w - 1] = x
        for s in list(m):
            if not sum(m[s]): del m[s]
        pools[c] = m
METH = {'CAP': f_cap, 'Fixed': f_fixed, 'Raw history': f_raw, 'Log decline only': f_noctx, 'CUSUM': f_cusum}
agg = {m: dict(wd_n=0, wd_flagged=0, leads=[], nw_n=0, nw_flagged=0, sw_pos=0, sw_pos_flag=0, sw_neg=0, sw_neg_flag=0) for m in METH}
H = 6; START = 10; END = 30
for c, p in pools.items():
    ids = sorted(p); M = np.array([p[s] for s in ids], dtype=float); F = feats(M)
    wk = np.array([wd[(c, s)] if wd[(c, s)] is not None else 10**6 for s in ids])
    for nm, fn in METH.items():
        fl = fn(F); a = agg[nm]
        for i in range(len(ids)):
            Wi = wk[i]
            if Wi < 10**6:
                # withdrawer with enough history: withdrawal after START
                if Wi <= START or Wi > END + H: continue
                last = min(Wi - 1, END)           # weeks while still registered (1-based)
                a['wd_n'] += 1
                fw = [t + 1 for t in range(7, last) if fl[i, t]]   # flags at weeks 8..last
                if fw: a['wd_flagged'] += 1; a['leads'].append(Wi - fw[0])
                for t in range(START, last + 1):                    # student-weeks at week t=START..last
                    pos = (Wi - t) <= H and (Wi - t) >= 1
                    if pos: a['sw_pos'] += 1; a['sw_pos_flag'] += int(fl[i, t - 1])
                    else: a['sw_neg'] += 1; a['sw_neg_flag'] += int(fl[i, t - 1])
            else:
                a['nw_n'] += 1
                if fl[i, 7:END].any(): a['nw_flagged'] += 1
                for t in range(START, END + 1):
                    a['sw_neg'] += 1; a['sw_neg_flag'] += int(fl[i, t - 1])
out = {}
for nm, a in agg.items():
    base = a['sw_pos'] / (a['sw_pos'] + a['sw_neg'])
    tpr = a['sw_pos_flag'] / a['sw_pos']; fpr = a['sw_neg_flag'] / a['sw_neg']
    out[nm] = dict(withdrawers=a['wd_n'], wd_ever_flagged=a['wd_flagged'] / a['wd_n'], median_lead=float(np.median(a['leads'])) if a['leads'] else None,
                   mean_lead=float(np.mean(a['leads'])) if a['leads'] else None,
                   nonwd=a['nw_n'], nonwd_ever_flagged=a['nw_flagged'] / a['nw_n'],
                   sw_sensitivity=tpr, sw_alert_rate_other=fpr, sw_base_rate=base, sw_precision=a['sw_pos_flag'] / (a['sw_pos_flag'] + a['sw_neg_flag']), lift=(a['sw_pos_flag'] / (a['sw_pos_flag'] + a['sw_neg_flag'])) / base)
    print(nm, {k: (round(v, 3) if isinstance(v, float) else v) for k, v in out[nm].items()})
json.dump(out, open('run5.json', 'w'))
