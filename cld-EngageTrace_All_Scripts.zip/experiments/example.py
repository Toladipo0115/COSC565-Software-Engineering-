from core import *
from frozen import load_frozen
sets = [S for S in make_sets(load_frozen(False), [4], seeds=[20261015])]
cands = {'ctrl': [], 'pos': []}
for S in sets:
    F = feats(S['M']); cap = f_cap(F); raw = f_raw(F); log = f_noctx(F); fx = f_fixed(F)
    scen = np.array(S['scen']); n = S['M'].shape[0]
    for i in range(n):
        m = S['M'][i]
        if scen[i] == 'quiet_only' and not cap[i].any() and raw[i, 6:13].any() and log[i, 6:13].any() and m[:6].mean() > 15 and not fx[i].any():
            cands['ctrl'].append((S['course'], i, m[:6].mean()))
        if scen[i] == 'sustained' and cap[i, 11:16].any() and not cap[i, :11].any() and not raw[i, :11].any() and not log[i, :11].any() and m[:11].mean() > 20 and not fx[i, :11].any():
            first = int(np.argmax(cap[i])) + 1
            cands['pos'].append((S['course'], i, m[:11].mean(), first))
print(len(cands['ctrl']), len(cands['pos']))
print(cands['ctrl'][:8]); print(cands['pos'][:8])
