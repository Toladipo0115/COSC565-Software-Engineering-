from core import *
pool = load_pool(TEST, dev_students()); sets = make_sets(pool, [2, 4])
cfg = RevisedConfig(k=3, lag=3, tau_ind_raw=0.5, tau_ind_log=0.2, tau_ctx_pct=0.6, p=3, fixed_threshold=6.0)
from collections import Counter
c = Counter(); ex=[]
for S in sets[:30]:
    mat = {i: list(map(int, S['M'][i])) for i in range(len(S['ids']))}
    ref = detect_revised(mat, cfg); F = feats(S['M'])
    for name, fl in [('cap', f_cap(F)), ('cap_no_context', f_noctx(F)), ('individual', f_raw(F)), ('fixed', f_fixed(F)), ('cusum', f_cusum(F))]:
        r = np.array([ref[i][name] for i in range(len(S['ids']))])
        d = np.argwhere(r != fl)
        c[name] += len(d)
        for i, t in d[:1]: ex.append((name, S['course'], i, t, S['M'][i].tolist(), r[i, t], fl[i, t]))
print(c); 
for e in ex[:4]: print(e)
