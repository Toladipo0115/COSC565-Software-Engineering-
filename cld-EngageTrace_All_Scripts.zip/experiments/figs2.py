import json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from core import *
from frozen import load_frozen
plt.rcParams.update({'font.family': 'DejaVu Serif', 'font.size': 7, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.grid': True, 'grid.color': '#e8e8e8', 'grid.linewidth': .5, 'axes.edgecolor': '#555', 'figure.dpi': 300, 'axes.linewidth': .6})
C = {'CAP': '#0072B2', 'Raw history': '#D55E00', 'Fixed': '#009E73', 'CUSUM': '#CC79A7', 'Log decline only': '#E69F00', 'Excess-decline CAP': '#56B4E9'}
W = 3.4
# ---- Fig 1 pipeline
fig, ax = plt.subplots(figsize=(W, 2.15)); ax.axis('off'); ax.set_xlim(0, 10); ax.set_ylim(0, 6.4)
def box(x, y, w, h, t, fc='#f4f4f4', ec='#555', fs=6.2):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.02,rounding_size=0.15', fc=fc, ec=ec, lw=.7)); ax.text(x + w / 2, y + h / 2, t, ha='center', va='center', fontsize=fs)
def arrow(x1, y1, x2, y2): ax.annotate('', xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle='-|>', lw=.7, color='#333'))
box(0.1, 4.3, 3.0, 1.7, 'Weekly clicks\n$x_{it}$')
box(3.5, 4.3, 3.0, 1.7, 'Log scale\n$y_{it}=\\ln(1+x_{it})$')
box(6.9, 4.3, 3.0, 1.7, 'Lagged baseline\n$b_{it}$ = median of\n$y_{i,t-L-k..t-L-1}$')
box(0.1, 2.0, 3.0, 1.7, 'Decline\n$d_{it}=b_{it}-y_{it}$', fc='#e3f0fa')
box(3.5, 2.0, 3.0, 1.7, 'Cohort rank\n$r_{it}$ of $d_{it}$\nin week $t$', fc='#e3f0fa')
box(6.9, 2.0, 3.0, 1.7, 'Condition\n$c_{it}$: $d\\geq\\tau_{ind}$\nand $r\\geq\\tau_{ctx}$', fc='#e3f0fa')
box(0.1, -0.3, 4.6, 1.7, 'Run length $m_{it}$\n$c_{it}(m_{i,t-1}+1)$', fc='#fdebd8')
box(5.3, -0.3, 4.6, 1.7, 'Flag if $m_{it}\\geq p$\n(review prompt)', fc='#d9f0e6')
for a, b in [((3.1, 5.15), (3.5, 5.15)), ((6.5, 5.15), (6.9, 5.15)), ((3.1, 2.85), (3.5, 2.85)), ((6.5, 2.85), (6.9, 2.85)), ((4.7, 0.55), (5.3, 0.55))]: arrow(*a, *b)
arrow(8.4, 4.3, 1.6, 3.7); arrow(8.4, 2.0, 2.4, 1.4)
ax.set_ylim(-0.5, 6.2)
fig.savefig('nf/fig1_pipeline.png', bbox_inches='tight', pad_inches=.03); plt.close(fig)
# ---- Fig 2 worked example
sets = make_sets(load_frozen(False), [4], seeds=[20261015])
S = [s for s in sets if s['course'] == 'BBB_2013B'][0]; F = feats(S['M'])
flags = {'CAP': f_cap(F), 'Raw history': f_raw(F), 'Log decline only': f_noctx(F)}
med = np.median(np.log1p(S['M']), axis=0)
fig, axs = plt.subplots(2, 1, figsize=(W, 3.5), sharex=True)
for ax, i, ttl, lull in [(axs[0], 183, '(a) No individual change; 4-week shared lull', True), (axs[1], 106, '(b) Sustained individual decline from week 12', False)]:
    wk = np.arange(1, 21); y = np.log1p(S['M'][i])
    ax.axvspan(6.5, 10.5, color='#e6e6e6', lw=0); ax.plot(wk, med, '--', color='#777', lw=1, label='Cohort median')
    ax.plot(wk, y, '-o', color='#222', ms=2.5, lw=1, label='Student')
    for k, (nm, col) in enumerate([('Raw history', C['Raw history']), ('Log decline only', C['Log decline only']), ('CAP', C['CAP'])]):
        w = np.where(flags[nm][i])[0] + 1; ax.plot(w, np.full(len(w), -0.55 - 0.4 * k), 's', color=col, ms=3.2, label=nm + ' flag')
    ax.set_ylim(-1.8, 6.5); ax.set_title(ttl, fontsize=6.6, loc='left'); ax.set_ylabel('ln(1 + clicks)')
    if i == 183: ax.text(8.5, 6.1, 'lull', ha='center', fontsize=6.5, color='#555')
axs[1].set_xlabel('Week'); h, l = axs[0].get_legend_handles_labels()
axs[1].set_xticks(range(1, 21, 2))
fig.tight_layout(h_pad=.6, rect=(0, 0.1, 1, 1)); fig.legend(h, l, frameon=False, fontsize=5.8, ncol=3, loc='lower center', handlelength=1.0, columnspacing=1.0); fig.savefig('nf/fig2_example.png'); plt.close(fig)
# ---- Fig 3 curves
R = json.load(open('curves_all.json'))
FAM = {'CAP': ['CAP (rank cutoff)'], 'Raw history': ['Raw-history rule'], 'Fixed': ['Fixed threshold'], 'CUSUM': ['CUSUM'], 'Log decline only': ['Log decline only']}
DEF = {'CAP': 'tc=0.6', 'Raw history': 'tr=0.5', 'Fixed': 'th=6', 'CUSUM': 'H=2', 'Log decline only': 'ti=0.2'}
MK = {'CAP': 'o', 'Raw history': 's', 'Fixed': '^', 'CUSUM': 'D', 'Log decline only': 'v'}
fig, axs = plt.subplots(2, 1, figsize=(W, 4.3), sharex=True)
for ax, w, ttl in zip(axs, ['to_end', 'w6'], ['(a) Primary window (onset to week 20)', '(b) Six-week window']):
    for m, fams in FAM.items():
        pts = sorted([(r['fa'], r['det'], r['setting']) for r in R if r['split'] == 'frozen' and r['q'] == 2 and r['window'] == w and r['family'] in fams])
        ax.plot([p[0] for p in pts], [p[1] for p in pts], '-', color=C[m], lw=1.1, label=m)
        d = [p for p in pts if p[2] == DEF[m]]
        if d: ax.plot(d[0][0], d[0][1], MK[m], color=C[m], ms=5.5, mec='white', mew=.8)
    ax.set_title(ttl, fontsize=6.8, loc='left'); ax.set_ylabel('Detection rate'); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
axs[1].set_xlabel('Control flag rate'); axs[0].legend(frameon=False, fontsize=5.8, loc='lower right')
fig.tight_layout(h_pad=.5); fig.savefig('nf/fig3_curves.png'); plt.close(fig)
# ---- Fig 4 lull effect
r4 = json.load(open('run4.json'))['frozen']; names = ['CAP', 'Raw history', 'Log decline only', 'Fixed', 'CUSUM']
fig, axs = plt.subplots(1, 2, figsize=(W, 2.2), sharey=True)
for ax, q in zip(axs, [2, 4]):
    for i, m in enumerate(names):
        e = r4[f'{m}|q{q}']; ax.bar(i, e['mean'] * 100, color=C[m], width=.62)
        ax.scatter([i] * len(e['per_course']), np.array(e['per_course']) * 100, s=4, color='#222', zorder=3)
    ax.axhline(0, color='#333', lw=.6); ax.set_xticks(range(5)); ax.set_xticklabels(['CAP', 'Raw', 'Log', 'Fixed', 'CUSUM'], fontsize=5.8)
    ax.set_title(f'{q}-week lull', fontsize=6.8); ax.grid(axis='x', visible=False)
axs[0].set_ylabel('Change in control alarms\nvs. no lull (points)', fontsize=6.4)
fig.tight_layout(w_pad=.4); fig.savefig('nf/fig4_lull.png'); plt.close(fig)
# ---- Fig 5 sensitivity
S5 = [e for e in json.load(open('run3.json'))['sensitivity_dev'] if e['window'] == 'to_end']
fig, axs = plt.subplots(2, 3, figsize=(W, 2.9), sharey=True); axs = axs.ravel()
for ax, (p, lab, dv) in zip(axs, [('tau_ind', 'Decline cutoff', .2), ('tau_ctx', 'Rank cutoff', .6), ('p', 'Persistence p', 3), ('k', 'Baseline length k', 3), ('lag', 'Lag L', 3)]):
    pts = [e for e in S5 if e['param'] == p]; x = [e['value'] for e in pts]
    ax.plot(x, [e['det'] for e in pts], '-o', color=C['CAP'], ms=2.3, lw=.9, label='Detection'); ax.plot(x, [e['fa'] for e in pts], '-s', color=C['Raw history'], ms=2.3, lw=.9, label='Control flags')
    ax.axvline(dv, color='#999', lw=.6, ls=':'); ax.set_xlabel(lab, fontsize=6.2); ax.tick_params(labelsize=5.8); ax.set_ylim(0, 1)
axs[5].axis('off'); h, l = axs[0].get_legend_handles_labels(); axs[5].legend(h, l, frameon=False, fontsize=6, loc='center')
axs[0].set_ylabel('Rate', fontsize=6.4); axs[3].set_ylabel('Rate', fontsize=6.4)
fig.tight_layout(h_pad=.5, w_pad=.3); fig.savefig('nf/fig5_sens.png'); plt.close(fig)
print('ok')
