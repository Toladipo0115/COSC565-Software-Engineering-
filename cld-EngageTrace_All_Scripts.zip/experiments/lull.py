from core import *
import pickle
from frozen import load_frozen
R = json.load(open('curves_all.json'))
# delta for excess-decline chosen on DEV only: closest control flag rate to CAP default (q=2,to_end)
cap = [r for r in R if r['split']=='dev' and r['q']==2 and r['window']=='to_end' and r['family']=='CAP (rank cutoff)' and r['setting']=='tc=0.6'][0]
ex = [r for r in R if r['split']=='dev' and r['q']==2 and r['window']=='to_end' and r['family']=='Excess-decline CAP']
best = min(ex, key=lambda r: abs(r['fa'] - cap['fa'])); DELTA = float(best['setting'].split('=')[1])
print('dev CAP fa', round(cap['fa'],3), 'chosen delta', DELTA, 'dev excess fa', round(best['fa'],3), 'det', round(best['det'],3), 'vs CAP det', round(cap['det'],3))
purge = dev_students()
splits = {'frozen': make_sets(load_frozen(False), [0, 2, 4], seeds=[20261015]),
          'transfer': make_sets(load_pool(TEST, purge), [0, 2, 4]),
          'dev': make_sets(load_pool(DEV), [0, 2, 4])}
METH = {'CAP': lambda F: f_cap(F), 'Excess-decline CAP': lambda F: f_excess(F, 0.2, DELTA), 'Fixed': lambda F: f_fixed(F), 'Raw history': lambda F: f_raw(F), 'CUSUM': lambda F: f_cusum(F), 'Log decline only': lambda F: f_noctx(F)}
CTRL = {'no_change', 'temporary', 'quiet_only'}
out = {}
for sp, sets in splits.items():
    # key: (course,seed) -> q -> flags per method
    store = defaultdict(dict)
    for S in sets:
        F = feats(S['M']); fl = {m: f(F) for m, f in METH.items()}
        if sp == 'frozen' or True:
            mat = {i: list(map(int, S['M'][i])) for i in range(S['M'].shape[0])}
            pk = detect_park_prefix(mat); fl['Park Poisson'] = np.array([pk[i] for i in range(S['M'].shape[0])])
        store[(S['course'], S['seed'])][S['q']] = (S, fl)
    res = defaultdict(lambda: defaultdict(list))
    for key, d in store.items():
        S0 = d[0][0]; scen = np.array(S0['scen'])
        for m in d[0][1]:
            for q in [0, 2, 4]:
                S, fl = d[q]; flags = fl[m]
                lullwin = flags[:, 6:].any(1)                      # any flag weeks 7-20
                a_end, pre, st = score(S, flags, 'to_end'); a_w6, _, st6 = score(S, flags, 'w6')
                for c in SCEN:
                    sel = scen == c
                    res[(m, q)][c].append(dict(course=key[0], lull=lullwin[sel], end=a_end[sel], w6=a_w6[sel], strict=st[sel]))
    # reduce
    tab = []
    for (m, q), byc in res.items():
        for c, lst in byc.items():
            lull = np.concatenate([x['lull'] for x in lst]); end = np.concatenate([x['end'] for x in lst]); w6 = np.concatenate([x['w6'] for x in lst]); st = np.concatenate([x['strict'] for x in lst])
            tab.append(dict(method=m, q=q, scenario=c, n=len(lull), lull_window_alarm=lull.mean(), alarm_end=end.mean(), alarm_w6=w6.mean(), strict_end=st.mean()))
    out[sp] = tab
    # paired new/lost for controls, lull window
    pair = []
    for m in METH.keys() | {'Park Poisson'}:
        for q in [2, 4]:
            new = lost = both = n = 0
            for key, d in store.items():
                S0 = d[0][0]; scen = np.array(S0['scen']); ctrl = np.isin(scen, list(CTRL))
                a0 = d[0][1][m][:, 6:].any(1)[ctrl]; aq = d[q][1][m][:, 6:].any(1)[ctrl]
                new += int((aq & ~a0).sum()); lost += int((~aq & a0).sum()); both += int((aq & a0).sum()); n += int(ctrl.sum())
            from math import comb
            nd = new + lost; k = min(new, lost)
            p = min(1.0, 2 * sum(comb(nd, i) for i in range(0, k + 1)) / 2 ** nd) if nd else 1.0
            pair.append(dict(method=m, q=q, n=n, rate_q0=(both + lost) / n, rate_q=(both + new) / n, new=new, lost=lost, mcnemar_p=p))
    out[sp + '_pair'] = pair
json.dump(out, open('lull.json', 'w'), indent=1, default=float)
for sp in ['frozen']:
    print(sp)
    for r in out[sp + '_pair']: print({k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items()})
