from frozen import *
import core
pools = load_frozen(False)
def run(sampler, label):
    tot = {}
    for q in [2]:
        res = []
        P = {c: v for c, v in pools.items()}
        det = fa = 0; npos = nneg = 0; fdet = ffa = 0
        for c in sorted(P):
            ids = sampler(c, sorted(P[c]))
            scen = [SCEN[j // 60] for j in range(300)]
            rows = []
            for j, sid in enumerate(ids):
                v = P[c][sid][:]
                for w in range(7, 7 + q): v[w - 1] = round(v[w - 1] * .5)
                cc = scen[j]
                if cc in POS:
                    for w in range(ONS[cc], 21): v[w - 1] = round(v[w - 1] * .25)
                elif cc == 'temporary': v[14] = round(v[14] * .25)
                rows.append(v)
            S = dict(onset=np.array([ONS[x] - 1 for x in scen]), pos=np.array([x in POS for x in scen]))
            F = feats(np.array(rows, dtype=float))
            for nm, fl in [('cap', f_cap(F)), ('fixed', f_fixed(F))]:
                a, pre, st = score(S, fl, 'to_end')
                tot[nm] = tot.get(nm, [0, 0]); tot[nm][0] += int(a[S['pos']].sum()); tot[nm][1] += int(a[~S['pos']].sum())
    print(label, tot)
SEED = 20261015
run(lambda c, ids: random.Random(f'{c}:{SEED}').sample(ids, 300), 'course:seed str')
run(lambda c, ids: random.Random(SEED).sample(ids, 300), 'Random(seed) per course')
run(lambda c, ids: random.Random(f'{SEED}:{c}').sample(ids, 300), 'seed:course str')
