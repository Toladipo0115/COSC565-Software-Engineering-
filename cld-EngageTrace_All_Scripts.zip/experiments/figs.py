import json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.grid': True, 'grid.color': '#e6e6e6', 'grid.linewidth': .6, 'axes.edgecolor': '#555', 'figure.dpi': 200})
C = {'CAP': '#0072B2', 'Raw history': '#D55E00', 'Fixed': '#009E73', 'CUSUM': '#CC79A7', 'Log decline only': '#E69F00', 'Excess-decline CAP': '#56B4E9'}
MK = {'CAP': 'o', 'Raw history': 's', 'Fixed': '^', 'CUSUM': 'D', 'Log decline only': 'v', 'Excess-decline CAP': 'P'}
R = json.load(open('curves_all.json'))
FAM = {'CAP': ['CAP (rank cutoff)'], 'Raw history': ['Raw-history rule'], 'Fixed': ['Fixed threshold'], 'CUSUM': ['CUSUM'], 'Log decline only': ['Log decline only'], 'Excess-decline CAP': ['Excess-decline CAP']}
DEF = {'CAP': 'tc=0.6', 'Raw history': 'tr=0.5', 'Fixed': 'th=6', 'CUSUM': 'H=2', 'Log decline only': 'ti=0.2', 'Excess-decline CAP': 'delta=0.3'}
# Fig 1
fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.2), sharey=True)
for ax, w, ttl in zip(axs, ['to_end', 'w6'], ['Primary window (onset to week 20)', 'Six-week window']):
    for m, fams in FAM.items():
        pts = sorted([(r['fa'], r['det'], r['setting']) for r in R if r['split'] == 'frozen' and r['q'] == 2 and r['window'] == w and r['family'] in fams])
        ax.plot([p[0] for p in pts], [p[1] for p in pts], '-', color=C[m], lw=1.3, alpha=.9, label=m)
        d = [p for p in pts if p[2] == DEF[m]]
        if d: ax.plot(d[0][0], d[0][1], MK[m], color=C[m], ms=7, mec='white', mew=1.0)
    ax.set_title(ttl, fontsize=9); ax.set_xlabel('Control flag rate'); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
axs[0].set_ylabel('Detection rate'); axs[0].legend(frameon=False, fontsize=7.5, loc='lower right')
fig.tight_layout(); fig.savefig('figs/fig_operating_points.png'); plt.close(fig)
# Fig 2 lull-attributable
r4 = json.load(open('run4.json'))['frozen']
fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.0), sharey=True)
names = ['CAP', 'Raw history', 'Log decline only', 'Fixed', 'CUSUM']
for ax, q in zip(axs, [2, 4]):
    for i, m in enumerate(names):
        e = r4[f'{m}|q{q}']; ax.bar(i, e['mean'] * 100, color=C[m], width=.6)
        ax.scatter([i] * len(e['per_course']), np.array(e['per_course']) * 100, s=9, color='#333', zorder=3)
    ax.axhline(0, color='#333', lw=.8); ax.set_xticks(range(len(names))); ax.set_xticklabels(['CAP', 'Raw\nhistory', 'Log decline\nonly', 'Fixed', 'CUSUM'], fontsize=7.5)
    ax.set_title(f'{q}-week shared lull', fontsize=9); ax.grid(axis='x', visible=False)
axs[0].set_ylabel('Change in control alarms\nvs. no lull (points)')
fig.tight_layout(); fig.savefig('figs/fig_lull_effect.png'); plt.close(fig)
# Fig 3 filter pass
f = json.load(open('run3.json'))['filter']['2']
wk = list(range(7, 21)); fig, ax = plt.subplots(figsize=(3.5, 2.8))
for k, c, lab, ls in [('decline>=0.2', '#D55E00', 'Student decline ≥ 0.2', '-'), ('rank>=0.6', '#0072B2', 'Cohort rank ≥ 0.6', '-'), ('excess>=0.3', '#56B4E9', 'Excess over cohort median ≥ 0.3', '--')]:
    ax.plot(wk, np.array(f[k]) * 100, ls, color=c, lw=1.5, label=lab)
ax.axvspan(7, 8, color='#ddd', alpha=.6, lw=0); ax.text(7.1, 3, 'lull', fontsize=7)
ax.set_xlabel('Week'); ax.set_ylabel('Students passing (%)'); ax.set_ylim(0, 100); ax.legend(frameon=False, fontsize=7, loc='upper right')
fig.tight_layout(); fig.savefig('figs/fig_filter.png'); plt.close(fig)
# Fig 4 sensitivity
S = [e for e in json.load(open('run3.json'))['sensitivity_dev'] if e['window'] == 'to_end']
fig, axs = plt.subplots(1, 5, figsize=(7.4, 2.4), sharey=True)
for ax, (p, lab) in zip(axs, [('tau_ind', 'Decline cutoff'), ('tau_ctx', 'Rank cutoff'), ('p', 'Persistence p'), ('k', 'Baseline length k'), ('lag', 'Lag L')]):
    pts = [e for e in S if e['param'] == p]; x = [e['value'] for e in pts]
    ax.plot(x, [e['det'] for e in pts], '-o', color=C['CAP'], ms=3.5, label='Detection'); ax.plot(x, [e['fa'] for e in pts], '-s', color=C['Raw history'], ms=3.5, label='Control flags')
    dv = {'tau_ind': .2, 'tau_ctx': .6, 'p': 3, 'k': 3, 'lag': 3}[p]; ax.axvline(dv, color='#999', lw=.8, ls=':'); ax.set_xlabel(lab, fontsize=8); ax.tick_params(labelsize=7); ax.set_ylim(0, 1)
axs[0].legend(frameon=False, fontsize=6.5, loc='upper left'); axs[0].set_ylabel('Rate (development)')
fig.tight_layout(); fig.savefig('figs/fig_sensitivity.png'); plt.close(fig)
print('ok')
