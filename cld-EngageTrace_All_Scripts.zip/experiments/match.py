import json, numpy as np
R = json.load(open('curves_all.json'))
def frontier(pts):
    # pts: list of (fa, det); upper-left envelope, monotone nondecreasing det in fa
    pts = sorted(set(pts)); env = []; best = -1
    for fa, d in pts:
        if d > best: env.append((fa, d)); best = d
    return env
def interp(env, x):
    xs = [e[0] for e in env]; ys = [e[1] for e in env]
    if x < xs[0]: return None  # curve never reaches this low alert rate
    if x >= xs[-1]: return ys[-1]
    return float(np.interp(x, xs, ys))
FAMS = ['CAP (grid)', 'CAP (rank cutoff)', 'CAP (decline cutoff)', 'Excess-decline CAP', 'Raw-history rule', 'Fixed threshold', 'CUSUM', 'Log decline only']
def family_points(split, q, w, fam, xk='fa', yk='det'):
    fams = [fam] if fam != 'CAP all' else ['CAP (grid)', 'CAP (rank cutoff)', 'CAP (decline cutoff)']
    return [(r[xk], r[yk]) for r in R if r['split'] == split and r['q'] == q and r['window'] == w and r['family'] in fams]
out = {}
for split in ['frozen', 'dev', 'test']:
    for q in [2, 4]:
        for w in ['to_end', 'w6']:
            cap = [r for r in R if r['split'] == split and r['q'] == q and r['window'] == w and r['family'] == 'CAP (rank cutoff)' and r['setting'] == 'tc=0.6'][0]
            target = cap['fa']
            line = dict(cap_det=cap['det'], cap_fa=target)
            for fam in ['CAP all', 'Excess-decline CAP', 'Raw-history rule', 'Fixed threshold', 'CUSUM', 'Log decline only']:
                env = frontier(family_points(split, q, w, fam))
                line[fam] = interp(env, target)
            # strict version
            capS = cap['strict_fa']
            line['cap_strict_det'] = cap['strict_det']; line['cap_strict_fa'] = capS
            for fam in ['CAP all', 'Excess-decline CAP', 'Raw-history rule', 'Fixed threshold', 'CUSUM', 'Log decline only']:
                env = frontier(family_points(split, q, w, fam, 'strict_fa', 'strict_det'))
                line['S_' + fam] = interp(env, capS)
            out[f'{split}|q{q}|{w}'] = line
for k, v in out.items():
    print(k, {a: (round(b, 3) if b is not None else None) for a, b in v.items()})
json.dump(out, open('matched.json', 'w'), indent=1)
