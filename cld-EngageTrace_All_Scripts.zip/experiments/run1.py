from core import *
import itertools, time, pickle
t0 = time.time()
purge = dev_students()
pools = {'test': load_pool(TEST, purge), 'dev': load_pool(DEV)}
sets = {k: make_sets(v, [0, 2, 4]) for k, v in pools.items()}
print('sets', {k: len(v) for k, v in sets.items()}, 'pool sizes', {k: {c: len(m) for c, m in v.items()} for k, v in pools.items()}, flush=True)
for k in sets:
    for S in sets[k]: S['F'] = feats(S['M'])

CURVES = {
 'CAP (rank cutoff)':   [(f'tc={x}', (lambda F, x=x: f_cap(F, 0.2, x))) for x in [0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.95,0.99]],
 'CAP (decline cutoff)':[(f'ti={x}', (lambda F, x=x: f_cap(F, x, 0.6))) for x in [0.05,0.1,0.15,0.2,0.3,0.4,0.5,0.7,1.0,1.5]],
 'Raw-history rule':    [(f'tr={x}', (lambda F, x=x: f_raw(F, x))) for x in [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.95]],
 'Fixed threshold':     [(f'th={x}', (lambda F, x=x: f_fixed(F, x))) for x in [1,2,3,4,6,8,10,15,20,30]],
 'CUSUM':               [(f'H={x}', (lambda F, x=x: f_cusum(F, x))) for x in [0.5,1,2,3,4,6,8,12]],
 'Log decline only':    [(f'ti={x}', (lambda F, x=x: f_noctx(F, x))) for x in [0.05,0.1,0.15,0.2,0.3,0.4,0.5,0.7,1.0,1.5]],
 'Excess-decline CAP':  [(f'delta={x}', (lambda F, x=x: f_excess(F, 0.2, x))) for x in [0,0.05,0.1,0.2,0.3,0.5,0.7,1.0,1.5]],
}
for ti in [0.1,0.2,0.3,0.5,0.7]:
    for tc in [0.4,0.5,0.6,0.7,0.8,0.9]:
        CURVES.setdefault('CAP (grid)', []).append((f'ti={ti},tc={tc}', (lambda F, a=ti, b=tc: f_cap(F, a, b))))
rows = []
for split in ['test', 'dev']:
    for q in [2, 4]:
        for window in ['to_end', 'w6']:
            for fam, items in CURVES.items():
                for name, fn in items:
                    m, cm = evaluate(sets[split], fn, window, q)
                    rows.append(dict(split=split, q=q, window=window, family=fam, setting=name, **m))
    print(split, 'curves done', round(time.time() - t0), flush=True)
json.dump(rows, open('curves.json', 'w'))
