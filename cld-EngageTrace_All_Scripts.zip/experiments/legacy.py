from core import *
from frozen import load_frozen
from engagetrace_detectors import LegacyConfig, detect_legacy
cfg = LegacyConfig(k=3, tau_ind=0.5, tau_ctx=1.5, p=2, fixed_threshold=6.0)
sets = make_sets(load_frozen(False), [0, 2, 4], seeds=[20261015])
for q in [2, 4]:
    for w in ['to_end', 'w6']:
        res = {'legacy CAP': [], 'revised CAP': []}
        for S in sets:
            if S['q'] != q: continue
            mat = {i: list(map(int, S['M'][i])) for i in range(S['M'].shape[0])}
            lg = detect_legacy(mat, cfg); fl = np.array([lg[i]['cap'] for i in range(S['M'].shape[0])])
            res['legacy CAP'].append((S['course'], metrics(S, fl, w)))
            res['revised CAP'].append((S['course'], metrics(S, f_cap(feats(S['M'])), w)))
        for k, v in res.items():
            m, _ = course_means(v); print(q, w, k, {a: round(b, 3) for a, b in m.items()})
