import re, copy, subprocess, zipfile, io, os, tempfile
from docx import Document
from docx.shared import Pt, Inches, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement, parse_xml
from lxml import etree
TPL = '../conv/tpl.docx'
M_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
class Builder:
    def __init__(self):
        self.d = Document(TPL); self.body = self.d.element.body
        els = list(self.body)
        self.el3 = copy.deepcopy(els[3]); self.el5 = copy.deepcopy(els[5])
        self.title = els[0]
        for e in els[1:96]: self.body.remove(e)
        self.anchor = els[96]           # paragraph holding the 2-column section properties
        self.fig = 0; self.tab = 0; self.eq = 0
    # ---- low level
    IDS = {}
    def _ids(self):
        if not self.IDS:
            for st in self.d.styles.element.findall(qn('w:style')):
                n = st.find(qn('w:name')); self.IDS[n.get(qn('w:val'))] = st.get(qn('w:styleId'))
        return self.IDS
    def setstyle(self, p, name):
        sid = self._ids()[name]; pPr = p._p.get_or_add_pPr()
        for e in pPr.findall(qn('w:pStyle')): pPr.remove(e)
        e = OxmlElement('w:pStyle'); e.set(qn('w:val'), sid); pPr.insert(0, e)
    def _new(self, style):
        p = self.d.add_paragraph(); self.setstyle(p, style); self.anchor.addprevious(p._p); return p
    def runs(self, p, text, size=None, bold=None, italic=None):
        parts = re.split(r'(\*\*.+?\*\*|\*.+?\*|~.+?~|\^.+?\^)', text)
        for part in parts:
            if not part: continue
            if part.startswith('**'): r = p.add_run(part[2:-2]); r.bold = True
            elif part.startswith('*'): r = p.add_run(part[1:-1]); r.italic = True
            elif part.startswith('~'): r = p.add_run(part[1:-1]); r.font.subscript = True
            elif part.startswith('^'): r = p.add_run(part[1:-1]); r.font.superscript = True
            else: r = p.add_run(part)
            if size: r.font.size = Pt(size)
            if bold: r.bold = True
            if italic: r.italic = True
        return p
    # ---- front matter
    def set_title(self, text):
        from docx.text.paragraph import Paragraph
        p = Paragraph(self.title, self.d)
        for r in list(p.runs): r._r.getparent().remove(r._r)
        p.add_run(text)
        self.anchor.addprevious(copy.deepcopy(self.el3))       # end of 1-column title section
    def authors(self, people):
        first = True
        for name, lines in people:
            p = self._new('Author'); 
            if not first:
                r = p.add_run(); br = OxmlElement('w:br'); br.set(qn('w:type'), 'column'); r._r.append(br)
            p.add_run(name); first = False
            p.paragraph_format.space_before = Pt(6)
            for ln in lines:
                a = self._new('Affiliation'); a.add_run(ln)
        sect = copy.deepcopy(self.el5)
        cols = sect.find('.//' + qn('w:cols')); cols.set(qn('w:num'), str(len(people)))
        self.anchor.addprevious(sect)
    # ---- text blocks
    def abstract(self, text, keywords):
        p = self._new('Abstract'); r = p.add_run('Abstract: '); r.bold = True; self.runs(p, text, bold=True)
        k = self._new('Keywords'); kr = k.add_run('Index Terms: '); kr.italic = True; kr.bold = True; k.add_run(keywords).italic = True
    def h1(self, t): return self._new('Heading 1').add_run(t)
    def h2(self, t): return self._new('Heading 2').add_run(t)
    def h5(self, t): return self._new('Heading 5').add_run(t)
    def p(self, t, style='Body Text'):
        para = self._new(style); self.runs(para, t); return para
    def bullet(self, t): return self.p(t, 'bullet list')
    def ref(self, t): return self.p(t, 'references')
    # ---- math
    def omml(self, latex):
        with tempfile.TemporaryDirectory() as td:
            open(td + '/a.md', 'w').write('$$' + latex + '$$\n')
            subprocess.run(['pandoc', '-f', 'markdown', '-t', 'docx', '-o', td + '/a.docx', td + '/a.md'], check=True)
            x = zipfile.ZipFile(td + '/a.docx').read('word/document.xml')
        root = etree.fromstring(x); om = root.find('.//{%s}oMath' % M_NS)
        return om
    def equation(self, latex):
        self.eq += 1
        p = self._new('equation'); p.add_run('\t')
        p._p.append(self.omml(latex))
        r = p.add_run('\t(%d)' % self.eq); r.font.name = 'Times New Roman'
        return p
    # ---- figures and tables
    def figure(self, path, caption, width=3.4):
        self.fig += 1
        p = self._new('Normal'); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_before = Pt(4); p.paragraph_format.keep_with_next = True
        p.add_run().add_picture(path, width=Inches(width))
        c = self._new('figure caption'); self.runs(c, caption); return c
    def table(self, caption, header, rows, widths, align=None, note=None, bold_last=False):
        self.tab += 1
        cap = self._new('table head'); self.runs(cap, caption); cap.paragraph_format.keep_with_next = True
        n = len(header); t = self.d.add_table(rows=1 + len(rows), cols=n); self.anchor.addprevious(t._tbl)
        tblPr = t._tbl.tblPr
        for el in tblPr.findall(qn('w:tblStyle')): tblPr.remove(el)
        lay = OxmlElement('w:tblLayout'); lay.set(qn('w:type'), 'fixed'); tblPr.append(lay)
        jc = OxmlElement('w:jc'); jc.set(qn('w:val'), 'center'); tblPr.append(jc)
        mar = OxmlElement('w:tblCellMar')
        for side, w in [('top', 10), ('left', 45), ('bottom', 10), ('right', 45)]:
            e = OxmlElement('w:' + side); e.set(qn('w:w'), str(w)); e.set(qn('w:type'), 'dxa'); mar.append(e)
        tblPr.append(mar)
        total = int(sum(widths) * 1440)
        w_el = tblPr.find(qn('w:tblW'))
        if w_el is None: w_el = OxmlElement('w:tblW'); tblPr.append(w_el)
        w_el.set(qn('w:w'), str(total)); w_el.set(qn('w:type'), 'dxa')
        grid = t._tbl.tblGrid
        for gc, w in zip(grid.findall(qn('w:gridCol')), widths): gc.set(qn('w:w'), str(int(w * 1440)))
        align = align or (['L'] + ['C'] * (n - 1))
        def setcell(cell, text, bold=False, a='C', w=1.0, borders=()):
            cell.width = Inches(w)
            p = cell.paragraphs[0]; self.setstyle(p, 'table copy')
            p.alignment = {'L': WD_ALIGN_PARAGRAPH.LEFT, 'C': WD_ALIGN_PARAGRAPH.CENTER}[a]
            self.runs(p, text, bold=bold)
            for r in p.runs: r.font.size = Pt(7.5)
            tcPr = cell._tc.get_or_add_tcPr(); b = OxmlElement('w:tcBorders')
            for side in borders:
                e = OxmlElement('w:' + side); e.set(qn('w:val'), 'single'); e.set(qn('w:sz'), '6'); e.set(qn('w:space'), '0'); e.set(qn('w:color'), '000000'); b.append(e)
            tcPr.append(b)
        for j, h in enumerate(header): setcell(t.rows[0].cells[j], h, True, 'L' if align[j] == 'L' else 'C', widths[j], ('top', 'bottom'))
        for i, row in enumerate(rows, 1):
            last = i == len(rows)
            for j, v in enumerate(row): setcell(t.rows[i].cells[j], v, bold_last and last, align[j], widths[j], ('bottom',) if last else ())
        trpr = t.rows[0]._tr.get_or_add_trPr(); th = OxmlElement('w:tblHeader'); trpr.append(th)
        for row in t.rows:
            tp = row._tr.get_or_add_trPr(); cs = OxmlElement('w:cantSplit'); tp.append(cs)
        if note:
            n_ = self._new('Body Text'); self.runs(n_, note, size=8); n_.paragraph_format.space_before=Pt(3); n_.paragraph_format.first_line_indent=Pt(0); n_.alignment=0
        else:
            sp = self._new('Normal'); sp.paragraph_format.space_after = Pt(2)
            for r in sp.runs: r.font.size = Pt(2)
        return t
    def algorithm(self, title, lines):
        self.tab_alg = True
        cap = self._new('Normal'); cap.paragraph_format.space_before = Pt(4); cap.paragraph_format.keep_with_next = True
        r = cap.add_run(title); r.bold = True; r.font.size = Pt(8)
        t = self.d.add_table(rows=1, cols=1); self.anchor.addprevious(t._tbl)
        tblPr = t._tbl.tblPr
        for el in tblPr.findall(qn('w:tblStyle')): tblPr.remove(el)
        c = t.rows[0].cells[0]; c.width = Inches(3.4)
        tcPr = c._tc.get_or_add_tcPr(); b = OxmlElement('w:tcBorders')
        for side in ('top', 'bottom'):
            e = OxmlElement('w:' + side); e.set(qn('w:val'), 'single'); e.set(qn('w:sz'), '8'); e.set(qn('w:space'), '0'); e.set(qn('w:color'), '000000'); b.append(e)
        tcPr.append(b)
        first = True
        for ln in lines:
            p = c.paragraphs[0] if first else c.add_paragraph(); first = False
            self.setstyle(p, 'table copy'); p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            self.runs(p, ln)
            for r in p.runs: r.font.size = Pt(7.5)
        sp = self._new('Normal'); sp.paragraph_format.space_after = Pt(2)
    def save(self, path): self.d.save(path)
