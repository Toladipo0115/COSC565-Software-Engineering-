# EngageTrace UML Submission

## Blackboard
Upload EngageTrace_UML_Assignment.pdf. It contains all three UML models and their supporting text. The diagrams retain vector graphics.

## GitHub
Upload the uml-diagrams folder to the repository root. Each diagram type has its own subfolder: use-case, sequence, and class. SVG files are vector; PNG images are high-resolution. The class model has two linked image views for readability.

The package also includes the written explanations and editable source where available.
