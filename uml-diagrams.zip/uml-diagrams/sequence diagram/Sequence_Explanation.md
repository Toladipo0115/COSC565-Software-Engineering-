# EngageTrace sequence diagram explanation

## Selected main use case

UC03 Run decline analysis is the main processing workflow of EngageTrace. It accepts the analyst's selected dataset, course, week range and detector settings; validates the request; runs CAP and three comparison detectors; records the execution; and returns results or an error. It incorporates UC04 Validate analysis settings and UC05 Record analysis run. This is the proposed first-iteration application design, including the browser-triggered analysis feature identified in Requirements.md.

## Participating actor and objects

**Analyst:** the external human actor who submits the scope and settings. **dashboard:AnalysisDashboard:** a boundary object that accepts input and displays responses. **service:AnalysisService:** a control object that validates and coordinates the analysis. **engine:DetectionEngine:** a control object that applies CAP, fixed-threshold, individual-history-only and CUSUM methods. **repository:AnalysisRepository:** the persistence object that reads validated activity and writes metadata, outputs and status to SQLite. These are logical design objects, not a claim that the application is already implemented.

## Preconditions and input

OULAD files have already been imported and validated through UC01 and UC02. The analyst has selected a dataset version, course and week range and supplied settings. The input loader retrieves the required earlier history and the eligible cohort data needed by CAP, even when the displayed analysis window begins later. Parameters include history window, lag, log-deviation threshold, cohort-percentile threshold and persistence.

## Messages 1 to 5 request and validation

The analyst submits the request to the dashboard, which calls runAnalysis on the service. The service retrieves dataset metadata and validates settings through a synchronous self-call. This checks parameter ranges and available coverage before a new computational run is created.

## Outer alt fragment validation alternatives

The first operand, [invalid settings], returns validation errors and shows corrections. No detectors run and no completed analysis is recorded. The second operand, [valid settings], creates a RUNNING run with its settings and versions, loads the required activity and calls the detection engine. The operands are alternatives, not consecutive workflow steps.

## Loop fragment detector execution

The loop executes once for each of CAP, fixed threshold, individual-history-only and CUSUM. The self-call detect(method, input, settings) applies the selected detector and collects its outputs. CAP evaluates individual log-scale deviation, contemporaneous cohort rank and consecutive-week persistence. The engine returns a structured outcome with all outputs or an error. Sequential execution is modeled; the diagram does not imply parallel execution.

## Nested alt fragment completion or failure

If all four methods succeed, saveResultsAndComplete stores the outputs and changes status to COMPLETED in one transaction. The stored run identifier and summary return to the dashboard. If a detector fails, markRunFailed records FAILED status and its reason. The dashboard shows an error and does not present partial outputs as a completed comparison. These alternatives represent UC05's successful and failed execution records.

## Message types and activations

Solid message lines with filled triangular arrowheads denote synchronous calls; the caller waits for completion. Dashed lines with open arrowheads denote returns or responses. Self-messages show validation and per-detector work within an object. Narrow rectangles show execution specifications, and dashed vertical lines are lifelines. An asynchronous message is not used because this version models a synchronous request and response; no background queue is assumed.

## Scope and requirement traceability

FR-03 supplies the scope; FR-04 covers configuration and validation; FR-05 covers the four detectors; FR-06 covers run persistence and status. Returning the completed run supports subsequent review and comparison without adding those independent use cases to this processing sequence. CSV import, timeline drill-down, saved-run loading and export are outside this selected interaction. Network and database failures beyond detector failure require separate implementation-level handling and are not expanded here.