# EngageTrace Class Diagram Guide

## One model in two views

The application view contains seven orchestration and interface classes. The domain view contains ten entity/value classes. Together they form the proposed first-iteration design. The repeated AnalysisRepository box is the same class, linking both views through its managed datasets and runs, not an eighteenth class. The sequence objects dashboard, service, engine and repository are instances of the corresponding named classes; the Analyst is an external actor, not a stored User class.

## Notation and data types

Each class has name, attributes and operations compartments. Minus (-) means private; plus (+) means public. A question mark means nullable. UUID, String, Int, Float, Boolean, DateTime, Map and List[T] are value/container types, not additional business classes. A wrapped operation line beginning with spaces continues the signature above it.

## Multiplicity and ownership

A solid line denotes an association. A filled diamond is on the whole/owner side of composition. Each association and composition is labeled at both ends. Application 1-to-1 relationships describe the selected local application context: services share the same configured importer, repository, exporter and engine. Multiple dashboard sessions (0..*) can use that one service. These values describe runtime object structure, not employee counts. In the domain view the repository represents the gateway to the selected local database; its managed-dataset and managed-run associations do not imply in-memory caching or ownership of entity lifetimes.

## Detector design

Detector is a concrete strategy selected by method: CAP, FIXED, INDIVIDUAL or CUSUM. The engine owns exactly four objects, one of each method. No inheritance or realization is shown, so all drawn relationships are instance-level associations/compositions with multiplicities. The four algorithms are configured behavior within Detector; a later implementation may refactor them into subclasses.

## Entity identity and constraints

CoursePresentation is unique within a dataset version by module and presentation code. Enrollment is unique by course and student. WeeklyActivity is unique by enrollment and week; CohortWeek by course and week; DetectionResult by run, enrollment, detector method and week. Associations represent the foreign keys, so duplicate foreign-key attributes are omitted from these class boxes.

## Run and result integrity

Every DetectionRun belongs to one course presentation and owns one copied, immutable DetectionParameters snapshot. A new run may have zero results; a completed run retains its eligible student-week outputs. Every DetectionResult references exactly one enrollment, and that enrollment must belong to the run's course. A flagged result must be eligible. A student can enroll in multiple courses and have multiple results across methods, weeks and runs.

## Enums and validation

DetectorMethod = {CAP, FIXED, INDIVIDUAL, CUSUM}. RunStatus = {RUNNING, COMPLETED, FAILED}. ImportStatus = {PENDING, COMPLETED, FAILED}. ObservationStatus = {OBSERVED, MISSING}. Window, lag and persistence values must satisfy the chosen documented history policy. contextPercentile is between 0 and 1; click counts and row counts are nonnegative. Missing activity is not automatically zero.

## Requirements coverage

DataImporter and DatasetVersion/SourceFile cover FR-01 and FR-02. Dashboard and service cover FR-03/FR-04. Engine, Detector and parameters cover FR-05. Repository, run and results cover FR-06/FR-11. Dashboard queries and weekly/cohort records support FR-07 through FR-09. ResultExporter covers FR-10. Database access is encapsulated in AnalysisRepository; raw data and real user identities are not modeled as application users.

## Relationships

| Left class | Left end | Type | Right end | Right class |
| --- | --- | --- | --- | --- |
| AnalysisDashboard | 0..* | association | 1 | AnalysisService |
| AnalysisService | 1 | association | 1 | DataImporter |
| AnalysisService | 1 | association | 1 | AnalysisRepository |
| AnalysisService | 1 | association | 1 | DetectionEngine |
| AnalysisService | 1 | association | 1 | ResultExporter |
| DataImporter | 1 | association | 1 | AnalysisRepository |
| ResultExporter | 1 | association | 1 | AnalysisRepository |
| DetectionEngine | 1 | composition | 4 | Detector |
| DatasetVersion | 1 | composition | 0..* | SourceFile |
| DatasetVersion | 1 | composition | 0..* | CoursePresentation |
| CoursePresentation | 1 | association | 0..* | Enrollment |
| Student | 1 | association | 0..* | Enrollment |
| Enrollment | 1 | composition | 0..* | WeeklyActivity |
| CoursePresentation | 1 | composition | 0..* | CohortWeek |
| CoursePresentation | 1 | association | 0..* | DetectionRun |
| Enrollment | 1 | association | 0..* | DetectionResult |
| DetectionRun | 1 | composition | 0..* | DetectionResult |
| DetectionRun | 1 | composition | 1 | DetectionParameters |
| AnalysisRepository | 1 | association | 0..* | DatasetVersion |
| AnalysisRepository | 1 | association | 0..* | DetectionRun |
