# EngageTrace use case descriptions

## UC01 Import LMS activity

**Actor:** Analyst

**Requirements:** FR-01

The analyst supplies courses.csv, studentRegistration.csv, and studentVle.csv through the ingestion command or proposed analyst-only upload endpoint. The system invokes UC02 and reports the dataset version and import summary.

**Precondition:** Readable source files are available.

**Outcome:** Valid input is imported once; invalid input is rejected with reasons.

**Relationship:** Includes UC02 on every import attempt.

## UC02 Validate and prepare data

**Actor:** Analyst, through UC01

**Requirements:** FR-02

The system checks required fields, identifiers, dates, nonnegative clicks and course relationships; reports rejected rows; prevents duplicate imports; and aggregates accepted daily clicks into weekly activity under the documented eligibility policy.

**Precondition:** UC01 has supplied source files.

**Outcome:** A validated weekly dataset is available, or the import fails with a clear explanation.

**Relationship:** Included by UC01; this is system behavior, not a separate human actor.

## UC03 Run decline analysis

**Actor:** Analyst

**Requirements:** FR-03, FR-04, FR-05

The analyst selects a dataset, course and week range, sets the history window, lag, deviation, cohort percentile and persistence parameters, and requests analysis. UC04 checks the settings. The engine executes CAP, fixed threshold, individual-history-only and CUSUM, then UC05 records the run.

**Precondition:** A validated dataset exists and sufficient eligible history is available for evaluated observations.

**Outcome:** The four methods produce eligible student-week flags; failure is reported without presenting partial results as complete.

**Relationship:** Includes UC04 and UC05 in the normal successful flow. Scope selection and configuration are steps in this use case.

## UC04 Validate analysis settings

**Actor:** Analyst, through UC03

**Requirements:** FR-04

The system verifies parameter types, allowed ranges, the selected course and weeks, and the availability of required data. Invalid settings prevent computation and produce a clear correction message.

**Precondition:** The analyst has supplied the proposed analysis configuration.

**Outcome:** Accepted settings can be executed; rejected settings require correction.

**Relationship:** Included by UC03. It validates settings; it does not choose thresholds for the analyst.

## UC05 Record analysis run

**Actor:** Analyst, through UC03

**Requirements:** FR-06

The system records dataset and engine versions, scope, settings, timestamps and run status. A successful run stores method outputs transactionally. If execution fails, the system records failure status rather than exposing a completed result.

**Precondition:** UC03 has an analysis request and its execution status.

**Outcome:** The run is traceable, and completed outputs can be reopened reproducibly.

**Relationship:** Included by UC03. This records a new run; UC06 loads an existing one.

## UC06 Load saved analysis

**Actor:** Analyst

**Requirements:** FR-11

The analyst selects a completed run. The application restores its dataset, course, week range, parameter values and stored method outputs for inspection without silently recomputing them.

**Precondition:** At least one completed run exists.

**Outcome:** The selected run is loaded unchanged; another computation creates a new run identifier.

**Relationship:** Independent use case; not an inclusion of UC03 because loading must not rerun detection.

## UC07 Review decline flags

**Actor:** Instructor, Advisor

**Requirements:** FR-09

An instructor or advisor reviews the current completed run and filters or sorts the flag list by student pseudonym, week and method. The list provides evidence for human review and does not automatically contact a student or assert disengagement.

**Precondition:** A completed run is available in the dashboard.

**Outcome:** Relevant flagged records are identified; a user can finish by reviewing the list alone.

**Relationship:** Extension point: inspect selected student. UC08 extends this use case when a student is selected for detail.

## UC08 View student timeline

**Actor:** Instructor, Advisor through UC07

**Requirements:** FR-07

When the reviewer selects a student while reviewing flags, the dashboard shows weekly clicks against the course median, method flag markers and condition explanations. Missing observations, zeros and insufficient history are distinguished.

**Precondition:** UC07 is active and the reviewer selects a student.

**Outcome:** The activity pattern behind the selected flag is visible, with an accessible data table.

**Relationship:** Extends UC07 at inspect selected student, only when the reviewer requests student detail.

## UC09 Compare detector outputs

**Actor:** Instructor, Advisor

**Requirements:** FR-08

The user compares CAP and the three baselines for a completed run using flagged student-week counts, eligible denominators, percentages and CAP flag-volume reduction relative to the fixed rule. The view distinguishes alert volume from verified false positives.

**Precondition:** A completed run contains results for the comparison methods.

**Outcome:** The user can inspect method differences without exporting any file.

**Relationship:** Extension point: export displayed comparison. UC10 extends this use case when export is requested.

## UC10 Export analysis results

**Actor:** Instructor, Advisor through UC09

**Requirements:** FR-10

If the user requests export while comparing methods, the application downloads the displayed or filtered results as CSV and the associated run metadata as JSON. It retains pseudonyms, method labels and complete settings, and escapes formula-like text cells.

**Precondition:** UC09 is active and a completed comparison is displayed.

**Outcome:** Downloadable results and metadata match the selected comparison scope.

**Relationship:** Extends UC09 at export displayed comparison, only when the user selects Export.

